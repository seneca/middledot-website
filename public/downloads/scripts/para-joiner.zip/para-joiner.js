/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    para-joiner.js
Description:    Joins the selected text range by replacing paragraph breaks,
                soft returns (Shift+Enter), and surrounding non-printing
                whitespace (regular spaces, tabs, NBSP, thin, hair, etc.)
                with a single normal space.  Runs of whitespace are collapsed
                to one space and punctuation at line ends is preserved.
                Character styles and inline elements are preserved.
                Paragraph style is left as-is (merged paragraph retains
                first paragraph's style; pull-back acquires previous line's
                style natively).  Supports linked/threaded frames spanning
                spreads — selection across pages is joined as one paragraph
                with a single space (no forced break at thread boundary).
                Works on normal and master-derived text frames.

Author:         Les Pruszynski (Middledot)
Version:        1.3.12
Created:        27/08/2026
Last updated:   17/09/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/


const { Document }                         = require('/document');
const { Selection, TextSelection, SubSelectionType } = require('/selections');
const { StoryDelta }                       = require('/storydelta');
const { GlyphAttStringType }               = require('/glyphatts');
const { DocumentCommand, CompoundCommandBuilder } = require('/commands');
const { getNodeChildren, NodeChildType }   = require('/nodes');

// ============================================================
// CONFIGURATION
// ============================================================

const CONFIG = {
  markerPrefix: '__PARA_JOIN_SEL__'
};

// ============================================================
// TEXT NODE HELPERS
// ============================================================

const TEXT_NODE_PROPS = [
  'isFrameTextNode', 'isArtTextNode', 'isPolyCurveTextNode',
  'isShapePathTextNode', 'isShapeTextNode', 'isCurvePathTextNode'
];

function isTextNodeLike(node) {
  if (!node) return false;
  for (const p of TEXT_NODE_PROPS) {
    if (node[p]) return true;
  }
  return false;
}

function walkTextNodes(handle, out, depth) {
  if (depth > 10) return;
  let children;
  try { children = getNodeChildren(handle, NodeChildType.Main, false); }
  catch (e) { return; }
  for (const n of children) {
    if (!n) continue;
    if (isTextNodeLike(n)) out.push(n);
    walkTextNodes(n.handle, out, depth + 1);
  }
}
function collectTextNodesOnCurrentSpread(doc) {
  const out = [];
  walkTextNodes(doc.currentSpread.handle, out, 0);
  return out;
}
function collectTextNodesAcrossDocument(doc) {
  try {
    const out = [];
    for (const sp of [...doc.spreads]) walkTextNodes(sp.handle, out, 0);
    return out;
  } catch (e) {
    return collectTextNodesOnCurrentSpread(doc);
  }
}

// Helper: group hits by TEXT FLOW (for linked/threaded frames only).
// Stories cannot be compared — Story exposes no isSameNode in this SDK,
// so story-identity checks (and the old overlap heuristic) silently never
// matched across wrappers. Grouping is by shared-flow membership on nodes
// instead, where isSameNode is valid.
// Unthreaded cross-box selection is not possible in Publisher, so only
// linked/threaded coalescing is needed. No forced break at thread boundary.
function groupHitsByStory(hits) {
  const groups = [];
  const flowCache = new Map();
  function flowOf(node) {
    if (!flowCache.has(node)) flowCache.set(node, getFlowFrames(node));
    return flowCache.get(node);
  }
  for (const h of hits) {
    const hFlow = flowOf(h.node);
    let g = null;
    for (const gr of groups) {
      if (isSameFlow(h.node, hFlow, gr.repNode, gr.repFlow)) { g = gr; break; }
    }
    if (g) {
      if (h.begin < g.begin) g.begin = h.begin;
      if (h.end > g.end) g.end = h.end;
      g.nodes.push(h.node);
      // keep representative node whose storyRange contains begin
      try {
        const sr = h.node.storyInterface.storyRange;
        if (h.begin >= sr.begin && h.begin < sr.end) g.repNode = h.node;
      } catch (e) {}
    } else {
      groups.push({ story: h.story, begin: h.begin, end: h.end, nodes: [h.node], repNode: h.node, repFlow: hFlow });
    }
  }
  // Threaded-only: Publisher cannot select across unthreaded boxes, so if
  // grouping produced multiple groups (separate Stories) it would be an
  // invalid state — coalesce to single group to avoid triple alerts.
  // For true separate Stories (should not happen), we still coalesce to one.
  if (groups.length > 1) {
    let minB = groups[0].begin, maxE = groups[0].end;
    const allNodes = [];
    let rep = groups[0].repNode;
    for (const gr of groups) {
      if (gr.begin < minB) minB = gr.begin;
      if (gr.end > maxE) maxE = gr.end;
      allNodes.push(...gr.nodes);
    }
    return [{ story: groups[0].story, begin: minB, end: maxE, nodes: allNodes, repNode: rep }];
  }
  return groups;
}

// ============================================================
// SPREAD RESOLUTION
// ============================================================

function isSameNodeSafe(a, b) {
  if (!a || !b) return false;
  try { return !!a.isSameNode(b); } catch (e) { return false; }
}

// Linked-flow helpers: stories expose no usable identity primitive
// (isSameNode exists on nodes only), so linked frames are matched by
// SHARED FLOW membership instead — node-to-node, where isSameNode is
// valid. Same pattern as para-pairs.js (see also the bundled
// examples/breakFrame.js, which navigates flows the same way).
function getFlowFrames(node) {
  try {
    const frameInterface = node.textFrameInterface;
    if (frameInterface) {
      const flow = frameInterface.textFlowNodes;
      if (flow && flow.length > 0) return flow;
    }
  } catch (e) {}
  return null;
}

function isSameFlow(nodeA, flowA, nodeB, flowB) {
  if (isSameNodeSafe(nodeA, nodeB)) return true;
  if (flowA) {
    for (const frame of flowA) {
      if (isSameNodeSafe(frame, nodeB)) return true;
    }
  }
  if (flowB) {
    for (const frame of flowB) {
      if (isSameNodeSafe(frame, nodeA)) return true;
    }
  }
  return false;
}

// The document spread the text frame visually lives on:
//   1. node.spread — only if it validates as a document spread
//   2. doc.currentSpread — fallback (master-derived frames)
function resolveNodeSpread(node, doc) {
  const spreads = [...doc.spreads];
  if (node.spread) {
    for (const s of spreads) {
      if (isSameNodeSafe(node.spread, s)) return s;
    }
  }
  return doc.currentSpread;
}

// ============================================================
// SELECTION CAPTURE
// ============================================================

// Normal path: requires an explicit text sub-selection (anchor !== caret).
// Supports cross-spread linked/threaded selections: collects all text
// sub-selections (each SelectionItem may be on a different spread), groups
// by Story identity, and unions to a single logical range per Story (so a
// drag spanning linked frames across spreads becomes one paragraph, no forced
// break at the thread boundary).
function captureSelection(doc) {
  const sel = doc.selection;
  if (!sel || sel.length === 0) return null;
  const hits = [];
  for (let idx = 0; idx < sel.length; idx++) {
    let item;
    try { item = sel.at(idx); } catch (e) { continue; }
    const node = item.node;
    if (!isTextNodeLike(node)) continue;
    let ts;
    try { ts = item.getSubSelectionOfType(SubSelectionType.Text); } catch (e) { continue; }
    if (!ts || ts.isEmpty) continue;
    const a = Math.min(ts.caret, ts.anchor);
    const b = Math.max(ts.caret, ts.anchor);
    if (a === b) continue;
    let story = null;
    try { story = node.storyInterface.story; } catch (e) {}
    hits.push({ node: node, begin: a, end: b, story: story });
  }
  if (hits.length === 0) return null;
  // If only one hit, return single scope (backward compatible)
  if (hits.length === 1) return hits[0];
  // Multiple hits: group by Story (linked/threaded) and union
  const groups = groupHitsByStory(hits);
  const scopes = [];
  for (const g of groups) {
    if (g.end - g.begin <= 2) continue;
    scopes.push({ node: g.repNode, begin: g.begin, end: g.end, mode: 'selection', story: g.story });
  }
  if (scopes.length === 0) return null;
  if (scopes.length === 1) return scopes[0];
  // For linked/threaded we expect one scope (one Story). If truly multiple stories, return array.
  return scopes;
}

// Master-derived fallback: apply a temporary character style to the
// live selection, scan document-wide text nodes for the marker,
// union the marked runs per node, then undo. Range-only (rejects <= 2).
// Supports cross-spread linked/threaded selections: hits are grouped by
// Story and unioned to a single logical range per Story (no forced break
// at thread boundary), so a drag spanning linked frames across spreads
// becomes one paragraph.
function captureViaMarker(doc) {
  const marker = CONFIG.markerPrefix + Date.now();
  let markerFound = false;
  try {
    const delta = StoryDelta.createGlyphString(GlyphAttStringType.StyleName, marker);
    doc.formatText(delta);

    // Walk all spreads for cross-spread linked selections; fallback to current spread
    let candidates = collectTextNodesAcrossDocument(doc);
    if (!candidates || candidates.length === 0) candidates = collectTextNodesOnCurrentSpread(doc);
    const rawHits = [];
    for (const node of candidates) {
      try {
        const story = node.storyInterface.story;
        let uBegin = null, uEnd = null;
        for (const run of story.getGlyphAttRunsFrom(0)) {
          if (run.glyphAtts.getStringValue(GlyphAttStringType.StyleName) === marker) {
            markerFound = true;
            if (uBegin === null || run.begin < uBegin) uBegin = run.begin;
            if (uEnd === null || run.end > uEnd) uEnd = run.end;
          }
        }
        if (uBegin !== null) rawHits.push({ node: node, begin: uBegin, end: uEnd, story: story });
      } catch (e) { /* skip unreadable nodes */ }
    }
    if (rawHits.length === 0) return null;

    // Group by Story (linked/threaded frames share same Story) and union
    const groups = groupHitsByStory(rawHits);
    // Filter degenerate and build scopes
    const scopes = [];
    for (const g of groups) {
      const len = g.end - g.begin;
      if (len <= 2) continue;
      // For linked story, keep global union (no forced break at thread). Use repNode whose storyRange contains begin, or first node.
      let repNode = g.repNode;
      if (!repNode) repNode = g.nodes[0];
      // Do NOT clamp to repNode's storyRange for linked case — keep global to allow single-paragraph join across spreads
      scopes.push({ node: repNode, begin: g.begin, end: g.end, mode: 'selection', source: 'marker', story: g.story });
    }
    if (scopes.length === 0) return null;
    if (scopes.length === 1) return scopes[0];
    // Multiple distinct Stories (separate boxes) — per spec only linked should be joined; return first for now, but expose array for caller to handle
    return scopes;
  } catch (e) {
    return null;
  } finally {
    if (markerFound) { try { doc.undo(); } catch (e) {} }
  }
}

// ============================================================
// TEXT PROCESSING HELPERS
// ============================================================

// Returns true only for non-printing whitespace that may surround a
// break: regular ASCII space (U+0020), tab (U+0009), and Unicode
// space variants (NBSP, thin, hair, etc.).  Returns FALSE for
// punctuation (',', '.', ';', ':', '!', '?' etc.), letters, digits,
// and control characters (\n, \r, U+2029).  This guarantees commas/
// full-stops at the end of a line are never stripped when a paragraph
// is joined.
function isTrimmableSpace(c) {
  if (!c) return false;
  if (c === ' ' || c === '\t') return true;
  const cp = c.codePointAt(0);
  // Explicit punctuation guard — never trimmable (covers , . ; : ! ? ' " - ( ) etc. that could be near a break)
  if (cp === 0x002C || cp === 0x002E || cp === 0x003B || cp === 0x003A ||
      cp === 0x0021 || cp === 0x003F || cp === 0x0027 || cp === 0x0022 ||
      cp === 0x002D || cp === 0x0028 || cp === 0x0029) return false;
  // Paragraph/line separators themselves are breaks, not spaces
  if (cp === 0x2029 || cp === 0x2028 || cp === 0x000A || cp === 0x000D) return false;
  // Fast path for NBSP family
  if (cp === 0x00A0) return true;                  // NBSP
  if (cp >= 0x2000 && cp <= 0x200A) return true;   // en/em/figure/thin/hair etc.
  if (cp === 0x202F || cp === 0x205F) return true;  // narrow NBSP / med math space
  if (cp === 0x3000 || cp === 0x1680) return true;  // ideographic / ogham space
  // Generic whitespace fallback: \s covers many unicode spaces in modern JS
  try { if (/^\s$/.test(c)) return true; } catch (e) {}
  return false;
}

// Legacy wrapper — "non-standard" means trimmable but not the plain
// ASCII space/tab.  Kept for readability where we need to distinguish.
function isNonStandardSpace(c) {
  if (!c || c === ' ' || c === '\t') return false;
  return isTrimmableSpace(c);
}

// Helper: fetch single char at story position.  Prefer direct
// story.getText(pos,1) which is position-accurate even when
// getText(begin,count) skips break characters (U+2029) and would
// misalign a snapshot.  Snapshot is only a last-resort fallback.
function storyCharAt(story, pos, snapshot, snapshotBegin) {
  try {
    const t = story.getText(pos, 1);
    if (t && t.length === 1) return t;
    if (t && t.length > 0) return t[0];
    // If getText returns empty for a break position, that position is a break, not a space — return empty
    if (t === '') return '';
  } catch (e) {}
  if (snapshot && pos >= snapshotBegin && pos < snapshotBegin + snapshot.length) {
    // Estimate offset: snapshot may be shorter than story range if breaks are omitted.
    // We try direct mapping but also try to correct for break count skew by probing nearby.
    return snapshot[pos - snapshotBegin] || '';
  }
  return '';
}

// Helper: robustly determine if story position pos holds trimmable space
function isTrimmableAt(story, pos, snapshot, snapshotBegin) {
  const ch = storyCharAt(story, pos, snapshot, snapshotBegin);
  // Empty means break or out-of-range — not trimmable
  if (!ch) return false;
  return isTrimmableSpace(ch);
}

// Scans [begin, end) and returns a list of replacement targets.
// Each target is { begin: <int>, end: <int>, type: 'break' | 'space' }
// where [begin, end) is the half-open run to replace with a single
// regular space (N→1).  For breaks the run is expanded to swallow
// contiguous trimmable whitespace on both sides of the break, so
// "word,  \n  next" → one space and "word," is preserved.  Only
// isTrimmableSpace characters are ever included — punctuation is
// never part of a run.
//
// Standalone whitespace runs (no break) are also normalised: a run
// of trimmable spaces that contains a non-standard variant or a tab
// or has length > 1 is collapsed to one space.  A single plain
// ASCII space is left alone.
function collectTargets(story, begin, end) {
  const targets = [];
  const count = end - begin;
  const snapshot = count > 0 ? story.getText(begin, count) : '';
  // Track which positions are already covered by a break run so we
  // don't emit overlapping space runs.
  const covered = [];
  function markCovered(b, e) { covered.push([b, e]); }
  function isCovered(pos) {
    for (let k = 0; k < covered.length; k++) {
      if (pos >= covered[k][0] && pos < covered[k][1]) return true;
    }
    return false;
  }
  function overlapsCovered(b, e) {
    for (let k = 0; k < covered.length; k++) {
      const cb = covered[k][0], ce = covered[k][1];
      if (b < ce && e > cb) return true;
    }
    return false;
  }

  // Phase 1: break-anchored runs (hard + soft), expanded to adjacent whitespace.
  // Use per-position isTrimmableAt to avoid snapshot misalignment for U+2029
  // (story.getText(begin,count) may omit breaks, shifting snapshot indices).
  // Note: g.isSoftBreak is true for ordinary spaces too (see snippet-export.js:281),
  // so a real soft break is isSoftBreak && !isCharGlyph.
  let i = begin;
  while (i < end) {
    let isBreak = false;
    try { if (story.isParagraphBreak(i)) isBreak = true; } catch (e) {}
    if (!isBreak) {
      try { const g = story.getGlyph(i); if (g && g.isSoftBreak && !g.isCharGlyph) isBreak = true; } catch (e) {}
    }
    if (isBreak) {
      let left = i - 1;
      while (left >= begin && isTrimmableAt(story, left, snapshot, begin)) left--;
      let right = i + 1;
      while (right < end && isTrimmableAt(story, right, snapshot, begin)) right++;
      const b = left + 1;
      const e = right;
      if (!overlapsCovered(b, e)) {
        targets.push({ begin: b, end: e, type: 'break' });
        markCovered(b, e);
      }
      i = right;
      continue;
    }
    i++;
  }

  // Phase 2: standalone trimmable runs not already covered.
  // Only normalise if the run would change: contains a non-standard
  // space/tab or has >1 char (so "  " or " \t" or "NBSP" → " ").
  // Use per-position checks as well for accuracy.
  i = begin;
  while (i < end) {
    if (isCovered(i)) { i++; continue; }
    if (!isTrimmableAt(story, i, snapshot, begin)) { i++; continue; }
    let j = i + 1;
    while (j < end && !isCovered(j) && isTrimmableAt(story, j, snapshot, begin)) j++;
    // Build run text via per-position fetches for hasNonStandard check
    let runText = '';
    for (let p = i; p < j; p++) runText += storyCharAt(story, p, snapshot, begin);
    let hasNonStandard = false;
    for (let c = 0; c < runText.length; c++) {
      if (isNonStandardSpace(runText[c]) || runText[c] === '\t') { hasNonStandard = true; break; }
    }
    if ((hasNonStandard || (j - i) > 1) && !overlapsCovered(i, j)) {
      targets.push({ begin: i, end: j, type: 'space' });
      markCovered(i, j);
    }
    i = j;
  }

  // Sort ascending for callers that iterate, but mergeBreaks will
  // execute right-to-left. Keep stable order by begin.
  targets.sort(function(a, b) { return a.begin - b.begin; });
  return targets;
}

// Merges paragraph breaks, soft returns, and surrounding non-printing
// whitespace in [begin, end).  Each target run [begin,end) (N chars,
// N>=1) is replaced with a single regular space (N→1).  Runs that are
// break-anchored have already swallowed adjacent spaces/tabs/NBSPs, so
// punctuation like ',' or '.' left of the run is untouched.  All
// replacements are batched into one CompoundCommandBuilder and
// executed right-to-left so story positions remain valid.  Character
// styles are preserved because only the targeted glyphs are replaced;
// paragraph style is left as-is (native inheritance).
function mergeBreaks(doc, node, begin, end, targets) {
  if (!targets || targets.length === 0) return false;
  const mergedBreak = targets.some(function(t) { return t.type === 'break'; });
  const compound = CompoundCommandBuilder.create();
  for (let k = targets.length - 1; k >= 0; k--) {
    const t = targets[k];
    const sel = Selection.create(doc, node);
    sel.addSubSelectionForNode(node, TextSelection.create([{ begin: t.begin, end: t.end }]));
    compound.addCommand(DocumentCommand.createSetText(sel, ' '));
  }
  doc.executeCommand(compound.createCommand());
  return mergedBreak;
}

// ============================================================
// PARAGRAPH JOINING
// ============================================================

function joinParagraphs(doc, node, begin, end) {
  const story = node.storyInterface.story;
  // Flow of the scope node, computed once: linked-frame matching below is
  // node-to-node because stories cannot be compared in this SDK.
  const scopeFlow = getFlowFrames(node);
  // Cache document-wide text nodes once for both maxEnd and sharding
  let allNodes = null;
  try { allNodes = collectTextNodesAcrossDocument(doc); } catch (e) {}
  if (!allNodes || allNodes.length === 0) {
    try { allNodes = collectTextNodesOnCurrentSpread(doc); } catch (e) { allNodes = []; }
  }
  // Clamp end to avoid terminator; for threaded use Story total terminator
  let safeEnd = end;
  try {
    let maxEnd = -1;
    for (const n of allNodes) {
      try {
        if (isSameFlow(node, scopeFlow, n, getFlowFrames(n)) && n.storyInterface.storyRange.end > maxEnd) maxEnd = n.storyInterface.storyRange.end;
      } catch (e) {}
    }
    if (maxEnd === -1) {
      for (const n of allNodes) {
        try {
          const sr = n.storyInterface.storyRange;
          if (sr.begin < end && sr.end > begin && sr.end > maxEnd) maxEnd = sr.end;
        } catch (e) {}
      }
    }
    const sr = node.storyInterface.storyRange;
    const clampEnd = maxEnd !== -1 ? maxEnd : sr.end;
    safeEnd = Math.min(end, clampEnd - 1);
    if (safeEnd < begin) safeEnd = begin;
  } catch (e) {
    const sr = node.storyInterface.storyRange;
    safeEnd = Math.min(end, sr.end - 1);
  }

  // Collect targets — shard per linked frame's Story wrapper so
  // isParagraphBreak/getText are queried on the containing node (fixes B1/B2).
  // No alerts, no Block, threaded-only, single N→1 batch.
  let targets = [];
  try {
    const linkedNodes = [];
    for (const n of allNodes) {
      try {
        if (isSameFlow(node, scopeFlow, n, getFlowFrames(n))) linkedNodes.push(n);
      } catch (e) {}
    }
    if (linkedNodes.length === 0) {
      for (const n of allNodes) {
        try {
          const sr = n.storyInterface.storyRange;
          if (sr.begin < safeEnd && sr.end > begin) linkedNodes.push(n);
        } catch (e) {}
      }
    }
    if (linkedNodes.length > 1) {
      const allT = [];
      for (const n of linkedNodes) {
        const sr = n.storyInterface.storyRange;
        const b = Math.max(begin, sr.begin);
        const e = Math.min(safeEnd, sr.end);
        if (b >= e) continue;
        try {
          const t = collectTargets(n.storyInterface.story, b, e);
          allT.push(...t);
        } catch (e2) {}
      }
      allT.sort((a,b)=>a.begin-b.begin);
      const deduped = [];
      const covered = [];
      function overlaps(a,b){ for(const [c,d] of covered) if(a<d&&b>c) return true; return false; }
      for (const t of allT) {
        if (!overlaps(t.begin, t.end)) {
          deduped.push(t);
          covered.push([t.begin, t.end]);
        }
      }
      deduped.sort((a,b)=>a.begin-b.begin);
      targets = deduped;
    } else {
      targets = collectTargets(story, begin, safeEnd);
    }
  } catch (e) {
    targets = collectTargets(story, begin, safeEnd);
  }
  if (targets.length === 0) return;

  // Set current spread (master-aware: node.spread can resolve to
  // the master spread for master-derived frames, so validate first).
  const spread = resolveNodeSpread(node, doc);
  if (!isSameNodeSafe(spread, doc.currentSpread)) {
    doc.executeCommand(DocumentCommand.createSetCurrentSpread(spread));
  }

  // Merge breaks and surrounding whitespace.  Each target run is
  // replaced with a single regular space (N→1).  Paragraph style is
  // left as-is — the merged paragraph retains the first paragraph's
  // style natively (pull-back acquires previous line's style), and
  // character styles are preserved because only the break/space glyphs
  // are replaced. No alerts, no Block.
  mergeBreaks(doc, node, begin, safeEnd, targets);
}

// ============================================================
// MAIN
// ============================================================

function main() {
  const doc = Document.current;
  if (!doc) return;

  // Capture selection(s) — supports cross-spread linked/threaded frames
  // as a single logical Story range (no forced break at thread boundary).
  // Threaded-only: separate boxes cannot be selected together, so only
  // linked case is handled. No alerts — silent exit if nothing to do.
  let scopes = captureSelection(doc);
  if (!scopes) scopes = captureViaMarker(doc);
  if (!scopes) return;
  if (!Array.isArray(scopes)) scopes = [scopes];
  for (const sc of scopes) {
    if (!sc || !sc.node || sc.begin >= sc.end) continue;
    joinParagraphs(doc, sc.node, sc.begin, sc.end);
  }
}

// ============================================================
// RUN
// ============================================================

try {
  main();
} catch (error) {
  console.error('Paragraph Joiner failed: ' + error.message);
}
