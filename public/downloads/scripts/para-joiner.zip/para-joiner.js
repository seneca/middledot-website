/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    para-joiner.js
Description:    Joins the selected text range by replacing paragraph breaks,
                soft returns (Shift+Enter), and surrounding non-printing
                whitespace (regular spaces, tabs, NBSP, thin, hair, etc.)
                with a single normal space.  Runs of whitespace are collapsed
                to one space and punctuation at line ends is preserved.
                Character styles and inline elements are preserved.
                Paragraph style is left as-is (merged paragraph retains
                first paragraph's style; pull-back acquires previous line's
                style natively).  Supports linked/threaded frames spanning
                spreads — selection across pages is joined as one paragraph
                with a single space (no forced break at thread boundary).
                Works on normal and master-derived text frames.

Author:         Les Pruszynski (Middledot)
Version:        1.3.14
Created:        27/08/2026
Last updated:   14/10/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/

'use strict';

const { Document }                         = require('/document');
const { Selection, TextSelection, SubSelectionType } = require('/selections');
const { StoryDelta }                       = require('/storydelta');
const { GlyphAttStringType }               = require('/glyphatts');
const { DocumentCommand, CompoundCommandBuilder } = require('/commands');
const { getNodeChildren, NodeChildType }   = require('/nodes');

// ============================================================
// CONFIGURATION
// ============================================================

const CONFIG = {
  // Prefix for the temporary character-style name used to mark a live
  // selection when the normal selection path cannot capture it.
  markerPrefix: '__PARA_JOIN_SEL__'
};

// Internal invariants (not user-tweakable).
const WALK_DEPTH_MAX = 10;   // max node-tree descent when walking text nodes
const MIN_RANGE_LEN  = 3;    // ranges shorter than this are degenerate and skipped

// ============================================================
// TEXT NODE HELPERS
// ============================================================

const TEXT_NODE_PROPS = [
  'isFrameTextNode', 'isArtTextNode', 'isPolyCurveTextNode',
  'isShapePathTextNode', 'isShapeTextNode', 'isCurvePathTextNode'
];

function isTextNodeLike(node) {
  if (!node) return false;
  for (const p of TEXT_NODE_PROPS) {
    if (node[p]) return true;
  }
  return false;
}

// Sort runs by begin and drop overlaps (first run wins). Non-mutating.
function dedupeRuns(runs) {
  const sorted = runs.toSorted((a, b) => a.begin - b.begin);
  const out = [];
  let lastEnd = -1;
  for (const r of sorted) {
    if (r.begin >= lastEnd) { out.push(r); lastEnd = r.end; }
  }
  return out;
}

function walkTextNodes(handle, out, depth) {
  if (depth > WALK_DEPTH_MAX) return;
  let children;
  try { children = getNodeChildren(handle, NodeChildType.Main, false); }
  catch (e) { return; }
  for (const n of children) {
    if (!n) continue;
    if (isTextNodeLike(n)) out.push(n);
    walkTextNodes(n.handle, out, depth + 1);
  }
}
function collectTextNodesOnCurrentSpread(doc) {
  const out = [];
  walkTextNodes(doc.currentSpread.handle, out, 0);
  return out;
}
function collectTextNodesAcrossDocument(doc) {
  try {
    const out = [];
    for (const sp of [...doc.spreads]) walkTextNodes(sp.handle, out, 0);
    return out;
  } catch (e) {
    return collectTextNodesOnCurrentSpread(doc);
  }
}
// Walk the whole document, falling back to the current spread if that
// comes back empty (e.g. a document with no readable spreads list yet).
function collectAllTextNodes(doc) {
  let nodes = collectTextNodesAcrossDocument(doc);
  if (!nodes || nodes.length === 0) nodes = collectTextNodesOnCurrentSpread(doc);
  return nodes;
}

// Group hits by TEXT FLOW (linked/threaded frames only).
// Story identity unavailable in this SDK (no isSameNode on Story);
// grouping uses shared-flow membership on nodes instead.
// Threaded-only: Publisher can't select across unthreaded boxes, so more
// than one group here means genuinely separate stories. Callers treat that
// as the documented "not handled" case rather than merging unrelated
// stories' coordinate spaces into one nonsensical range.
function groupHitsByStory(hits) {
  const groups = [];
  const flowCache = new Map();
  function flowOf(node) {
    if (!flowCache.has(node)) flowCache.set(node, getFlowFrames(node));
    return flowCache.get(node);
  }
  for (const h of hits) {
    const hFlow = flowOf(h.node);
    let g = null;
    for (const gr of groups) {
      if (isSameFlow(h.node, hFlow, gr.repNode, gr.repFlow)) { g = gr; break; }
    }
    if (g) {
      if (h.begin < g.begin) g.begin = h.begin;
      if (h.end > g.end) g.end = h.end;
      g.nodes.push(h.node);
      // keep representative node whose storyRange contains begin
      try {
        const sr = h.node.storyInterface.storyRange;
        if (h.begin >= sr.begin && h.begin < sr.end) g.repNode = h.node;
      } catch (e) {}
    } else {
      groups.push({ story: h.story, begin: h.begin, end: h.end, nodes: [h.node], repNode: h.node, repFlow: hFlow });
    }
  }
  return groups;
}

// ============================================================
// SPREAD RESOLUTION
// ============================================================

function isSameNodeSafe(a, b) {
  if (!a || !b) return false;
  try { return !!a.isSameNode(b); } catch (e) { return false; }
}

// Linked-flow matching: stories expose no identity primitive,
// so frames are matched by shared-flow membership (node-to-node).
// Same pattern as para-pairs.js (see also examples/breakFrame.js).
function getFlowFrames(node) {
  try {
    const frameInterface = node.textFrameInterface;
    if (frameInterface) {
      const flow = frameInterface.textFlowNodes;
      if (flow && flow.length > 0) return flow;
    }
  } catch (e) {}
  return null;
}

function isSameFlow(nodeA, flowA, nodeB, flowB) {
  if (isSameNodeSafe(nodeA, nodeB)) return true;
  if (flowA) {
    for (const frame of flowA) {
      if (isSameNodeSafe(frame, nodeB)) return true;
    }
  }
  if (flowB) {
    for (const frame of flowB) {
      if (isSameNodeSafe(frame, nodeA)) return true;
    }
  }
  return false;
}

// The document spread the text frame visually lives on:
//   1. node.spread — only if it validates as a document spread
//   2. doc.currentSpread — fallback (master-derived frames)
function resolveNodeSpread(node, doc) {
  const spreads = [...doc.spreads];
  if (node.spread) {
    for (const s of spreads) {
      if (isSameNodeSafe(node.spread, s)) return s;
    }
  }
  return doc.currentSpread;
}

// ============================================================
// SELECTION CAPTURE
// ============================================================

// Explicit text sub-selection required (anchor !== caret).
// Cross-spread linked/threaded: collects all sub-selections,
// groups by Story, unions to a single logical range per Story.
function captureSelection(doc) {
  const sel = doc.selection;
  if (!sel || sel.length === 0) return null;
  const hits = [];
  for (let idx = 0; idx < sel.length; idx++) {
    let item;
    try { item = sel.at(idx); } catch (e) { continue; }
    const node = item.node;
    if (!isTextNodeLike(node)) continue;
    let ts;
    try { ts = item.getSubSelectionOfType(SubSelectionType.Text); } catch (e) { continue; }
    if (!ts || ts.isEmpty) continue;
    const a = Math.min(ts.caret, ts.anchor);
    const b = Math.max(ts.caret, ts.anchor);
    if (a === b) continue;
    let story = null;
    try { story = node.storyInterface.story; } catch (e) {}
    hits.push({ node: node, begin: a, end: b, story: story });
  }
  if (hits.length === 0) return null;
  // If only one hit, return single scope (backward compatible)
  if (hits.length === 1) return hits[0];
  // Multiple hits: group by text flow (linked/threaded). More than one
  // group means genuinely separate, unthreaded stories — not supported
  // (see para-joiner.md "Known limitations"); treat as nothing to do.
  const groups = groupHitsByStory(hits);
  if (groups.length !== 1) return null;
  const g = groups[0];
  if (g.end - g.begin < MIN_RANGE_LEN) return null;
  return { node: g.repNode, begin: g.begin, end: g.end, mode: 'selection', story: g.story };
}

// History position before a probe mutation, so cleanup only undoes when
// the probe actually pushed an entry (a blind undo would pop the user's).
function getHistoryPosition(doc) {
  try { if (doc.history) return doc.history.position; } catch (e) {}
  return null;
}

// Undo a probe cleanup only with history evidence of a pushed entry;
// trust the scan result when history is unreadable.
function shouldUndoProbe(historyBefore, mutationFound, doc) {
  if (historyBefore === null) return mutationFound;
  const historyAfter = getHistoryPosition(doc);
  if (historyAfter === null) return mutationFound;
  return historyAfter > historyBefore;
}

function warnCleanupFailed(kind, e) {
  try {
    console.warn(`para-joiner: ${kind} cleanup failed, history may need an extra undo: ${e && e.message ? e.message : e}`);
  } catch (e2) {}
}

// Marker fallback for master-derived frames.
// Range-only (rejects degenerate ranges); cross-spread grouped by Story.
function captureViaMarker(doc) {
  const marker = CONFIG.markerPrefix + Date.now();
  let markerApplied = false;
  let historyBefore = null;
  let markerFound = false;
  try {
    const delta = StoryDelta.createGlyphString(GlyphAttStringType.StyleName, marker);
    historyBefore = getHistoryPosition(doc);
    doc.formatText(delta);
    markerApplied = true;

    // Walk all spreads for cross-spread linked selections; fallback to current spread
    const candidates = collectAllTextNodes(doc);
    const rawHits = [];
    for (const node of candidates) {
      try {
        const story = node.storyInterface.story;
        let uBegin = null, uEnd = null;
        for (const run of story.getGlyphAttRunsFrom(0)) {
          if (run.glyphAtts.getStringValue(GlyphAttStringType.StyleName) === marker) {
            markerFound = true;
            if (uBegin === null || run.begin < uBegin) uBegin = run.begin;
            if (uEnd === null || run.end > uEnd) uEnd = run.end;
          }
        }
        if (uBegin !== null) rawHits.push({ node: node, begin: uBegin, end: uEnd, story: story });
      } catch (e) { /* skip unreadable nodes */ }
    }
    if (rawHits.length === 0) return null;

    // Group by text flow (linked/threaded frames share a flow) and union.
    // More than one group means genuinely separate stories — not supported
    // (see para-joiner.md "Known limitations"); treat as nothing to do.
    const groups = groupHitsByStory(rawHits);
    if (groups.length !== 1) return null;
    const g = groups[0];
    if (g.end - g.begin < MIN_RANGE_LEN) return null;
    // For linked story, keep global union (no forced break at thread). Use repNode whose storyRange contains begin, or first node.
    const repNode = g.repNode || g.nodes[0];
    // Do NOT clamp to repNode's storyRange for linked case — keep global to allow single-paragraph join across spreads
    return { node: repNode, begin: g.begin, end: g.end, mode: 'selection', source: 'marker', story: g.story };
  } catch (e) {
    return null;
  } finally {
    if (markerApplied) {
      if (shouldUndoProbe(historyBefore, markerFound, doc)) {
        try { doc.undo(); } catch (e) { warnCleanupFailed('marker', e); }
      } else if (markerFound) {
        try { console.warn('para-joiner: marker style found but no history entry was pushed; leaving it in place.'); } catch (e2) {}
      }
    }
  }
}

// ============================================================
// TEXT PROCESSING HELPERS
// ============================================================

// True for trimmable whitespace (space, tab, NBSP, thin, hair…).
// False for punctuation, letters, digits, and line separators.
function isTrimmableSpace(c) {
  if (!c) return false;
  if (c === ' ' || c === '\t') return true;
  const cp = c.codePointAt(0);
  // Paragraph/line separators themselves are breaks, not spaces
  if (cp === 0x2029 || cp === 0x2028 || cp === 0x000A || cp === 0x000D) return false;
  // Fast path for NBSP family
  if (cp === 0x00A0) return true;                  // NBSP
  if (cp >= 0x2000 && cp <= 0x200A) return true;   // en/em/figure/thin/hair etc.
  if (cp === 0x202F || cp === 0x205F) return true;  // narrow NBSP / med math space
  if (cp === 0x3000 || cp === 0x1680) return true;  // ideographic / ogham space
  // Generic whitespace fallback: \s covers many unicode spaces in modern JS
  try { if (/^\s$/.test(c)) return true; } catch (e) {}
  return false;
}

// "Non-standard" means trimmable but not a plain ASCII space — a lone tab
// or NBSP-family character still normalizes even at run length 1, whereas
// a lone plain space does not (see usage in collectTargets below).
function isNonStandardSpace(c) {
  if (!c || c === ' ') return false;
  return isTrimmableSpace(c);
}

// Fetch single char at story position. Direct getText preferred
// (position-accurate even when breaks are omitted);
// snapshot is the last-resort fallback.
function storyCharAt(story, pos, snapshot, snapshotBegin) {
  try {
    const t = story.getText(pos, 1);
    if (t && t.length === 1) return t;
    if (t && t.length > 0) return t[0];
    // If getText returns empty for a break position, that position is a break, not a space — return empty
    if (t === '') return '';
  } catch (e) {}
  if (snapshot && pos >= snapshotBegin && pos < snapshotBegin + snapshot.length) {
    // Estimate offset: snapshot may be shorter than story range if breaks are omitted.
    // We try direct mapping but also try to correct for break count skew by probing nearby.
    return snapshot[pos - snapshotBegin] || '';
  }
  return '';
}

// Helper: robustly determine if story position pos holds trimmable space
function isTrimmableAt(story, pos, snapshot, snapshotBegin) {
  const ch = storyCharAt(story, pos, snapshot, snapshotBegin);
  // Empty means break or out-of-range — not trimmable
  if (!ch) return false;
  return isTrimmableSpace(ch);
}

// Scans [begin, end) for break-anchored and standalone trimmable runs.
// Break-anchored runs expand to swallow adjacent whitespace;
// standalone runs normalize only if >1 char or contains variant.
function collectTargets(story, begin, end) {
  const targets = [];
  const count = end - begin;
  const snapshot = count > 0 ? story.getText(begin, count) : '';
  // Track which positions are already covered by a break run so we
  // don't emit overlapping space runs.
  const covered = [];
  function markCovered(b, e) { covered.push([b, e]); }
  function isCovered(pos) {
    for (let k = 0; k < covered.length; k++) {
      if (pos >= covered[k][0] && pos < covered[k][1]) return true;
    }
    return false;
  }
  function overlapsCovered(b, e) {
    for (let k = 0; k < covered.length; k++) {
      const cb = covered[k][0], ce = covered[k][1];
      if (b < ce && e > cb) return true;
    }
    return false;
  }

  // Phase 1: break-anchored runs (hard + soft), expanded to adjacent whitespace.
  // Per-position isTrimmableAt avoids U+2029 snapshot misalignment.
  // g.isSoftBreak is true for ordinary spaces — real soft break is isSoftBreak && !isCharGlyph.
  let i = begin;
  while (i < end) {
    let isBreak = false;
    try { if (story.isParagraphBreak(i)) isBreak = true; } catch (e) {}
    if (!isBreak) {
      try { const g = story.getGlyph(i); if (g && g.isSoftBreak && !g.isCharGlyph) isBreak = true; } catch (e) {}
    }
    if (isBreak) {
      let left = i - 1;
      while (left >= begin && isTrimmableAt(story, left, snapshot, begin)) left--;
      let right = i + 1;
      while (right < end && isTrimmableAt(story, right, snapshot, begin)) right++;
      const b = left + 1;
      const e = right;
      if (!overlapsCovered(b, e)) {
        targets.push({ begin: b, end: e, type: 'break' });
        markCovered(b, e);
      }
      i = right;
      continue;
    }
    i++;
  }

  // Phase 2: standalone trimmable runs not already covered.
  // Normalize only if run would change (>1 char or contains variant).
  i = begin;
  while (i < end) {
    if (isCovered(i)) { i++; continue; }
    if (!isTrimmableAt(story, i, snapshot, begin)) { i++; continue; }
    let j = i + 1;
    while (j < end && !isCovered(j) && isTrimmableAt(story, j, snapshot, begin)) j++;
    // Build run text via per-position fetches for hasNonStandard check
    let runText = '';
    for (let p = i; p < j; p++) runText += storyCharAt(story, p, snapshot, begin);
    let hasNonStandard = false;
    for (let c = 0; c < runText.length; c++) {
      if (isNonStandardSpace(runText[c])) { hasNonStandard = true; break; }
    }
    if ((hasNonStandard || (j - i) > 1) && !overlapsCovered(i, j)) {
      targets.push({ begin: i, end: j, type: 'space' });
      markCovered(i, j);
    }
    i = j;
  }

  // Sorted ascending; mergeBreaks executes right-to-left.
  return dedupeRuns(targets);
}

// N→1 replacement per target run, right-to-left so story positions remain valid.
// Break-anchored runs already swallowed adjacent whitespace — punctuation untouched.
// Character styles preserved (targeted glyphs only); paragraph style left as-is.
// `spread`, if given and not already current, is switched to inside this same
// compound — with useAsDescription on the first content command — so the
// whole operation (spread switch included) undoes in a single step. Same
// pattern as para-pairs.js; see docs/sdk-issues.md BUG-012.
function mergeBreaks(doc, node, targets, spread) {
  if (!targets || targets.length === 0) return;
  const compound = CompoundCommandBuilder.create();
  if (spread && !isSameNodeSafe(spread, doc.currentSpread)) {
    compound.addCommand(DocumentCommand.createSetCurrentSpread(spread));
  }
  let descriptionSet = false;
  for (let k = targets.length - 1; k >= 0; k--) {
    const t = targets[k];
    const sel = Selection.create(doc, node);
    sel.addSubSelectionForNode(node, TextSelection.create([{ begin: t.begin, end: t.end }]));
    compound.addCommand(DocumentCommand.createSetText(sel, ' '), !descriptionSet);
    descriptionSet = true;
  }
  doc.executeCommand(compound.createCommand());
}

// ============================================================
// PARAGRAPH JOINING
// ============================================================

function joinParagraphs(doc, node, begin, end) {
  const story = node.storyInterface.story;
  // Flow of the scope node, computed once: linked-frame matching below is
  // node-to-node because stories cannot be compared in this SDK.
  const scopeFlow = getFlowFrames(node);
  // Cache document-wide text nodes once for both maxEnd and sharding
  let allNodes = [];
  try { allNodes = collectAllTextNodes(doc); } catch (e) {}

  // Flow membership is identical for both the maxEnd clamp below and the
  // target collection further down — compute once and reuse.
  const flowMatchedNodes = [];
  for (const n of allNodes) {
    try { if (isSameFlow(node, scopeFlow, n, getFlowFrames(n))) flowMatchedNodes.push(n); } catch (e) {}
  }

  // Clamp end to avoid terminator; for threaded use Story total terminator
  let safeEnd = end;
  try {
    let maxEnd = -1;
    for (const n of flowMatchedNodes) {
      try { if (n.storyInterface.storyRange.end > maxEnd) maxEnd = n.storyInterface.storyRange.end; } catch (e) {}
    }
    if (maxEnd === -1) {
      for (const n of allNodes) {
        try {
          const sr = n.storyInterface.storyRange;
          if (sr.begin < end && sr.end > begin && sr.end > maxEnd) maxEnd = sr.end;
        } catch (e) {}
      }
    }
    const sr = node.storyInterface.storyRange;
    const clampEnd = maxEnd !== -1 ? maxEnd : sr.end;
    safeEnd = Math.min(end, clampEnd - 1);
    if (safeEnd < begin) safeEnd = begin;
  } catch (e) {
    const sr = node.storyInterface.storyRange;
    safeEnd = Math.min(end, sr.end - 1);
  }

  // Collect targets — shard per linked frame's Story wrapper so
  // isParagraphBreak/getText are queried on the containing node (fixes B1/B2).
  // No alerts, no Block, threaded-only, single N→1 batch.
  let targets = [];
  try {
    let linkedNodes = flowMatchedNodes;
    if (linkedNodes.length === 0) {
      linkedNodes = [];
      for (const n of allNodes) {
        try {
          const sr = n.storyInterface.storyRange;
          if (sr.begin < safeEnd && sr.end > begin) linkedNodes.push(n);
        } catch (e) {}
      }
    }
    if (linkedNodes.length > 1) {
      const allT = [];
      for (const n of linkedNodes) {
        const sr = n.storyInterface.storyRange;
        const b = Math.max(begin, sr.begin);
        const e = Math.min(safeEnd, sr.end);
        if (b >= e) continue;
        try {
          const t = collectTargets(n.storyInterface.story, b, e);
          allT.push(...t);
        } catch (e2) {}
      }
      targets = dedupeRuns(allT);
    } else {
      targets = collectTargets(story, begin, safeEnd);
    }
  } catch (e) {
    targets = collectTargets(story, begin, safeEnd);
  }
  if (targets.length === 0) return;

  // Resolve the spread (master-aware: node.spread may be the master spread).
  // The switch itself happens inside mergeBreaks' compound below, so the
  // whole operation stays a single undo step.
  const spread = resolveNodeSpread(node, doc);

  // N→1 per target run, right-to-left; break-anchored whitespace swallowed — punctuation untouched.
  // Char styles preserved (targeted glyphs only); paragraph style left as-is (native inheritance).
  mergeBreaks(doc, node, targets, spread);
}

// ============================================================
// MAIN
// ============================================================

function main() {
  const doc = Document.current;
  if (!doc) return;

  // Capture the selection — cross-spread linked/threaded frames resolve to
  // a single logical Story range (no forced break at the thread boundary).
  // Threaded-only: separate boxes can't be selected together; silent exit if nothing to do.
  const scope = captureSelection(doc) || captureViaMarker(doc);
  if (!scope || !scope.node || scope.begin >= scope.end) return;
  joinParagraphs(doc, scope.node, scope.begin, scope.end);
}

// ============================================================
// RUN
// ============================================================

try {
  main();
} catch (error) {
  console.error(`Paragraph Joiner failed: ${error.message}`);
}
