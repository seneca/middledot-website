/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    para-pairs.js
Description:    Finds a paragraph with style A followed immediately by a paragraph with style B, and re-styles the pair. Master pages are scanned. The whole run is a single undo step.

Author:         Les Pruszynski (Middledot)
Version:        1.2.5
Created:        —
Last updated:   17/09/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/

"use strict";

// Only selection-safe modules are loaded here. Selection-sensitive state is
// captured before modules that can disturb the live text selection.
const { Document } = require("/document");
const { Selection, TextSelection, SubSelectionType } = require("/selections");
const { StoryDelta } = require("/storydelta");
const { GlyphAttStringType } = require("/glyphatts");
// /commands is safe at top level: it is absent from the selection-clearing
// list, and para-joiner.js already requires it up top with working capture.
const { DocumentCommand, CompoundCommandBuilder } = require("/commands");
const {
  NodeChildType,
  getNodeChildren,
  getNodeChildrenRecursive,
} = require("/nodes");

const sdkModules = {};
// Cached lazy require: defers selection-clearing module loads until after snapshot capture.
function sdk(path) {
  return sdkModules[path] || (sdkModules[path] = require(path));
}
function getApp() {
  return sdk("/application").app;
}
function getDialogModules() {
  return sdk("/dialog");
}
function getParagraphStyleType() {
  return sdk("/paragraphatts").ParagraphAttStringType;
}

const NO_STYLE_LABEL = "[No Paragraph Style]";
const KEEP_LABEL = "\u2014 Keep current style \u2014";
const ANY_LABEL = "\u2014 Any paragraph style \u2014";
const ANY_SENTINEL = Symbol("any");
const KEEP_SENTINEL = Symbol("keep");

const SCOPE_DOCUMENT = "document";
const SCOPE_STORY = "story";
const SCOPE_RANGE = "range";

const LIVE_SELECTION_MARKER_PREFIX = "__PARA_PAIRS_SEL__";
// Private Use Area character, U+E000. Never use a printable character here.
const LIVE_CARET_PROBE = String.fromCodePoint(0xe000);

// Fresh JS wrappers per access defeat === and String(handle); isSameNode
// compares the native object — but exists on NODES only, never on stories.
function isSameSdkNode(a, b) {
  if (!a || !b) return false;
  try {
    if (typeof a.isSameNode === "function") return !!a.isSameNode(b);
  } catch (e) {}
  return a === b;
}

// Frames of the node's text flow, in flow order; null when unavailable.
function getFlowFrames(node) {
  try {
    const frameInterface = node.textFrameInterface;
    if (frameInterface) {
      const flow = frameInterface.textFlowNodes;
      if (flow && flow.length > 0) return flow;
    }
  } catch (e) {}
  return null;
}

// Shared flow ⟺ shared story, compared node-to-node where isSameNode is
// valid. Direct match first so singletons work without flow enumeration.
function isSameFlow(nodeA, flowA, nodeB, flowB) {
  if (isSameSdkNode(nodeA, nodeB)) return true;
  if (flowA) {
    for (const frame of flowA) {
      try {
        if (isSameSdkNode(frame, nodeB)) return true;
      } catch (e) {}
    }
  }
  if (flowB) {
    for (const frame of flowB) {
      try {
        if (isSameSdkNode(frame, nodeA)) return true;
      } catch (e) {}
    }
  }
  return false;
}

// History position before a probe mutation, so cleanup only undoes when
// the probe actually pushed an entry (a blind undo would pop the user's
// own previous entry when the probe silently did nothing).
function getHistoryPosition(doc) {
  try {
    if (doc.history) return doc.history.position;
  } catch (e) {}
  return null;
}

// Undo a probe cleanup only with history evidence of a pushed entry;
// trust the scan result when history is unreadable.
function shouldUndoProbe(historyBefore, mutationFound, doc) {
  if (historyBefore === null) return mutationFound;
  const historyAfter = getHistoryPosition(doc);
  if (historyAfter === null) return mutationFound;
  return historyAfter > historyBefore;
}

function warnCleanupFailed(kind, e) {
  try {
    console.warn(
      "para-pairs: " +
        kind +
        " cleanup failed, history may need an extra undo: " +
        (e && e.message ? e.message : e),
    );
  } catch (e2) {}
}

function* iterAllTextLikeNodes(doc) {
  for (const layer of doc.layers.all) {
    if (layer) yield layer;
  }
  // Master spreads aren't included in doc.layers / doc.spreads.
  const rootHandle = doc.rootNode.handle;
  for (const masterSpread of getNodeChildren(
    rootHandle,
    NodeChildType.MasterSpread,
    false,
  )) {
    if (!masterSpread) continue;
    for (const descendant of getNodeChildrenRecursive(
      masterSpread.handle,
      NodeChildType.Main,
      false,
    )) {
      if (descendant) yield descendant;
    }
  }
}

function getParagraphsOfStory(story, paragraphStyleType) {
  const paras = [];
  for (const range of story.paragraphRanges) {
    let styleName = "";
    try {
      styleName =
        story
          .getParagraphAtts(range.begin)
          .getStringValue(paragraphStyleType.StyleName) || "";
    } catch (e) {
      styleName = "";
    }
    paras.push({ begin: range.begin, end: range.end, style: styleName });
  }
  return paras;
}

function scanDocument(doc) {
  const paragraphStyleType = getParagraphStyleType();
  const styleSet = new Set();
  const nodeEntries = [];
  for (const node of collectFrameTextNodes(doc)) {
    let story;
    try {
      story = node.storyInterface.story;
    } catch (e) {
      continue;
    }
    if (!story) continue;
    // Group by SHARED FLOW (stories are uncomparable); keep the flow
    // for scope matching later.
    const flow = getFlowFrames(node);
    const group = nodeEntries.find((candidate) =>
      isSameFlow(candidate.node, candidate.flow, node, flow),
    );
    if (group) continue;
    const paras = getParagraphsOfStory(story, paragraphStyleType);
    nodeEntries.push({ node: node, flow: flow, paras: paras });
    for (const p of paras) styleSet.add(p.style);
  }
  // Case-insensitive sort (localeCompare throws ICU errors in this runtime).
  const named = [...styleSet]
    .filter((s) => s !== "")
    .sort((a, b) => {
      const al = a.toLowerCase(),
        bl = b.toLowerCase();
      return al < bl ? -1 : al > bl ? 1 : a < b ? -1 : a > b ? 1 : 0;
    });
  const hasUnstyled = styleSet.has("");
  const stylesInUse = hasUnstyled ? [...named, ""] : named;
  return { stylesInUse, nodeEntries };
}

// Snapshot: node locates the selected flow (matched by flow membership,
// never by comparing stories); range is the union of text sub-ranges in
// story offsets. Anything beyond one frame falls back to whole-document.
function emptySnapshot(source) {
  return {
    node: null,
    rangeBegin: null,
    rangeEnd: null,
    hasStory: false,
    hasRange: false,
    source: source,
  };
}

function collectFrameTextNodes(doc) {
  const out = [];
  for (const layer of iterAllTextLikeNodes(doc)) {
    if (layer && layer.isFrameTextNode) out.push(layer);
  }
  return out;
}

// Frame clicked as an object (no text range): narrows to its flow without
// touching the document. Ranges go to the marker pass (also covering
// master frames, where doc.selection reads empty); carets to the probe.
function snapshotFrameObject(doc) {
  const result = emptySnapshot("frame");
  let item = null;
  try {
    const sel = doc.selection;
    if (!sel || sel.length !== 1) return result;
    item = sel.at(0);
  } catch (e) {
    return result;
  }
  const node = item && item.node;
  if (!node || !node.isFrameTextNode) return result;
  try {
    const sub = item.getSubSelectionOfType(SubSelectionType.Text);
    if (sub && !sub.isEmpty) return result; // a real range: marker's job
  } catch (e) {}
  try {
    for (const range of node.storyInterface.story.paragraphRanges) {
      if (range) {
        result.node = node;
        result.hasStory = true;
        return result;
      }
    }
  } catch (e) {}
  return result;
}

// Probes the live target: reports which frame's story changed and by how
// much (+1 proves a caret, <= 0 a range selection). Always undone first.
// Null on any failure.
function probeLiveTarget(doc) {
  const candidates = collectFrameTextNodes(doc);
  const before = [];
  for (const node of candidates) {
    try {
      const story = node.storyInterface.story;
      // Keyed by NODE: node identity is comparable, story identity is not.
      if (story) before.push({ node: node, length: story.length });
    } catch (e) {}
  }
  if (before.length === 0) return null;
  const historyBefore = getHistoryPosition(doc);
  let probeApplied = false,
    changed = false,
    outcome = null;
  try {
    try {
      // No selection argument inserts at the live UI caret, or replaces
      // the live UI range selection.
      doc.setText(LIVE_CARET_PROBE);
    } catch (e) {
      return null;
    }
    probeApplied = true;
    for (const node of candidates) {
      let story;
      try {
        story = node.storyInterface.story;
      } catch (e) {
        continue;
      }
      if (!story) continue;
      let postLength;
      try {
        postLength = story.length;
      } catch (e) {
        continue;
      }
      const pre = before.find((entry) =>
        isSameSdkNode(entry.node, node),
      );
      if (pre && postLength !== pre.length) {
        changed = true;
        outcome = { node: node, delta: postLength - pre.length };
        break;
      }
    }
    return outcome;
  } finally {
    if (probeApplied && shouldUndoProbe(historyBefore, changed, doc)) {
      try {
        doc.undo();
      } catch (e) {
        warnCleanupFailed("live-target probe", e);
      }
    }
  }
}

// True only when the probe proves the marker's story holds a collapsed
// caret (caret styling may cover the enclosing word, faking a selection).
function isProvenCaret(doc, node, flow) {
  const probe = probeLiveTarget(doc);
  return (
    !!probe &&
    probe.delta === 1 &&
    isSameFlow(probe.node, getFlowFrames(probe.node), node, flow)
  );
}

function snapshotLiveRange(doc) {
  const result = emptySnapshot("marker");
  const marker = LIVE_SELECTION_MARKER_PREFIX + Date.now();
  let markerApplied = false;
  let historyBefore = null;
  let markerFound = false;
  try {
    let delta;
    try {
      delta = StoryDelta.createGlyphString(
        GlyphAttStringType.StyleName,
        marker,
      );
    } catch (e) {
      return result;
    }
    try {
      historyBefore = getHistoryPosition(doc);
      // No selection argument targets the live UI text selection.
      doc.formatText(delta);
    } catch (e) {
      return result;
    }
    markerApplied = true;

    const groups = [];
    for (const node of collectFrameTextNodes(doc)) {
      let story;
      try {
        story = node.storyInterface.story;
      } catch (e) {
        continue;
      }
      if (!story) continue;

      let begin = null,
        end = null;
      try {
        for (const run of story.getGlyphAttRunsFrom(0)) {
          let styleName = "";
          try {
            styleName =
              run.glyphAtts.getStringValue(GlyphAttStringType.StyleName) ||
              "";
          } catch (e) {
            continue;
          }
          if (styleName === marker) {
            if (begin === null || run.begin < begin) begin = run.begin;
            if (end === null || run.end > end) end = run.end;
          }
        }
      } catch (e) {
        continue;
      }
      if (begin === null || end === null) continue;

      // Group by flow membership (stories cannot be compared).
      const flow = getFlowFrames(node);
      const group = groups.find((candidate) =>
        isSameFlow(candidate.node, candidate.flow, node, flow),
      );
      if (!group) {
        groups.push({ node: node, flow: flow, begin: begin, end: end });
      } else {
        if (begin < group.begin) group.begin = begin;
        if (end > group.end) group.end = end;
      }
    }
    if (groups.length === 0) return result;
    // The marker lands in one story only, so every group must show the same
    // union (linked frames each scan the shared story). Diverging unions
    // mean a multi-story selection: fall back to whole-document scope.
    const sameMark = groups.every(
      (g) => g.begin === groups[0].begin && g.end === groups[0].end,
    );
    if (!sameMark) {
      try {
        console.warn(
          "para-pairs: selection spans multiple stories; using whole-document scope.",
        );
      } catch (e2) {}
      return result;
    }
    markerFound = true;

    const best = groups[0];
    result.node = best.node;
    result.hasStory = true;
    if (
      best.end - best.begin > 1 &&
      !isProvenCaret(doc, best.node, best.flow)
    ) {
      result.rangeBegin = best.begin;
      result.rangeEnd = best.end;
      result.hasRange = true;
    } else if (best.end > best.begin) {
      // Collapsed caret, not a selection: story scope only (a superset of
      // range scope, so no match is lost).
      result.source = "marker-caret";
    }
  } finally {
    if (markerApplied) {
      if (shouldUndoProbe(historyBefore, markerFound, doc)) {
        try {
          doc.undo();
        } catch (e) {
          warnCleanupFailed("live-selection marker", e);
        }
      } else if (markerFound) {
        try {
          console.warn(
            "para-pairs: marker style found but no history entry was pushed; leaving it in place.",
          );
        } catch (e2) {}
      }
    }
  }
  return result;
}

function snapshotLiveCaret(doc) {
  const result = emptySnapshot("caret");
  const probe = probeLiveTarget(doc);
  if (probe && probe.delta === 1) {
    result.node = probe.node;
    result.hasStory = true;
  }
  return result;
}

function resolveSnapshot(doc) {
  const frame = snapshotFrameObject(doc);
  if (frame.hasStory) return frame;
  const liveRange = snapshotLiveRange(doc);
  if (liveRange.hasStory || liveRange.hasRange) return liveRange;
  return snapshotLiveCaret(doc);
}

// Combo boxes use parallel label/value arrays; choices are looked up by
// index, never by parsing the label back to a style name.
function buildDialog(stylesInUse, selSnapshot) {
  const { Dialog, HorizontalAlignment } = getDialogModules();
  const styleLabels = stylesInUse.map((s) =>
    String(s === "" ? NO_STYLE_LABEL : s),
  );
  const styleValues = stylesInUse.slice();

  const findLabels = [String(ANY_LABEL)].concat(styleLabels);
  const findValues = [ANY_SENTINEL].concat(styleValues);

  const replaceALabels = [String(KEEP_LABEL)].concat(styleLabels);
  const replaceAValues = [KEEP_SENTINEL].concat(styleValues);

  const replaceBLabels = [String(KEEP_LABEL)].concat(styleLabels);
  const replaceBValues = [KEEP_SENTINEL].concat(styleValues);

  const scopeLabels = ["Whole document"];
  const scopeValues = [SCOPE_DOCUMENT];
  if (selSnapshot.hasStory) {
    scopeLabels.push("Current story");
    scopeValues.push(SCOPE_STORY);
  }
  if (selSnapshot.hasRange) {
    scopeLabels.push("Current text selection");
    scopeValues.push(SCOPE_RANGE);
  }
  // Default to the narrowest available scope.
  let defaultScopeIdx = 0;
  if (selSnapshot.hasRange) defaultScopeIdx = scopeValues.indexOf(SCOPE_RANGE);
  else if (selSnapshot.hasStory)
    defaultScopeIdx = scopeValues.indexOf(SCOPE_STORY);

  const dlg = Dialog.create("Find & Replace Paragraph Pairs");
  const col = dlg.addColumn();

  let scopeCombo = null;
  if (scopeValues.length > 1) {
    const scopeGrp = col.addGroup("Scope");
    scopeCombo = scopeGrp.addComboBox("Apply to", scopeLabels);
    scopeCombo.isFullWidth = true;
    scopeCombo.selectedIndex = defaultScopeIdx;
  }

  const findGrp = col.addGroup("Find");
  const defaultFindAIdx = styleLabels.length > 0 ? 1 : 0;
  const defaultFindBIdx =
    styleLabels.length > 1 ? 2 : styleLabels.length > 0 ? 1 : 0;
  const findA = findGrp.addComboBox("First paragraph style", findLabels);
  findA.isFullWidth = true;
  findA.selectedIndex = defaultFindAIdx;
  const findB = findGrp.addComboBox("Followed by paragraph style", findLabels);
  findB.isFullWidth = true;
  findB.selectedIndex = defaultFindBIdx;

  const replaceGrp = col.addGroup("Replace with");
  const [replaceA, replaceB] = [
    {
      label: "New style for first paragraph",
      labels: replaceALabels,
      tip: '"Keep current style" leaves the first paragraph untouched.',
    },
    {
      label: "New style for second paragraph",
      labels: replaceBLabels,
      tip: '"Keep current style" leaves the second paragraph untouched.',
    },
  ].map((cfg) => {
    const combo = replaceGrp.addComboBox(cfg.label, cfg.labels);
    combo.isFullWidth = true;
    combo.selectedIndex = 0;
    combo.description = cfg.tip;
    return combo;
  });

  const notesGrp = col.addGroup("Notes");
  const note = notesGrp.addStaticText(
    "",
    "Lists show paragraph styles currently used in the document. " +
      "All matches are changed in a single undoable action.",
  );
  note.isFullWidth = true;
  try {
    note.textHorizontalAlignment = HorizontalAlignment.Left;
  } catch (e) {}

  return {
    dlg,
    findA,
    findB,
    replaceA,
    replaceB,
    scopeCombo,
    findValues,
    replaceAValues,
    replaceBValues,
    scopeValues,
  };
}

function matches(style, target) {
  return target === ANY_SENTINEL || style === target;
}

function findPairsInParas(paras, findA, findB, rangeBegin, rangeEnd) {
  const pairs = [];
  const filterByRange = rangeBegin !== null && rangeEnd !== null;
  for (let i = 0; i < paras.length - 1; i++) {
    const a = paras[i],
      b = paras[i + 1];
    if (!matches(a.style, findA) || !matches(b.style, findB)) continue;
    // Anchor to the first paragraph: selecting only the second does NOT match.
    if (filterByRange && !(a.begin < rangeEnd && a.end > rangeBegin)) continue;
    pairs.push({
      first: { begin: a.begin, end: a.end },
      second: { begin: b.begin, end: b.end },
    });
  }
  return pairs;
}

function resolveCommandSpread(doc, node) {
  try {
    const candidate = node.spread;
    if (candidate) {
      for (const spread of doc.spreads) {
        if (isSameSdkNode(candidate, spread)) return spread;
      }
    }
  } catch (e) {}
  try {
    return doc.currentSpread;
  } catch (e) {
    return null;
  }
}

// Groups hits per spread, stable with the starting spread last so the run
// ends where it began. Groups without a spread never match and stay put.
function groupHitsBySpread(hits, originalSpread) {
  const groups = [];
  for (const hit of hits) {
    const group = groups.find((candidate) =>
      isSameSdkNode(candidate.spreadNode, hit.spreadNode),
    );
    if (group) group.hits.push(hit);
    else groups.push({ spreadNode: hit.spreadNode, hits: [hit] });
  }
  const isOrigin = (group) =>
    !!(
      originalSpread &&
      group.spreadNode &&
      isSameSdkNode(group.spreadNode, originalSpread)
    );
  return groups
    .slice()
    .sort((a, b) => (isOrigin(a) === isOrigin(b) ? 0 : isOrigin(a) ? 1 : -1));
}

// Adds a format sub-command, marking the first one as the compound's
// History description so the undo entry reads as a content change rather
// than borrowing the first spread switch's label. Returns the updated flag.
function addFormatSubCommand(builder, command, descriptionSet) {
  builder.addCommand(command, !descriptionSet);
  return true;
}

// True only when the run ended on a different spread than it started on,
// meaning the viewport moved and a restore switch is warranted.
function needsSpreadRestore(originalSpread, activeSpread) {
  return !!(
    originalSpread &&
    activeSpread &&
    !isSameSdkNode(activeSpread, originalSpread)
  );
}

function buildFormatCommand(doc, node, ranges, styleName) {
  const paragraphStyleType = getParagraphStyleType();
  const sel = Selection.create(doc, node);
  const textSel = TextSelection.create(ranges);
  sel.addSubSelectionForNode(node, textSel);
  const delta = StoryDelta.createParagraphString(
    paragraphStyleType.StyleName,
    styleName,
  );
  return DocumentCommand.createFormatText(sel, delta);
}

function main() {
  const doc = Document.current;
  if (!doc) {
    getApp().alert("Open a document first.", "No document");
    return;
  }

  // Capture selection-sensitive state before loading modules or scanning
  // styles that can disturb the live text selection.
  const selSnapshot = resolveSnapshot(doc);
  const { stylesInUse, nodeEntries } = scanDocument(doc);
  // The snapshot locates a FLOW (node-to-node, the only identity the SDK
  // implements), not a story.
  const snapshotFlow = selSnapshot.node
    ? getFlowFrames(selSnapshot.node)
    : null;
  try {
    // Diagnostic for "why no match": snapshot source, scope detail, flow
    // match result, and distinct flows scanned.
    let flowMatched = "n/a";
    let flowSize = "n/a";
    if (selSnapshot.node) {
      flowSize = String(snapshotFlow ? snapshotFlow.length : 1);
      flowMatched = String(
        nodeEntries.some((entry) =>
          isSameFlow(
            selSnapshot.node,
            snapshotFlow,
            entry.node,
            entry.flow,
          ),
        ),
      );
    }
    console.log(
      "para-pairs: scope snapshot source=" +
        selSnapshot.source +
        " hasStory=" +
        selSnapshot.hasStory +
        " hasRange=" +
        selSnapshot.hasRange +
        (selSnapshot.hasRange
          ? " range=[" +
            selSnapshot.rangeBegin +
            "," +
            selSnapshot.rangeEnd +
            ")"
          : "") +
        " flowMatched=" +
        flowMatched +
        " flowSize=" +
        flowSize +
        " flowGroups=" +
        nodeEntries.length,
    );
  } catch (e) {}
  if (!stylesInUse.length) {
    getApp().alert(
      "No text frames with paragraphs were found in this document.",
      "Nothing to do",
    );
    return;
  }

  const ui = buildDialog(stylesInUse, selSnapshot);
  const { DialogResult } = getDialogModules();

  while (ui.dlg.runModal() == DialogResult.Ok) {
    const findA = ui.findValues[ui.findA.selectedIndex];
    const findB = ui.findValues[ui.findB.selectedIndex];

    const replaceAVal = ui.replaceAValues[ui.replaceA.selectedIndex];
    const keepFirst = replaceAVal === KEEP_SENTINEL;
    const replaceStyleA = keepFirst ? null : replaceAVal;

    const replaceBVal = ui.replaceBValues[ui.replaceB.selectedIndex];
    const keepSecond = replaceBVal === KEEP_SENTINEL;
    const replaceStyleB = keepSecond ? null : replaceBVal;

    const scope = ui.scopeCombo
      ? ui.scopeValues[ui.scopeCombo.selectedIndex]
      : SCOPE_DOCUMENT;

    if (keepFirst && keepSecond) {
      getApp().alert(
        'Both replacement fields are set to "Keep current style", ' +
          "so there's nothing to change.",
        "Nothing to do",
      );
      continue;
    }

    const restrictToNode =
      scope === SCOPE_STORY || scope === SCOPE_RANGE
        ? selSnapshot.node
        : null;
    const rangeBegin = scope === SCOPE_RANGE ? selSnapshot.rangeBegin : null;
    const rangeEnd = scope === SCOPE_RANGE ? selSnapshot.rangeEnd : null;

    const hits = [];
    let totalPairs = 0;

    for (const entry of nodeEntries) {
      if (
        restrictToNode !== null &&
        !isSameFlow(
          restrictToNode,
          snapshotFlow,
          entry.node,
          entry.flow,
        )
      )
        continue;
      const pairs = findPairsInParas(
        entry.paras,
        findA,
        findB,
        rangeBegin,
        rangeEnd,
      );
      if (!pairs.length) continue;
      totalPairs += pairs.length;
      const sides = [];
      if (!keepFirst)
        sides.push({
          ranges: pairs.map((p) => p.first),
          style: replaceStyleA,
        });
      if (!keepSecond)
        sides.push({
          ranges: pairs.map((p) => p.second),
          style: replaceStyleB,
        });
      if (sides.length === 0) continue;
      hits.push({
        node: entry.node,
        spreadNode: resolveCommandSpread(doc, entry.node),
        sides: sides,
      });
    }

    if (totalPairs === 0) {
      const humanize = (v) => {
        if (v === ANY_SENTINEL) return ANY_LABEL;
        if (v === "") return NO_STYLE_LABEL;
        return v;
      };
      const scopeNote =
        scope === SCOPE_STORY
          ? " in the current story"
          : scope === SCOPE_RANGE
            ? " in the current selection"
            : "";
      getApp().alert(
        'No paragraph pairs matched "' +
          humanize(findA) +
          '" \u2192 "' +
          humanize(findB) +
          '"' +
          scopeNote +
          ".",
        "Done",
      );
      return;
    }

    const builder = CompoundCommandBuilder.create();
    let originalSpread = null;
    let activeSpread = null;
    try {
      originalSpread = doc.currentSpread;
      activeSpread = originalSpread;
    } catch (e) {}
    // Starting spread last, so the run ends where it began with the
    // minimum of SDK-mandated spread switches.
    const spreadGroups = groupHitsBySpread(hits, originalSpread);
    let descriptionSet = false;
    for (const group of spreadGroups) {
      // formatText requires the target spread current (else COMMAND_FAILED).
      // Switch once per spread, never back to the active one.
      if (
        group.spreadNode &&
        !isSameSdkNode(group.spreadNode, activeSpread)
      ) {
        builder.addCommand(
          DocumentCommand.createSetCurrentSpread(group.spreadNode),
        );
        activeSpread = group.spreadNode;
      }
      for (const hit of group.hits) {
        for (const side of hit.sides) {
          descriptionSet = addFormatSubCommand(
            builder,
            buildFormatCommand(doc, hit.node, side.ranges, side.style),
            descriptionSet,
          );
        }
      }
    }

    // Ended elsewhere (starting spread held no hits): switch back so the
    // viewport does not move. Skipped otherwise to preserve single-undo.
    if (needsSpreadRestore(originalSpread, activeSpread)) {
      builder.addCommand(
        DocumentCommand.createSetCurrentSpread(originalSpread),
      );
    }

    doc.executeCommand(builder.createCommand());
    // No success alert: redraw is suppressed under a script-owned modal.
    return;
  }
}

main();
