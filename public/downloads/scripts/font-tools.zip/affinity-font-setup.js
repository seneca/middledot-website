/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    affinity-font-setup.js
Description:    Sets up an Affinity Designer document as a font workspace: one artboard per glyph, laid out in rows of 10, with locked metric markers. Artboards read top-to-bottom as Uppercase → Lowercase → Digits → Other in both the spread and the layers panel.

Author:         Les Pruszynski (Middledot)
Version:        1.0.1
Created:        —
Last updated:   07/10/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/




const { Document, NewDocumentOptions } = require('/document');
const { UnitType } = require('/units');
const { Rectangle, Curve, PolyCurve } = require('/geometry');
const { RGBA8 } = require('/colours');
const { CompoundCommandBuilder, DocumentCommand, AddChildNodesCommandBuilder } = require('/commands');
const { ShapeNodeDefinition, PolyCurveNodeDefinition } = require('/nodes');
const { ShapeRectangle } = require('/shapes');
const { FillDescriptor } = require('/fills');
const { Dialog, DialogResult } = require('/dialog');

// ============================================================
// CONFIGURATION
// ============================================================
const UNITS_PER_EM         = 1000;
const BASELINE_FROM_BOTTOM = 200;
const DEFAULT_ADV_WIDTH    = 600;
const DEFAULT_LSB          = 50;
const DEFAULT_RSB          = 550;
const DEFAULT_CAP_HEIGHT   = 700;
const DEFAULT_X_HEIGHT     = 500;
const GAP_BETWEEN_GLYPHS   = 50;
const GAP_BETWEEN_ROWS     = 200;
const GAP_BETWEEN_GROUPS   = 400;
const ARTBOARDS_PER_ROW    = 10;
const MARKER_INSET         = 1;
const LINE_WEIGHT          = 1;

const COLOUR_BASELINE   = [ 80, 130, 200, 255];  // steel blue
const COLOUR_SIDEBEAR   = [200,  70,  70, 255];  // softened red
const COLOUR_XHEIGHT    = [220, 140,  50, 255];  // warm orange
const COLOUR_CAPHEIGHT  = [ 80, 160,  90, 255];  // moss green

// ============================================================
// CHARACTER SETS
// ============================================================
function rangeChars(from, to) {
    const out = [];
    for (let c = from.charCodeAt(0); c <= to.charCodeAt(0); c++) {
        out.push(String.fromCharCode(c));
    }
    return out;
}
const UPPERCASE = rangeChars('A', 'Z');
const LOWERCASE = rangeChars('a', 'z');
const DIGITS    = rangeChars('0', '9');

// Adobe Glyph List names for ASCII punctuation (digits handled separately)
const AGL_NAMES = {
    ' ': 'space',      '!': 'exclam',     '"': 'quotedbl',
    '#': 'numbersign', '$': 'dollar',     '%': 'percent',
    '&': 'ampersand',  "'": 'quotesingle','(': 'parenleft',
    ')': 'parenright', '*': 'asterisk',   '+': 'plus',
    ',': 'comma',      '-': 'hyphen',     '.': 'period',
    '/': 'slash',      ':': 'colon',      ';': 'semicolon',
    '<': 'less',       '=': 'equal',      '>': 'greater',
    '?': 'question',   '@': 'at',         '[': 'bracketleft',
    '\\':'backslash',  ']': 'bracketright','^': 'asciicircum',
    '_': 'underscore', '`': 'grave',      '{': 'braceleft',
    '|': 'bar',        '}': 'braceright', '~': 'asciitilde',
};

function baseGlyphName(ch) {
    if (/^[A-Za-z0-9]$/.test(ch)) return ch;
    if (AGL_NAMES[ch]) return AGL_NAMES[ch];
    const cp = ch.codePointAt(0);
    if (cp <= 0xFFFF) return 'uni' + cp.toString(16).toUpperCase().padStart(4, '0');
    return 'u' + cp.toString(16).toUpperCase().padStart(5, '0');
}

function fullArtboardName(ch) {
    const cp = ch.codePointAt(0);
    const hex = cp.toString(16).toUpperCase().padStart(4, '0');
    return baseGlyphName(ch) + ' (U+' + hex + ')';
}

// Category ordering: uppercase, then lowercase, then digits, then anything else.
// This is the desired top-to-bottom reading order in the layers panel and the
// row order in the spread.
function categoryRank(ch) {
    if (/[A-Z]/.test(ch)) return 0;
    if (/[a-z]/.test(ch)) return 1;
    if (/[0-9]/.test(ch)) return 2;
    return 3;
}

// ============================================================
// DIALOG HELPERS
// ============================================================
function buildDialog() {
    const dlg = Dialog.create('Create Font Project');
    dlg.initialWidth = 350;
    const col = dlg.addColumn();
    
    const idGrp = col.addGroup('Font identity');
    dlg.nameField     = idGrp.addTextBox('Font name', 'My Font');
    dlg.designerField = idGrp.addTextBox('Designer ', '');
    
    const charsGrp = col.addGroup('Characters');
    dlg.charsetRadio = charsGrp.addRadioGroup('Preset',
        ['Uppercase (A-Z)',
         'Lowercase (a-z)',
         'Digits (0-9)',
         'Upper + lower',
         'Upper + lower + digits',
         'Custom (use field below)'],
        4);
    dlg.customField = charsGrp.addTextBox('Custom characters', 'LOGO');
    
    const mGrp = col.addGroup('Glyph cell defaults');
    dlg.advWidthField = mGrp.addUnitValueEditor('Advance width',
        UnitType.Number, UnitType.Number, DEFAULT_ADV_WIDTH, 100, 2000);
    dlg.advWidthField.setPrecision(0);
    
    dlg.showCapCheck   = mGrp.addCheckBox('Show cap-height line', true);
    dlg.capHeightField = mGrp.addUnitValueEditor('Cap-height',
        UnitType.Number, UnitType.Number, DEFAULT_CAP_HEIGHT, 100, 1000);
    dlg.capHeightField.setPrecision(0);
    
    dlg.showXCheck   = mGrp.addCheckBox('Show x-height line', true);
    dlg.xHeightField = mGrp.addUnitValueEditor('x-height',
        UnitType.Number, UnitType.Number, DEFAULT_X_HEIGHT, 100, 1000);
    dlg.xHeightField.setPrecision(0);
    
    return dlg;
}

function resolveCharacters(dlg) {
    const preset = dlg.charsetRadio.selectedIndex;
    let chars = [];
    switch (preset) {
        case 0: chars = UPPERCASE.slice(); break;
        case 1: chars = LOWERCASE.slice(); break;
        case 2: chars = DIGITS.slice(); break;
        case 3: chars = UPPERCASE.concat(LOWERCASE); break;
        case 4: chars = UPPERCASE.concat(LOWERCASE).concat(DIGITS); break;
        case 5: {
            const text = dlg.customField.text || '';
            const seen = new Set();
            for (const c of text) {
                if (!/\s/.test(c) && !seen.has(c)) {
                    seen.add(c); chars.push(c);
                }
            }
            break;
        }
    }
    return chars;
}

function groupChars(chars) {
    const upper = [], lower = [], digit = [], other = [];
    for (const c of chars) {
        if (/[A-Z]/.test(c)) upper.push(c);
        else if (/[a-z]/.test(c)) lower.push(c);
        else if (/[0-9]/.test(c)) digit.push(c);
        else other.push(c);
    }
    return [upper, lower, digit, other].filter(g => g.length > 0);
}

function layoutRows(groups) {
    const rows = [];
    for (let g = 0; g < groups.length; g++) {
        const grp = groups[g];
        for (let i = 0; i < grp.length; i += ARTBOARDS_PER_ROW) {
            rows.push({
                chars: grp.slice(i, i + ARTBOARDS_PER_ROW),
                isNewGroup: (i === 0 && g > 0)
            });
        }
    }
    return rows;
}

// ============================================================
// DOCUMENT CONSTRUCTION
// ============================================================
function buildFontDocument(opts2) {
    const { characters, advWidth, capHeight, xHeight, showCap, showX } = opts2;
    const groups = groupChars(characters);
    if (characters.length === 0) throw new Error('No characters specified');
    const rows = layoutRows(groups);
    
    const cellWidth = advWidth + GAP_BETWEEN_GLYPHS;
    const cellHeight = UNITS_PER_EM;
    const positions = [];
    let y = 0;
    let maxRowWidth = 0;
    for (let r = 0; r < rows.length; r++) {
        const row = rows[r];
        if (r > 0) y += row.isNewGroup ? GAP_BETWEEN_GROUPS : GAP_BETWEEN_ROWS;
        let x = 0;
        for (const ch of row.chars) {
            positions.push({ ch, x, y });
            x += cellWidth;
        }
        const rowWidth = row.chars.length * cellWidth - GAP_BETWEEN_GLYPHS;
        if (rowWidth > maxRowWidth) maxRowWidth = rowWidth;
        y += cellHeight;
    }
    const docWidth = maxRowWidth;
    const docHeight = y;
    
    // Sort the insertion order so the layers panel reads top-to-bottom as
    // Uppercase → Lowercase → Digits → Other, matching the row layout on
    // the spread. Affinity renders tree[0] at the bottom of the panel and
    // tree[last] at the top, so we sort REVERSED: digits go in first, then
    // lowercase, then uppercase, so they end up at the bottom, middle, top
    // of the panel respectively. Within each category, characters are
    // inserted in reverse alphabetical order for the same reason.
    // Each entry keeps its (x, y), so the visual layout is unchanged.
    positions.sort((a, b) => {
        const ra = categoryRank(a.ch), rb = categoryRank(b.ch);
        if (ra !== rb) return rb - ra;
        return a.ch < b.ch ? 1 : a.ch > b.ch ? -1 : 0;
    });
    
    const docOpts = NewDocumentOptions.createDefault();
    docOpts.units = UnitType.Pixel;
    docOpts.width = docWidth;
    docOpts.height = docHeight;
    docOpts.dpi = 1000;
    docOpts.viewDpi = 1000;
    docOpts.isTransparentBackground = false;
    docOpts.createArtboard = false;
    
    const doc = Document.create(docOpts);
    
    // Pass 1: add all artboards atomically (fixes first-artboard quirk)
    const cb = CompoundCommandBuilder.create();
    for (const p of positions) {
        const def = ShapeNodeDefinition.createDefault();
        def.shape = ShapeRectangle.create();
        def.setBoundingRectangle(new Rectangle(p.x, p.y, advWidth, cellHeight));
        cb.addCommand(DocumentCommand.createAddArtboard(def));
    }
    doc.executeCommand(cb.createCommand(), false);
    
    // Pass 2: name + add markers per artboard
    const abs = doc.spreads.first.artboards;
    const lsbOffset = DEFAULT_LSB;
    const rsbOffset = Math.min(DEFAULT_RSB, advWidth - DEFAULT_LSB);
    
    const colBaseline = RGBA8(COLOUR_BASELINE[0], COLOUR_BASELINE[1], COLOUR_BASELINE[2], COLOUR_BASELINE[3]);
    const colSidebear = RGBA8(COLOUR_SIDEBEAR[0], COLOUR_SIDEBEAR[1], COLOUR_SIDEBEAR[2], COLOUR_SIDEBEAR[3]);
    const colXHeight  = RGBA8(COLOUR_XHEIGHT[0],  COLOUR_XHEIGHT[1],  COLOUR_XHEIGHT[2],  COLOUR_XHEIGHT[3]);
    const colCapHt    = RGBA8(COLOUR_CAPHEIGHT[0],COLOUR_CAPHEIGHT[1],COLOUR_CAPHEIGHT[2],COLOUR_CAPHEIGHT[3]);
    
    for (let i = 0; i < positions.length; i++) {
        const ab = abs[i];
        const ch = positions[i].ch;
        ab.node.userDescription = fullArtboardName(ch);
        
        const sb = ab.node.getSpreadBaseBox(false);
        const lsbX = sb.x + lsbOffset;
        const rsbX = sb.x + rsbOffset;
        const topY = sb.y + MARKER_INSET;
        const botY = sb.y + sb.height - MARKER_INSET;
        const baselineY = sb.y + sb.height - BASELINE_FROM_BOTTOM;
        const xHeightY  = baselineY - xHeight;
        const capHtY    = baselineY - capHeight;
        const leftX  = sb.x + MARKER_INSET;
        const rightX = sb.x + sb.width - MARKER_INSET;
        
        function makeLine(label, x1, y1, x2, y2) {
            const pc = PolyCurve.create();
            pc.addCurve(Curve.createLineXY(x1, y1, x2, y2));
            const def = PolyCurveNodeDefinition.createDefault();
            def.setCurves(pc);
            def.userDescription = label;
            return def;
        }
        
        const builder = AddChildNodesCommandBuilder.create();
        builder.setInsertionTarget(ab.node);
        builder.addPolyCurveNode(makeLine('LSB',      lsbX,  topY,    lsbX,   botY));
        builder.addPolyCurveNode(makeLine('RSB',      rsbX,  topY,    rsbX,   botY));
        builder.addPolyCurveNode(makeLine('baseline', leftX, baselineY, rightX, baselineY));
        if (showCap) builder.addPolyCurveNode(makeLine('cap-height', leftX, capHtY,   rightX, capHtY));
        if (showX)   builder.addPolyCurveNode(makeLine('x-height',   leftX, xHeightY, rightX, xHeightY));
        doc.executeCommand(builder.createCommand(false));
        
        // Style by label
        for (const child of ab.node.children) {
            const d = child.userDescription;
            let col = null;
            if (d === 'LSB' || d === 'RSB')     col = colSidebear;
            else if (d === 'baseline')          col = colBaseline;
            else if (d === 'cap-height')        col = colCapHt;
            else if (d === 'x-height')          col = colXHeight;
            if (col) {
                doc.setPenFillDescriptor(col, child);
                doc.setLineWeight(LINE_WEIGHT, child);
                doc.setBrushFillDescriptor(FillDescriptor.createNone(), child);
                child.lock();
            }
        }
    }
    
    // Clear any selection residue left by the marker/lock commands so the
    // Layers panel has nothing to reveal — artboards come up collapsed.
    // (There is no scriptable disclosure state; this is the only lever.)
    const { Selection } = require('/selections');
    doc.executeCommand(DocumentCommand.createSetSelection(Selection.createEmpty(doc)));

    return { doc, glyphCount: positions.length, rowCount: rows.length };
}

function main() {
    const dlg = buildDialog();
    if (dlg.runModal() != DialogResult.Ok) return;
    
    const fontName   = (dlg.nameField.text || '').trim() || 'Untitled Font';
    const designer   = (dlg.designerField.text || '').trim();
    const characters = resolveCharacters(dlg);
    const advWidth   = Math.round(dlg.advWidthField.value);
    const capHeight  = Math.round(dlg.capHeightField.value);
    const xHeight    = Math.round(dlg.xHeightField.value);
    const showCap    = dlg.showCapCheck.value;
    const showX      = dlg.showXCheck.value;
    
    if (characters.length === 0) {
        console.log('No characters chosen — nothing to do.');
        return;
    }
    
    console.log('Creating "' + fontName + '" with ' + characters.length + ' glyphs.');
    const result = buildFontDocument({
        characters, advWidth, capHeight, xHeight, showCap, showX
    });
    console.log('Created document with ' + result.glyphCount + ' artboards in ' + result.rowCount + ' rows.');
}

main();