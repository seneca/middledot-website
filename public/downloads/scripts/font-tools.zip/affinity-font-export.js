/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    affinity-font-export.js
Description:    Reads artboards built by the Create Font Project script, extracts glyph outlines, transforms them into font coordinates, and writes a .otf file to a chosen folder.

Author:         Les Pruszynski (Middledot)
Version:        1.1.0
Created:        —
Last updated:   07/10/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/




const { Buffer } = require('/buffer');
const { File } = require('/fs');
const { app } = require('/application');
const { Document } = require('/document');
const { Dialog, DialogResult } = require('/dialog');

// ============================================================
// CONFIGURATION — SET THIS BEFORE FIRST USE
// Folder where exported .otf files are saved. Replace the
// placeholder below with a real folder on your machine, e.g.
// '/Users/les/Desktop' on Mac or 'C:/Users/Name/Desktop' on
// Windows (forward slashes work on both). The folder MUST be
// allowed under Affinity Settings → File System Access, or every
// export fails with PERMISSION_DENIED. You can still override it
// per-export in the dialog's "Save to folder" field.
// ============================================================
const OUTPUT_FOLDER = 'YOUR-OUTPUT-FOLDER-HERE';

// ============================================================
// OTF / CFF WRITER
// Pure JS — no external dependencies.
// ============================================================

class ByteWriter {
    constructor() { this.bytes = []; }
    get length() { return this.bytes.length; }
    u8(v)  { this.bytes.push(v & 0xFF); }
    u16(v) { this.bytes.push((v >>> 8) & 0xFF, v & 0xFF); }
    i16(v) { this.u16(v < 0 ? v + 0x10000 : v); }
    u24(v) { this.bytes.push((v >>> 16) & 0xFF, (v >>> 8) & 0xFF, v & 0xFF); }
    u32(v) { this.bytes.push((v >>> 24) & 0xFF, (v >>> 16) & 0xFF, (v >>> 8) & 0xFF, v & 0xFF); }
    i32(v) { this.u32(v < 0 ? v + 0x100000000 : v); }
    tag(s) { const p = (s + '    ').substring(0, 4); for (let i = 0; i < 4; i++) this.u8(p.charCodeAt(i)); }
    raw(b) { if (b instanceof ByteWriter) { for (const v of b.bytes) this.bytes.push(v); } else { for (const v of b) this.bytes.push(v); } }
    ascii(s) { for (let i = 0; i < s.length; i++) this.u8(s.charCodeAt(i)); }
    fixed16_16(maj, min) { this.u16(maj); this.u16(min); }
    longDateTime(s) { this.u32(0); this.u32(s); }
    toUint8Array() { return new Uint8Array(this.bytes); }
}

function utf8Encode(str) {
    const b = [];
    for (let i = 0; i < str.length; i++) {
        let c = str.charCodeAt(i);
        if (c < 0x80) b.push(c);
        else if (c < 0x800) { b.push(0xC0|(c>>6)); b.push(0x80|(c&0x3F)); }
        else if (c < 0xD800 || c >= 0xE000) { b.push(0xE0|(c>>12)); b.push(0x80|((c>>6)&0x3F)); b.push(0x80|(c&0x3F)); }
        else { i++; const c2 = str.charCodeAt(i); const cp = 0x10000 + (((c&0x3FF)<<10)|(c2&0x3FF));
               b.push(0xF0|(cp>>18)); b.push(0x80|((cp>>12)&0x3F)); b.push(0x80|((cp>>6)&0x3F)); b.push(0x80|(cp&0x3F)); }
    }
    return new Uint8Array(b);
}

function cffDictInt(w, v) {
    if (v >= -107 && v <= 107) w.u8(v + 139);
    else if (v >= 108 && v <= 1131) { v -= 108; w.u8(247 + (v >> 8)); w.u8(v & 0xFF); }
    else if (v >= -1131 && v <= -108) { v = -v - 108; w.u8(251 + (v >> 8)); w.u8(v & 0xFF); }
    else if (v >= -32768 && v <= 32767) { w.u8(28); w.i16(v); }
    else { w.u8(29); w.i32(v); }
}
function cffDictOp(w, op) { if (op > 255) { w.u8(12); w.u8(op - 1200); } else w.u8(op); }
function csInt(w, v) {
    if (v >= -107 && v <= 107) w.u8(v + 139);
    else if (v >= 108 && v <= 1131) { v -= 108; w.u8(247 + (v >> 8)); w.u8(v & 0xFF); }
    else if (v >= -1131 && v <= -108) { v = -v - 108; w.u8(251 + (v >> 8)); w.u8(v & 0xFF); }
    else if (v >= -32768 && v <= 32767) { w.u8(28); w.i16(v); }
    else throw new Error('CharString int out of range: ' + v);
}

function cffIndex(items) {
    const w = new ByteWriter();
    if (items.length === 0) { w.u16(0); return w; }
    const offsets = [1]; let pos = 1;
    for (const it of items) { pos += it.length; offsets.push(pos); }
    const maxOff = offsets[offsets.length - 1];
    let offSize;
    if (maxOff < 0x100) offSize = 1;
    else if (maxOff < 0x10000) offSize = 2;
    else if (maxOff < 0x1000000) offSize = 3;
    else offSize = 4;
    w.u16(items.length); w.u8(offSize);
    for (const o of offsets) {
        if (offSize === 1) w.u8(o);
        else if (offSize === 2) w.u16(o);
        else if (offSize === 3) w.u24(o);
        else w.u32(o);
    }
    for (const it of items) w.raw(it);
    return w;
}

const UNITS_PER_EM = 1000;

function buildCharString(glyph, nominalWidthX) {
    const w = new ByteWriter();
    csInt(w, glyph.advanceWidth - nominalWidthX);
    let cx = 0, cy = 0;
    if (glyph.contours.length === 0) { w.u8(14); return w.toUint8Array(); }
    for (const contour of glyph.contours) {
        const first = contour[0];
        if (first.type !== 'moveTo') throw new Error('Contour must start with moveTo');
        csInt(w, first.x - cx); csInt(w, first.y - cy);
        w.u8(21); cx = first.x; cy = first.y;
        for (let i = 1; i < contour.length; i++) {
            const op = contour[i];
            if (op.type === 'lineTo') {
                csInt(w, op.x - cx); csInt(w, op.y - cy); w.u8(5);
                cx = op.x; cy = op.y;
            } else if (op.type === 'curveTo') {
                const dx1 = op.x1 - cx, dy1 = op.y1 - cy;
                const dx2 = op.x2 - op.x1, dy2 = op.y2 - op.y1;
                const dx3 = op.x - op.x2, dy3 = op.y - op.y2;
                csInt(w, dx1); csInt(w, dy1); csInt(w, dx2); csInt(w, dy2); csInt(w, dx3); csInt(w, dy3);
                w.u8(8); cx = op.x; cy = op.y;
            } else if (op.type === 'closePath') {
                // implicit in Type 2
            } else throw new Error('Unknown op: ' + op.type);
        }
    }
    w.u8(14);
    return w.toUint8Array();
}

function buildCFF(fontName, glyphs) {
    const predefinedSIDs = { '.notdef': 0, 'A': 34 };
    const customStrings = [];
    function stringSID(s) {
        if (predefinedSIDs[s] !== undefined) return predefinedSIDs[s];
        let idx = customStrings.indexOf(s);
        if (idx < 0) { idx = customStrings.length; customStrings.push(s); }
        return 391 + idx;
    }
    
    const nominalWidthX = 0, defaultWidthX = 0;
    const charStrings = glyphs.map(g => buildCharString(g, nominalWidthX));
    const fontNameSID = stringSID(fontName);
    
    const charsetW = new ByteWriter();
    charsetW.u8(0);
    for (let gid = 1; gid < glyphs.length; gid++) charsetW.u16(stringSID(glyphs[gid].name));
    const charset = charsetW.toUint8Array();
    
    const privW = new ByteWriter();
    cffDictInt(privW, nominalWidthX); cffDictOp(privW, 21);
    cffDictInt(privW, defaultWidthX); cffDictOp(privW, 20);
    const privateDict = privW.toUint8Array();
    const localSubrs = cffIndex([]).toUint8Array();
    const nameIndex = cffIndex([utf8Encode(fontName)]).toUint8Array();
    const stringIndex = cffIndex(customStrings.map(s => utf8Encode(s))).toUint8Array();
    const globalSubrs = cffIndex([]).toUint8Array();
    const charStringsIndex = cffIndex(charStrings).toUint8Array();
    
    function dictInt5(w, v) { w.u8(29); w.i32(v); }
    function emitTopDict(charsetOff, charStringsOff, privateOff) {
        const w = new ByteWriter();
        cffDictInt(w, fontNameSID); cffDictOp(w, 2);
        cffDictInt(w, fontNameSID); cffDictOp(w, 3);
        cffDictInt(w, 0); cffDictInt(w, 0); cffDictInt(w, 1000); cffDictInt(w, 1000); cffDictOp(w, 5);
        dictInt5(w, charsetOff); cffDictOp(w, 15);
        cffDictInt(w, 0); cffDictOp(w, 16);
        dictInt5(w, charStringsOff); cffDictOp(w, 17);
        cffDictInt(w, privateDict.length);
        dictInt5(w, privateOff); cffDictOp(w, 18);
        return w.toUint8Array();
    }
    
    let topDictBytes = emitTopDict(0, 0, 0);
    let topDictIndex = cffIndex([topDictBytes]).toUint8Array();
    
    const headerW = new ByteWriter();
    headerW.u8(1); headerW.u8(0); headerW.u8(4); headerW.u8(4);
    const header = headerW.toUint8Array();
    
    for (let iter = 0; iter < 5; iter++) {
        let off = 0;
        off += header.length; off += nameIndex.length; off += topDictIndex.length;
        off += stringIndex.length; off += globalSubrs.length;
        const offCharStrings = off; off += charStringsIndex.length;
        const offCharset = off; off += charset.length;
        const offPrivate = off; off += privateDict.length;
        
        const newTop = emitTopDict(offCharset, offCharStrings, offPrivate);
        const newIdx = cffIndex([newTop]).toUint8Array();
        if (newIdx.length === topDictIndex.length) {
            topDictIndex = newIdx;
            break;
        }
        topDictIndex = newIdx;
    }
    
    const parts = [header, nameIndex, topDictIndex, stringIndex, globalSubrs, charStringsIndex, charset, privateDict, localSubrs];
    let total = 0; for (const p of parts) total += p.length;
    const out = new Uint8Array(total);
    let pos = 0; for (const p of parts) { out.set(p, pos); pos += p.length; }
    return out;
}

function buildHead(unitsPerEm, xMin, yMin, xMax, yMax) {
    const w = new ByteWriter();
    w.fixed16_16(1, 0); w.fixed16_16(1, 0);
    w.u32(0); w.u32(0x5F0F3CF5); w.u16(0x000B); w.u16(unitsPerEm);
    const SECS_1970_TO_1904 = 2082844800;
    const now = Math.floor(Date.now() / 1000) + SECS_1970_TO_1904;
    w.longDateTime(now); w.longDateTime(now);
    w.i16(xMin); w.i16(yMin); w.i16(xMax); w.i16(yMax);
    w.u16(0); w.u16(8); w.i16(2); w.i16(0); w.i16(0);
    return w.toUint8Array();
}

function buildHhea(asc, desc, lg, maxAdv, numHM) {
    const w = new ByteWriter();
    w.fixed16_16(1, 0); w.i16(asc); w.i16(desc); w.i16(lg); w.u16(maxAdv);
    w.i16(0); w.i16(0); w.i16(maxAdv); w.i16(1); w.i16(0); w.i16(0);
    w.i16(0); w.i16(0); w.i16(0); w.i16(0); w.i16(0); w.u16(numHM);
    return w.toUint8Array();
}

function buildHmtx(glyphs) {
    const w = new ByteWriter();
    for (const g of glyphs) { w.u16(g.advanceWidth); w.i16(0); }
    return w.toUint8Array();
}

function buildMaxpV05(n) { const w = new ByteWriter(); w.u32(0x00005000); w.u16(n); return w.toUint8Array(); }

function buildOS2(asc, desc, lg, glyphs) {
    const w = new ByteWriter();
    w.u16(4); w.i16(500); w.u16(400); w.u16(5); w.u16(0);
    w.i16(650); w.i16(0); w.i16(0); w.i16(140); w.i16(650); w.i16(0); w.i16(0); w.i16(477);
    w.i16(50); w.i16(259); w.i16(0);
    for (let i = 0; i < 10; i++) w.u8(0);
    w.u32(0); w.u32(0); w.u32(0); w.u32(0);
    w.ascii('AFTY'); w.u16(0x40);
    let minU = 0xFFFF, maxU = 0;
    for (const g of glyphs) { if (g.unicode != null) { if (g.unicode < minU) minU = g.unicode; if (g.unicode > maxU) maxU = g.unicode; } }
    if (minU > maxU) { minU = 0; maxU = 0; }
    w.u16(minU); w.u16(maxU);
    w.i16(asc); w.i16(desc); w.i16(lg); w.u16(asc); w.u16(-desc);
    w.u32(0); w.u32(0); w.i16(500); w.i16(700); w.u16(0); w.u16(0x20); w.u16(0);
    return w.toUint8Array();
}

function buildPost() {
    const w = new ByteWriter();
    w.fixed16_16(3, 0); w.fixed16_16(0, 0); w.i16(-100); w.i16(50);
    w.u32(0); w.u32(0); w.u32(0); w.u32(0); w.u32(0);
    return w.toUint8Array();
}

function buildCmap(glyphs) {
    const entries = [];
    for (let gid = 0; gid < glyphs.length; gid++) if (glyphs[gid].unicode != null) entries.push({ u: glyphs[gid].unicode, gid });
    entries.sort((a, b) => a.u - b.u);
    const segCount = entries.length + 1;
    const segCountX2 = segCount * 2;
    let searchRange = 2, entrySelector = 0;
    while (searchRange * 2 <= segCountX2) { searchRange *= 2; entrySelector++; }
    const rangeShift = segCountX2 - searchRange;
    const sub = new ByteWriter();
    sub.u16(4); const lenPos = sub.length; sub.u16(0); sub.u16(0);
    sub.u16(segCountX2); sub.u16(searchRange); sub.u16(entrySelector); sub.u16(rangeShift);
    for (const e of entries) sub.u16(e.u); sub.u16(0xFFFF); sub.u16(0);
    for (const e of entries) sub.u16(e.u); sub.u16(0xFFFF);
    for (const e of entries) { const d = (e.gid - e.u) & 0xFFFF; sub.u16(d); } sub.u16(1);
    for (let i = 0; i < segCount; i++) sub.u16(0);
    const subBytes = sub.toUint8Array();
    const subLen = subBytes.length;
    subBytes[lenPos] = (subLen >> 8) & 0xFF; subBytes[lenPos + 1] = subLen & 0xFF;
    const w = new ByteWriter();
    w.u16(0); w.u16(1); w.u16(3); w.u16(1); w.u32(4 + 8);
    w.raw(subBytes);
    return w.toUint8Array();
}

function buildName(fontName) {
    const entries = [
        { nameID: 1, str: fontName },
        { nameID: 2, str: 'Regular' },
        { nameID: 3, str: 'AffinityExport:' + fontName },
        { nameID: 4, str: fontName },
        { nameID: 5, str: 'Version 1.000' },
        { nameID: 6, str: fontName.replace(/\s+/g, '') },
    ];
    const records = [];
    for (const e of entries) {
        const b = []; for (let i = 0; i < e.str.length; i++) b.push(e.str.charCodeAt(i) & 0xFF);
        records.push({ platformID: 1, encodingID: 0, languageID: 0, nameID: e.nameID, bytes: new Uint8Array(b) });
    }
    for (const e of entries) {
        const b = [];
        for (let i = 0; i < e.str.length; i++) {
            const c = e.str.charCodeAt(i);
            b.push((c >> 8) & 0xFF); b.push(c & 0xFF);
        }
        records.push({ platformID: 3, encodingID: 1, languageID: 0x409, nameID: e.nameID, bytes: new Uint8Array(b) });
    }
    records.sort((a, b) => {
        if (a.platformID !== b.platformID) return a.platformID - b.platformID;
        if (a.encodingID !== b.encodingID) return a.encodingID - b.encodingID;
        if (a.languageID !== b.languageID) return a.languageID - b.languageID;
        return a.nameID - b.nameID;
    });
    let storage = [];
    for (const r of records) { r.offset = storage.length; for (const b of r.bytes) storage.push(b); }
    const w = new ByteWriter();
    w.u16(0); w.u16(records.length); w.u16(6 + records.length * 12);
    for (const r of records) {
        w.u16(r.platformID); w.u16(r.encodingID); w.u16(r.languageID);
        w.u16(r.nameID); w.u16(r.bytes.length); w.u16(r.offset);
    }
    for (const b of storage) w.u8(b);
    return w.toUint8Array();
}

function tableChecksum(bytes) {
    let sum = 0, i = 0;
    while (i + 4 <= bytes.length) {
        const v = (bytes[i] << 24) | (bytes[i+1] << 16) | (bytes[i+2] << 8) | bytes[i+3];
        sum = (sum + (v >>> 0)) >>> 0; i += 4;
    }
    if (i < bytes.length) {
        let last = 0, shift = 24;
        while (i < bytes.length) { last |= bytes[i] << shift; i++; shift -= 8; }
        sum = (sum + (last >>> 0)) >>> 0;
    }
    return sum;
}

function buildOTF(fontName, glyphs) {
    let xMin = 0, yMin = 0, xMax = 0, yMax = 0, hasAny = false, maxAdv = 0;
    for (const g of glyphs) {
        if (g.advanceWidth > maxAdv) maxAdv = g.advanceWidth;
        for (const c of g.contours) for (const op of c) if (op.x != null) {
            if (!hasAny) { xMin = xMax = op.x; yMin = yMax = op.y; hasAny = true; }
            if (op.x < xMin) xMin = op.x; if (op.x > xMax) xMax = op.x;
            if (op.y < yMin) yMin = op.y; if (op.y > yMax) yMax = op.y;
        }
    }
    const asc = 800, desc = -200, lg = 200;
    const tables = {};
    tables['CFF '] = buildCFF(fontName, glyphs);
    tables['OS/2'] = buildOS2(asc, desc, lg, glyphs);
    tables['cmap'] = buildCmap(glyphs);
    tables['head'] = buildHead(UNITS_PER_EM, xMin, yMin, xMax, yMax);
    tables['hhea'] = buildHhea(asc, desc, lg, maxAdv, glyphs.length);
    tables['hmtx'] = buildHmtx(glyphs);
    tables['maxp'] = buildMaxpV05(glyphs.length);
    tables['name'] = buildName(fontName);
    tables['post'] = buildPost();
    const tags = Object.keys(tables).sort();
    const numT = tags.length;
    let sr = 16, es = 0;
    while (sr * 2 <= numT * 16) { sr *= 2; es++; }
    const rs = numT * 16 - sr;
    const dirSize = 12 + numT * 16;
    const offsets = {}; let pos = dirSize;
    for (const t of tags) { offsets[t] = pos; pos += tables[t].length; while (pos % 4 !== 0) pos++; }
    const checksums = {}; for (const t of tags) checksums[t] = tableChecksum(tables[t]);
    const out = new ByteWriter();
    out.u32(0x4F54544F); out.u16(numT); out.u16(sr); out.u16(es); out.u16(rs);
    for (const t of tags) { out.tag(t); out.u32(checksums[t]); out.u32(offsets[t]); out.u32(tables[t].length); }
    for (const t of tags) { out.raw(tables[t]); while (out.length % 4 !== 0) out.u8(0); }
    const fileBytes = out.toUint8Array();
    const fileSum = tableChecksum(fileBytes);
    const adj = (0xB1B0AFBA - fileSum) >>> 0;
    const ho = offsets['head'];
    fileBytes[ho + 8] = (adj >>> 24) & 0xFF;
    fileBytes[ho + 9] = (adj >>> 16) & 0xFF;
    fileBytes[ho + 10] = (adj >>> 8) & 0xFF;
    fileBytes[ho + 11] = adj & 0xFF;
    return fileBytes;
}

// ============================================================
// GLYPH EXTRACTION FROM ARTBOARDS
// ============================================================

const METRIC_NAMES = new Set(['LSB', 'RSB', 'baseline', 'cap-height', 'x-height']);

const PS_NAME = {
    '0': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four',
    '5': 'five', '6': 'six', '7': 'seven','8': 'eight','9': 'nine',
    ' ': 'space', '!': 'exclam', '"': 'quotedbl', '#': 'numbersign',
    '$': 'dollar', '%': 'percent', '&': 'ampersand', "'": 'quotesingle',
    '(': 'parenleft', ')': 'parenright', '*': 'asterisk', '+': 'plus',
    ',': 'comma', '-': 'hyphen', '.': 'period', '/': 'slash',
    ':': 'colon', ';': 'semicolon', '<': 'less', '=': 'equal',
    '>': 'greater', '?': 'question', '@': 'at', '[': 'bracketleft',
    '\\':'backslash', ']': 'bracketright','^': 'asciicircum',
    '_': 'underscore', '`': 'grave', '{': 'braceleft', '|': 'bar',
    '}': 'braceright', '~': 'asciitilde',
};

function postScriptNameFor(ch, cp) {
    if (/^[A-Za-z]$/.test(ch)) return ch;
    if (PS_NAME[ch]) return PS_NAME[ch];
    return 'uni' + cp.toString(16).toUpperCase().padStart(4, '0');
}

function parseArtboardName(name) {
    const i = name.indexOf(' (U+');
    if (i < 0) return null;
    const j = name.indexOf(')', i);
    if (j < 0) return null;
    const hex = name.substring(i + 4, j);
    if (!/^[0-9A-Fa-f]+$/.test(hex)) return null;
    const cp = parseInt(hex, 16);
    return { ch: String.fromCodePoint(cp), codePoint: cp };
}

// FIX: read marker positions in spread coordinates so they match the
// coordinate space we'll get for the glyph artwork via baseToSpreadTransform.
function readMarkers(node) {
    const m = { lsbX: null, rsbX: null, baselineY: null };
    for (const c of node.children) {
        const d = c.userDescription;
        if (!METRIC_NAMES.has(d)) continue;
        const sb = c.getSpreadBaseBox(false);
        if (d === 'LSB') m.lsbX = sb.x;
        else if (d === 'RSB') m.rsbX = sb.x;
        else if (d === 'baseline') m.baselineY = sb.y;
    }
    return m;
}

function lastPoint(ops) {
    for (let i = ops.length - 1; i >= 0; i--) {
        const o = ops[i];
        if (o.type === 'moveTo' || o.type === 'lineTo' || o.type === 'curveTo') return { x: o.x, y: o.y };
    }
    return { x: 0, y: 0 };
}

function extractGlyph(artboard, parsed) {
    const m = readMarkers(artboard.node);
    if (m.lsbX == null || m.rsbX == null || m.baselineY == null) {
        return { error: 'missing required marker' };
    }
    const adv = Math.round(m.rsbX - m.lsbX);
    if (adv <= 0) return { error: 'RSB <= LSB' };
    
    const xf = (x, y) => ({ x: Math.round(x - m.lsbX), y: Math.round(m.baselineY - y) });
    const contours = [];
    
    for (const child of artboard.node.children) {
        if (METRIC_NAMES.has(child.userDescription)) continue;
        let ci = null;
        try { ci = child.curvesInterface; } catch (e) {}
        if (!ci) continue;
        const ppc = ci.polyPolyCurves;
        if (!ppc || ppc.polyCurveCount === 0) continue;
        
        // FIX: convert each polyCurve into spread coordinates via the node's
        // baseToSpreadTransform. getTransformedPolyCurve() does NOT do this —
        // it only applies the embedded domain transform, leaving the curve in
        // the node's local coordinate space. Using it caused every glyph in
        // the font to inherit the first glyph's local origin, which made the
        // exported letters stair-step vertically and crowd horizontally.
        const nodeXform = child.baseToSpreadTransform;
        
        for (let i = 0; i < ppc.polyCurveCount; i++) {
            const pc = ppc.getPolyCurve(i).clone();
            pc.transform(nodeXform);
            
            for (let j = 0; j < pc.curveCount; j++) {
                const curve = pc.at(j);
                if (curve.pointCount < 2) continue;
                const ops = [];
                let firstStart = null;
                for (const bez of curve.beziers) {
                    if (firstStart === null) {
                        firstStart = xf(bez.start.x, bez.start.y);
                        ops.push({ type: 'moveTo', x: firstStart.x, y: firstStart.y });
                    }
                    const end = xf(bez.end.x, bez.end.y);
                    const c1 = xf(bez.c1.x, bez.c1.y);
                    const c2 = xf(bez.c2.x, bez.c2.y);
                    const prev = lastPoint(ops);
                    if (c1.x === prev.x && c1.y === prev.y && c2.x === end.x && c2.y === end.y) {
                        ops.push({ type: 'lineTo', x: end.x, y: end.y });
                    } else {
                        ops.push({ type: 'curveTo',
                                   x1: c1.x, y1: c1.y,
                                   x2: c2.x, y2: c2.y,
                                   x:  end.x, y:  end.y });
                    }
                }
                if (ops.length > 0) {
                    if (curve.isClosed) ops.push({ type: 'closePath' });
                    contours.push(ops);
                }
            }
        }
    }
    
    return {
        name: postScriptNameFor(parsed.ch, parsed.codePoint),
        unicode: parsed.codePoint,
        advanceWidth: adv,
        contours: contours,
    };
}

// ============================================================
// MAIN ENTRY POINT
// ============================================================

function main() {
    const doc = Document.current;
    if (!doc) {
        app.alert('No document is open. Run Create Font Project first.', 'Export OTF');
        return;
    }
    if (doc.spreads.first.artboardCount === 0) {
        app.alert('This document has no artboards. Run Create Font Project first.', 'Export OTF');
        return;
    }
    
    // Dialog: ask for font name + output folder
    const dlg = Dialog.create('Export OTF');
    dlg.initialWidth = 350;
    const col = dlg.addColumn();
    const g = col.addGroup('Font identity');
    dlg.nameField = g.addTextBox('Font name', doc.title || 'My Font');
    dlg.folderField = g.addTextBox('Save to folder', OUTPUT_FOLDER);
    dlg.browseButton = g.addButton('Browse…');
    dlg.browseButton.onClickHandler = function () {
        // TRIAL: no folder picker exists in the SDK, so open the OS file
        // picker and derive the folder from whatever file is chosen.
        // May fail (nested modals) — the manual field always works.
        try {
            const picked = app.chooseFile();
            if (picked) {
                const s = '' + picked;
                const i = Math.max(s.lastIndexOf('/'), s.lastIndexOf('\\'));
                dlg.folderField.text = (i > 0) ? s.substring(0, i) : s;
            }
        } catch (e) {
            console.log('Browse failed, type the folder manually: ' + e.message);
        }
    };
    if (dlg.runModal() != DialogResult.Ok) return;
    
    const fontName = (dlg.nameField.text || '').trim() || 'Untitled';
    let outFolder = (dlg.folderField.text || '').trim();
    if (!outFolder || outFolder === OUTPUT_FOLDER) {
        app.alert('Please set your output folder first.\n\n' +
                  'Type a folder into "Save to folder" (or Browse to one).\n' +
                  'The folder must be allowed under Affinity Settings → File System Access.',
                  'Export OTF');
        return;
    }
    while (outFolder.charAt(outFolder.length - 1) === '/' ||
           outFolder.charAt(outFolder.length - 1) === '\\') {
        outFolder = outFolder.substring(0, outFolder.length - 1);
    }
    
    // Walk artboards
    const glyphs = [];
    const skipped = [];
    
    // Always add .notdef as glyph 0
    glyphs.push({
        name: '.notdef',
        unicode: null,
        advanceWidth: 500,
        contours: [[
            { type: 'moveTo', x: 50, y: 0 },
            { type: 'lineTo', x: 50, y: 700 },
            { type: 'lineTo', x: 450, y: 700 },
            { type: 'lineTo', x: 450, y: 0 },
            { type: 'closePath' },
        ]],
    });
    
    for (const ab of doc.spreads.first.artboards) {
        const name = ab.node.userDescription;
        const parsed = parseArtboardName(name);
        if (!parsed) { skipped.push(name + ' (could not parse name)'); continue; }
        const glyph = extractGlyph(ab, parsed);
        if (glyph.error) { skipped.push(name + ' (' + glyph.error + ')'); continue; }
        if (glyph.contours.length === 0) { skipped.push(name + ' (no artwork drawn)'); continue; }
        glyphs.push(glyph);
    }
    
    if (glyphs.length <= 1) {
        app.alert('No valid glyphs to export.\n\n' +
                  (skipped.length > 0 ? 'Skipped:\n' + skipped.join('\n') : ''),
                  'Export OTF');
        return;
    }
    
    // Build OTF
    let bytes;
    try {
        bytes = buildOTF(fontName, glyphs);
    } catch (e) {
        app.alert('OTF build failed: ' + e.message, 'Export OTF');
        return;
    }
    
    // Write to the chosen folder
    const safeName = fontName.replace(/[^A-Za-z0-9_-]/g, '_');
    const filePath = outFolder + '/' + safeName + '.otf';
    
    try {
        const buf = Buffer.create(bytes.length);
        const arr = buf.array;
        for (let i = 0; i < bytes.length; i++) arr[i] = bytes[i];
        const f = File.create(filePath, 'wb');
        if (!f.isOpen) {
            app.alert('Could not open for writing:\n' + filePath +
                      '\n\nEnable this folder under Affinity Settings → File System Access, ' +
                      'then run the export again.', 'Export OTF');
            return;
        }
        f.write(buf, buf.length);
        f.close();
    } catch (e) {
        app.alert('Failed to write OTF: ' + e.message, 'Export OTF');
        return;
    }
    
    // Report
    let msg = 'Exported ' + (glyphs.length - 1) + ' glyphs to:\n' + filePath;
    if (skipped.length > 0) {
        msg += '\n\nSkipped:\n' + skipped.slice(0, 10).join('\n');
        if (skipped.length > 10) msg += '\n... and ' + (skipped.length - 10) + ' more';
    }
    app.alert(msg, 'Export OTF');
    console.log(msg);
}

main();