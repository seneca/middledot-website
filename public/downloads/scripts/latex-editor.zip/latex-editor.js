/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    latex-editor.js
Description:    Creates LaTeX formulas using MathJax and places them as vector curves in Affinity Publisher. Supports re-editing formulas previously created by this script. Needs tex2svg.bundle.js in a readable folder (set CONFIG.LIBRARY_FOLDER) or on the Desktop.

Author:         Les Pruszynski (Middledot)
Version:        0.9.18
Created:        —
Last updated:   07/10/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/

const { app } = require("/application");
const { File } = require("/fs");
const { Document } = require("/document");
const { Selection } = require("/selections");
const { Dialog, DialogResult } = require("/dialog");
const {
  DocumentCommand,
  AddChildNodesCommandBuilder,
  createCompoundCommand,
  NodeMoveType,
} = require("/commands");
const {
  PolyCurveNodeDefinition,
  ContainerNodeDefinition,
  NodeChildType,
} = require("/nodes");
const { FillDescriptor } = require("/fills");
const { LineStyleDescriptor } = require("/linestyle");
const { Colour, RGBA8 } = require("/colours");
const { Transform, PolyCurve, CurveBuilder } = require("/geometry");
const { TagInterface } = require("/taginterface");
const { TagInterfaceApi } = require("affinity:dom");

// ============================================================
// CONFIGURATION
// Edit these values to customise the script behaviour.
// ============================================================

const CONFIG = {
  // Display name shown in dialog titles and alerts.
  TOOL_NAME: "MathJax Editor",
  TOOL_VERSION: "0.9.18",

  // tex2svg.bundle.js lookup. Leave LIBRARY_FOLDER as "" to look next
  // to this script (works when running from a checkout; Scripts Library
  // installs resolve elsewhere, so they must set a folder below).
  // To use a shared folder, set this to a real folder on your machine
  // (forward slashes work on both Mac and Windows). That folder MUST be
  // allowed under Affinity Settings -> File System Access or reads throw
  // PERMISSION_DENIED.
  // Lookup order: configured folder (if set), script's own folder,
  // then the legacy Desktop copy.
  LIBRARY_FOLDER: "",
  BUNDLE_FILE_NAME: "tex2svg.bundle.js",

  // Typography defaults.
  FONT_SIZES: [8, 10, 11, 12, 14, 18, 24, 36, 48, 72, 96, 144],
  DEFAULT_FONT_SIZE: 12,
  DEFAULT_COLOUR_RGBA: { r: 0, g: 0, b: 0, alpha: 255 },
  DEFAULT_DISPLAY: false,

  // Formula structure. true = merge all glyph outlines into one curve
  // layer (one row in the Layers panel); false = separate editable
  // glyph curves inside a named group (v0.8.0 behaviour).
  DEFAULT_KEEP_SINGLE_OBJECT: true,

  // Empirically calibrated: at 4.0, a 12pt formula matches 12pt body text.
  EM_TO_PT_SCALE: 4.0,

  // Fresh-formula placement: fraction across the visible spread box.
  // Users can override X/Y in the dialog; re-edits keep their position.
  PLACE_FRACTION_X: 0.4,
  PLACE_FRACTION_Y: 0.4,

  // Dialog retry budget. Values persist across retries; Cancel always
  // exits immediately and keeps the original formula untouched.
  MAX_ATTEMPTS: 5,

  // Post-run summary alert. Turn off for silent batch use.
  SUCCESS_ALERT: true,

  // Live canvas preview while the dialog is open. Renders transiently
  // on every change; OK commits for real, Cancel discards. Verified
  // in-app; default on.
  LIVE_PREVIEW: true,
};

const TOOL_NAME = CONFIG.TOOL_NAME;
const TOOL_VERSION = CONFIG.TOOL_VERSION;
const FONT_SIZES = CONFIG.FONT_SIZES;

// Formula tags. The LEGACY keys keep formulas made by older versions
// re-editable; all new formulas are written with the keys above.
const TAG_KEY_SOURCE = "com.lesoie.affinitymathjax.source";
const TAG_KEY_VERSION = "com.lesoie.affinitymathjax.version";
const TAG_KEY_FONT_SIZE = "com.lesoie.affinitymathjax.fontSize";
const TAG_KEY_COLOUR = "com.lesoie.affinitymathjax.colour";
const TAG_KEY_DISPLAY = "com.lesoie.affinitymathjax.display";
const TAG_KEY_SINGLE_OBJECT = "com.lesoie.affinitymathjax.singleObject";

const LEGACY_TAG_KEY_SOURCE = "com.lesoie.affinitykatex.source";
const LEGACY_TAG_KEY_FONT_SIZE = "com.lesoie.affinitykatex.fontSize";
const LEGACY_TAG_KEY_COLOUR = "com.lesoie.affinitykatex.colour";
const LEGACY_TAG_KEY_DISPLAY = "com.lesoie.affinitykatex.display";

// Starter examples shown in the dialog dropdown.
const EXAMPLES = [
  { label: "Keep my text (no example)", code: "" },
  { label: "Basic: E = mc^2", code: "E = mc^2" },
  { label: "Fraction: quadratic formula", code: "x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}" },
  { label: "Integral", code: "\\int_0^{\\infty} e^{-x^2} dx = \\frac{\\sqrt{\\pi}}{2}" },
  { label: "Sum", code: "\\sum_{n=1}^{\\infty} \\frac{1}{n^2} = \\frac{\\pi^2}{6}" },
  { label: "Greek + sub/superscript", code: "\\alpha^2 + \\beta_{ij} = \\gamma^{\\delta}" },
  { label: "Matrix", code: "\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}" },
  { label: "Chemistry: \\ce", code: "\\ce{H2O -> H+ + OH-}" },
];

function defaultFontSizeIndex() {
  const i = FONT_SIZES.indexOf(CONFIG.DEFAULT_FONT_SIZE);
  return i >= 0 ? i : FONT_SIZES.indexOf(12);
}

function log(msg) {
  console.log("[mathjax] " + msg);
}

// ============================================================
// Script location (for the co-located bundle fallback)
// ============================================================

// Folder this script was loaded from, e.g. ".../scripts/latex-editor".
// Proven pattern from smart-recto-verso.js.
function scriptFolder() {
  try {
    const sp = app.scriptPath;
    if (sp) {
      const i = sp.lastIndexOf("/");
      if (i > 0) return sp.substring(0, i);
    }
  } catch (e) {
    /* ignore — falls back to Desktop below */
  }
  return null;
}

function candidateBundlePaths() {
  const paths = [];
  // 1) Dedicated shared library folder (preferred).
  if (CONFIG.LIBRARY_FOLDER) {
    paths.push(CONFIG.LIBRARY_FOLDER + "/" + CONFIG.BUNDLE_FILE_NAME);
  }
  // 2) Same folder as this script (portable fallback).
  const folder = scriptFolder();
  if (folder) paths.push(folder + "/" + CONFIG.BUNDLE_FILE_NAME);
  // 3) Legacy Desktop copy (v0.7.x location).
  try {
    const desktop = app.userDesktopPath;
    if (desktop) paths.push(desktop + "/" + CONFIG.BUNDLE_FILE_NAME);
  } catch (e) {
    /* ignore */
  }
  return paths;
}

// ============================================================
// MathJax bundle (cached, loaded lazily on first render)
// ============================================================

let cachedTex2Svg = null;
let resolvedBundlePath = null;

function readBundleSource() {
  const candidates = candidateBundlePaths();
  let lastError = null;
  for (const p of candidates) {
    try {
      const buf = File.readAll(p);
      resolvedBundlePath = p;
      try {
        return buf.toString("utf8");
      } catch (e) {
        let s = "";
        for (let i = 0; i < buf.length; i++) s += String.fromCharCode(buf[i]);
        return s;
      }
    } catch (e) {
      lastError = e;
      log("Bundle not readable at " + p + ": " + (e && e.message ? e.message : String(e)));
    }
  }
  const where = candidates.length > 0 ? candidates.join("\n  ") : "(no candidate paths)";
  const reason = lastError && lastError.message ? lastError.message : String(lastError);
  const configuredHint = CONFIG.LIBRARY_FOLDER
    ? "Set CONFIG.LIBRARY_FOLDER to the folder holding tex2svg.bundle.js, or "
    : "Set CONFIG.LIBRARY_FOLDER (top of the script) to the folder holding tex2svg.bundle.js, or ";
  throw new Error(
    "The MathJax library (tex2svg.bundle.js) could not be read.\n\n" +
      "Looked in:\n  " + where + "\n\n" +
      "Fix: " + configuredHint +
      "copy it to your Desktop — " +
      "then allow that folder in " +
      "Affinity Settings -> File System Access and run again.\n\n" +
      "Note: 'next to this script' means Affinity's internal Scripts " +
      "Library store for Library installs, not your download folder.\n\n" +
      "Technical detail: " + reason,
  );
}

// Fail-fast setup check: run before any dialog, so a broken library
// setup reports instructions instead of failing after the dialog.
function checkBundleSetup() {
  try {
    readBundleSource();
    return true;
  } catch (err) {
    const msg = err && err.message ? err.message : String(err);
    log("Setup check failed: " + msg);
    app.alert(
      "First-time setup needed (once per machine):\n\n" +
        "1. Keep tex2svg.bundle.js in a permanent folder.\n" +
        "2. Set CONFIG.LIBRARY_FOLDER (top of the script) to that folder.\n" +
        "3. Allow the folder in Affinity Settings -> File System Access.\n\n" +
        msg,
      TOOL_NAME + " — setup",
    );
    return false;
  }
}

function getTex2Svg() {
  if (cachedTex2Svg) return cachedTex2Svg;
  log("Loading MathJax bundle...");
  const src = readBundleSource();
  const sandbox = {};
  const fakeModule = { exports: {} };
  const factory = new Function(
    "globalThis",
    "global",
    "self",
    "window",
    "module",
    "exports",
    src + '\n;return (typeof tex2svg !== "undefined") ? tex2svg : null;',
  );
  cachedTex2Svg =
    factory(
      sandbox,
      sandbox,
      sandbox,
      sandbox,
      fakeModule,
      fakeModule.exports,
    ) ||
    sandbox.tex2svg ||
    (fakeModule.exports && fakeModule.exports.tex2svg);
  if (typeof cachedTex2Svg !== "function") {
    throw new Error(
      "tex2svg.bundle.js loaded but did not provide a tex2svg function " +
        "(looked in globalThis + module.exports). The bundle may be corrupt — " +
        "rebuild it from tex2svg.entry.js (see folder notes) and try again.",
    );
  }
  log("MathJax bundle ready (" + resolvedBundlePath + ")");
  return cachedTex2Svg;
}

// ============================================================
// Tags (new keys, legacy KaTeX keys readable)
// ============================================================

function tagInterfaceFor(node) {
  try {
    return new TagInterface(TagInterfaceApi.fromNode(node.handle));
  } catch (e) {
    return null;
  }
}

function readTagValue(node, key) {
  const ti = tagInterfaceFor(node);
  if (!ti) return null;
  try {
    if (ti.hasKey(key)) return ti.getValueForKey(key);
  } catch (e) {
    /* ignore */
  }
  return null;
}

function readTagWithLegacy(node, key, legacyKey) {
  const v = readTagValue(node, key);
  if (v != null) return v;
  if (legacyKey) return readTagValue(node, legacyKey);
  return null;
}

function findOurFormulaAncestor(node) {
  let cur = node;
  let safety = 16;
  while (cur && safety-- > 0) {
    let v = readTagValue(cur, TAG_KEY_SOURCE);
    if (v == null) v = readTagValue(cur, LEGACY_TAG_KEY_SOURCE);
    if (v != null) return { node: cur, source: v };
    try {
      cur = cur.parent;
    } catch (e) {
      return null;
    }
  }
  return null;
}

function readFormulaSettings(formulaNode) {
  const settings = {
    fontSize: CONFIG.DEFAULT_FONT_SIZE,
    colourRGBA: {
      r: CONFIG.DEFAULT_COLOUR_RGBA.r,
      g: CONFIG.DEFAULT_COLOUR_RGBA.g,
      b: CONFIG.DEFAULT_COLOUR_RGBA.b,
      alpha: CONFIG.DEFAULT_COLOUR_RGBA.alpha,
    },
    display: !!CONFIG.DEFAULT_DISPLAY,
    keepSingleObject: !!CONFIG.DEFAULT_KEEP_SINGLE_OBJECT,
  };
  const fs = readTagWithLegacy(formulaNode, TAG_KEY_FONT_SIZE, LEGACY_TAG_KEY_FONT_SIZE);
  if (fs != null) {
    const n = parseInt(fs, 10);
    if (!isNaN(n) && n > 0) settings.fontSize = n;
  }
  const col = readTagWithLegacy(formulaNode, TAG_KEY_COLOUR, LEGACY_TAG_KEY_COLOUR);
  if (col != null) {
    const parts = String(col).split(",");
    if (parts.length === 4) {
      settings.colourRGBA = {
        r: parseInt(parts[0], 10) | 0,
        g: parseInt(parts[1], 10) | 0,
        b: parseInt(parts[2], 10) | 0,
        alpha: parseInt(parts[3], 10) | 0,
      };
    }
  }
  const disp = readTagWithLegacy(formulaNode, TAG_KEY_DISPLAY, LEGACY_TAG_KEY_DISPLAY);
  if (disp != null) settings.display = String(disp) === "true";
  // No legacy key — new in 0.8.2. Absent tag keeps the CONFIG default,
  // so pre-0.8.2 formulas re-edit as multi-curve groups unless ticked.
  const so = readTagValue(formulaNode, TAG_KEY_SINGLE_OBJECT);
  if (so != null) settings.keepSingleObject = String(so) === "true";
  return settings;
}

function settingsToTagStrings(settings) {
  return {
    fontSize: String(settings.fontSize),
    colour:
      String(settings.colourRGBA.r) +
      "," +
      String(settings.colourRGBA.g) +
      "," +
      String(settings.colourRGBA.b) +
      "," +
      String(settings.colourRGBA.alpha),
    display: settings.display ? "true" : "false",
    singleObject: settings.keepSingleObject ? "true" : "false",
  };
}

// ============================================================
// LaTeX normalisation
// ============================================================

function normaliseLatex(s) {
  if (!s) return "";
  s = String(s).trim();
  // Pasted JSON-escaped source (\\alpha) -> \alpha, but only when it
  // looks like escaping rather than an intentional line break (\\).
  if (/\\\\[a-zA-Z]/.test(s)) {
    s = s.replace(/\\\\/g, "\\");
  }
  return s;
}

// ============================================================
// SVG sizing post-process
// ============================================================

function rewriteSvgSize(svg, userFontSizePt) {
  const exInPt = 0.5 * userFontSizePt * CONFIG.EM_TO_PT_SCALE;

  function replaceAttr(svgIn, attrName) {
    const re = new RegExp(attrName + '="([0-9]*\\.?[0-9]+)ex"', "g");
    return svgIn.replace(re, function (_, num) {
      const ptVal = (parseFloat(num) * exInPt).toFixed(3);
      return attrName + '="' + ptVal + 'pt"';
    });
  }

  let out = svg;
  out = replaceAttr(out, "width");
  out = replaceAttr(out, "height");
  out = out.replace(
    /vertical-align:\s*(-?[0-9]*\.?[0-9]+)ex/g,
    function (_, num) {
      return "vertical-align: " + (parseFloat(num) * exInPt).toFixed(3) + "pt";
    },
  );
  return out;
}

// ============================================================
// In-memory MathJax SVG parser (no helper document)
//
// MathJax's SVG dialect (empirically inventoried from live tex2svg()
// output, mathjax-full 3.2.2, fontCache "local") is narrow:
// - glyphs as <path d="..."/> inside <defs>, placed via <use href="#id">
//   (no transform or translate-only);
// - path commands M L H V Q T Z, absolute, Z-terminated (relative,
//   C S A forms parsed anyway for future-proofing);
// - <g transform="translate(...)"> nesting, single scale(s) for scripts,
//   one root scale(1,-1) y-flip; <rect> fraction rules/overbars,
//   <line> menclose diagonals, <polygon>/<polyline> frames.
// - nested <svg> viewports (extensible-arrow shafts, brace segments):
//   x/y offset composed, content clipped to the viewBox rect before
//   mapping (Sutherland-Hodgman + cubic subdivision, so caps survive).
// - sibling butt joints: shafts trimmed back to head-stub edges in the
//   same assembly, so merged fills have no overlap to knock out.
//   (Brace center-tip curls may still interleave; bbox-pinned residual,
//   union-class, not trim-safe.)
// - sibling butt joints: shafts trimmed back to head-stub edges in the
//   same assembly, so merged fills have no overlap to knock out.
// - <text> elements (glyphs missing from the SVG font: upright Greek,
//   ℃, €, \unicode) carry no outlines — counted in dropped.text so the
//   run warns instead of silently skipping characters.
// Stroked frames (menclose box/cancel) are treated as filled loops —
// same as today's harvest-then-solid-fill behaviour (parity, not a fix).
// vertical-align is ignored — Affinity's importer ignores it too, so
// harvested geometry never had it either.
// ==== MJX-PURE-START ====
// Everything between the MJX-PURE markers is Affinity-SDK-free and is
// executed under bun by the offline validation harness. Keep it that way.

function mjxSplitNums(s) {
  const out = [];
  const re = /[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/g;
  let m;
  while ((m = re.exec(s || '')) !== null) out.push(parseFloat(m[0]));
  return out;
}

function mjxParsePt(v) {
  if (v == null) return NaN;
  const m = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(String(v));
  return m ? parseFloat(m[0]) : NaN;
}

function mjxAttr(tag, name) {
  // Leading \s so 'd' never matches the tail of 'id=' (and friends).
  const re = new RegExp('\\s' + name + '\\s*=\\s*"([^"]*)"');
  const m = re.exec(tag);
  return m ? m[1] : null;
}

function mjxTokenizePath(d) {
  const tokens = [];
  const re = /([A-Za-z])|([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)/g;
  let m;
  while ((m = re.exec(d)) !== null) {
    if (m[1] !== undefined) tokens.push({ type: 'cmd', val: m[1] });
    else tokens.push({ type: 'num', val: parseFloat(m[2]) });
  }
  return tokens;
}

// SVG F.6.5 endpoint -> bezier segments (each <= 90 degrees).
function mjxArcToBeziers(x0, y0, rx, ry, phiDeg, largeArc, sweep, x1, y1) {
  const out = [];
  rx = Math.abs(rx);
  ry = Math.abs(ry);
  if (rx < 1e-9 || ry < 1e-9) return out;
  const phi = phiDeg * Math.PI / 180;
  const cosPhi = Math.cos(phi);
  const sinPhi = Math.sin(phi);
  const dx = (x0 - x1) / 2;
  const dy = (y0 - y1) / 2;
  const x1p = cosPhi * dx + sinPhi * dy;
  const y1p = -sinPhi * dx + cosPhi * dy;
  const lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
  if (lam > 1) {
    const s = Math.sqrt(lam);
    rx *= s;
    ry *= s;
  }
  const num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
  const den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
  let co = 0;
  if (den > 1e-12) co = Math.sqrt(Math.max(0, num / den));
  if (!!largeArc === !!sweep) co = -co;
  const cxp = (co * rx * y1p) / ry;
  const cyp = (-co * ry * x1p) / rx;
  const cx = cosPhi * cxp - sinPhi * cyp + (x0 + x1) / 2;
  const cy = sinPhi * cxp + cosPhi * cyp + (y0 + y1) / 2;
  return mjxArcSegments(cx, cy, rx, ry, cosPhi, sinPhi, x1p, y1p, cxp, cyp, sweep, x0, y0);
}

function mjxArcSegments(cx, cy, rx, ry, cosPhi, sinPhi, x1p, y1p, cxp, cyp, sweep, x0, y0) {
  const out = [];
  function vAngle(ux, uy, vx, vy) {
    const dot = ux * vx + uy * vy;
    const len = Math.sqrt((ux * ux + uy * uy) * (vx * vx + vy * vy)) || 1;
    let a = Math.acos(Math.min(1, Math.max(-1, dot / len)));
    if (ux * vy - uy * vx < 0) a = -a;
    return a;
  }
  const th1 = vAngle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
  let dth = vAngle(
    (x1p - cxp) / rx, (y1p - cyp) / ry,
    (-x1p - cxp) / rx, (-y1p - cyp) / ry,
  );
  const TWO_PI = Math.PI * 2;
  dth = dth % TWO_PI;
  if (!sweep && dth > 0) dth -= TWO_PI;
  else if (!!sweep && dth < 0) dth += TWO_PI;
  const segs = Math.max(1, Math.ceil(Math.abs(dth) / (Math.PI / 2)));
  const delta = dth / segs;
  const alpha = (4 / 3) * Math.tan(delta / 4);
  function deriv(t) {
    return [
      -rx * cosPhi * Math.sin(t) - ry * sinPhi * Math.cos(t),
      -rx * sinPhi * Math.sin(t) + ry * cosPhi * Math.cos(t),
    ];
  }
  function epoint(t) {
    return [
      cx + rx * (cosPhi * Math.cos(t) - sinPhi * Math.sin(t)),
      cy + ry * (sinPhi * Math.cos(t) + cosPhi * Math.sin(t)),
    ];
  }
  let th = th1;
  let px = x0;
  let py = y0;
  for (let sgi = 0; sgi < segs; sgi++) {
    const th2 = th + delta;
    const e2 = epoint(th2);
    const d1 = deriv(th);
    const d2 = deriv(th2);
    out.push([
      px + alpha * d1[0], py + alpha * d1[1],
      e2[0] - alpha * d2[0], e2[1] - alpha * d2[1],
      e2[0], e2[1],
    ]);
    px = e2[0];
    py = e2[1];
    th = th2;
  }
  return out;
}

// Path data -> absolute-unit op list. Q/T become cubics (same math as
// barcode svgPathToCurves); S/C pass through; Z stays Z.
function mjxParsePathOps(d) {
  const tokens = mjxTokenizePath(d);
  const ops = [];
  let i = 0;
  let cmd = '';
  let curX = 0;
  let curY = 0;
  let startX = 0;
  let startY = 0;
  let qcx = 0;
  let qcy = 0;
  let ccx = 0;
  let ccy = 0;
  let lastSeg = '';

  function needNum() {
    if (i >= tokens.length || tokens[i].type !== 'num' || isNaN(tokens[i].val)) {
      throw new Error(
        'Bad SVG path data (number expected near token ' + i + '): ' +
          String(d).substring(0, 80),
      );
    }
    return tokens[i++].val;
  }

  while (i < tokens.length) {
    if (tokens[i].type === 'cmd') {
      cmd = tokens[i].val;
      i++;
      if ('MmLlHhVvCcSsQqTtAaZz'.indexOf(cmd) < 0) {
        throw new Error(
          'Unsupported SVG path command "' + cmd + '" in: ' +
            String(d).substring(0, 80),
        );
      }
      if (cmd === 'Z' || cmd === 'z') {
        ops.push({ t: 'Z', p: [] });
        curX = startX;
        curY = startY;
        lastSeg = '';
        continue;
      }
    } else if (cmd === '') {
      throw new Error(
        'Bad SVG path data (must start with a command): ' +
          String(d).substring(0, 80),
      );
    } else if (cmd === 'Z' || cmd === 'z') {
      cmd = 'M'; // lenient: numbers after Z open a new subpath
    }
    const rel = cmd !== cmd.toUpperCase();
    const C = cmd.toUpperCase();
    if (C === 'M') {
      const x = needNum();
      const y = needNum();
      const ax = rel ? curX + x : x;
      const ay = rel ? curY + y : y;
      ops.push({ t: 'M', p: [ax, ay] });
      curX = ax;
      curY = ay;
      startX = ax;
      startY = ay;
      lastSeg = '';
      cmd = rel ? 'l' : 'L';
    } else if (C === 'L') {
      const x = needNum();
      const y = needNum();
      const ax = rel ? curX + x : x;
      const ay = rel ? curY + y : y;
      ops.push({ t: 'L', p: [ax, ay] });
      curX = ax;
      curY = ay;
      lastSeg = '';
    } else if (C === 'H') {
      const x = needNum();
      const ax = rel ? curX + x : x;
      ops.push({ t: 'L', p: [ax, curY] });
      curX = ax;
      lastSeg = '';
    } else if (C === 'V') {
      const y = needNum();
      const ay = rel ? curY + y : y;
      ops.push({ t: 'L', p: [curX, ay] });
      curY = ay;
      lastSeg = '';
    } else if (C === 'C') {
      const x1 = needNum();
      const y1 = needNum();
      const x2 = needNum();
      const y2 = needNum();
      const x = needNum();
      const y = needNum();
      const a1x = rel ? curX + x1 : x1;
      const a1y = rel ? curY + y1 : y1;
      const a2x = rel ? curX + x2 : x2;
      const a2y = rel ? curY + y2 : y2;
      const ax = rel ? curX + x : x;
      const ay = rel ? curY + y : y;
      ops.push({ t: 'C', p: [a1x, a1y, a2x, a2y, ax, ay] });
      ccx = a2x;
      ccy = a2y;
      curX = ax;
      curY = ay;
      lastSeg = 'C';
    } else if (C === 'S') {
      const x2 = needNum();
      const y2 = needNum();
      const x = needNum();
      const y = needNum();
      let a1x = curX;
      let a1y = curY;
      if (lastSeg === 'C' || lastSeg === 'S') {
        a1x = 2 * curX - ccx;
        a1y = 2 * curY - ccy;
      }
      const a2x = rel ? curX + x2 : x2;
      const a2y = rel ? curY + y2 : y2;
      const ax = rel ? curX + x : x;
      const ay = rel ? curY + y : y;
      ops.push({ t: 'C', p: [a1x, a1y, a2x, a2y, ax, ay] });
      ccx = a2x;
      ccy = a2y;
      curX = ax;
      curY = ay;
      lastSeg = 'S';
    } else if (C === 'Q') {
      const cx = needNum();
      const cy = needNum();
      const x = needNum();
      const y = needNum();
      const acx = rel ? curX + cx : cx;
      const acy = rel ? curY + cy : cy;
      const ax = rel ? curX + x : x;
      const ay = rel ? curY + y : y;
      const c0x = curX + (2 / 3) * (acx - curX);
      const c0y = curY + (2 / 3) * (acy - curY);
      const c1x = ax + (2 / 3) * (acx - ax);
      const c1y = ay + (2 / 3) * (acy - ay);
      ops.push({ t: 'C', p: [c0x, c0y, c1x, c1y, ax, ay] });
      qcx = acx;
      qcy = acy;
      curX = ax;
      curY = ay;
      lastSeg = 'Q';
    } else if (C === 'T') {
      const x = needNum();
      const y = needNum();
      let acx = curX;
      let acy = curY;
      if (lastSeg === 'Q' || lastSeg === 'T') {
        acx = 2 * curX - qcx;
        acy = 2 * curY - qcy;
      }
      const ax = rel ? curX + x : x;
      const ay = rel ? curY + y : y;
      const c0x = curX + (2 / 3) * (acx - curX);
      const c0y = curY + (2 / 3) * (acy - curY);
      const c1x = ax + (2 / 3) * (acx - ax);
      const c1y = ay + (2 / 3) * (acy - ay);
      ops.push({ t: 'C', p: [c0x, c0y, c1x, c1y, ax, ay] });
      qcx = acx;
      qcy = acy;
      curX = ax;
      curY = ay;
      lastSeg = 'T';
    } else if (C === 'A') {
      const rx = needNum();
      const ry = needNum();
      const phi = needNum();
      const laf = needNum();
      const sf = needNum();
      const x = needNum();
      const y = needNum();
      const ax = rel ? curX + x : x;
      const ay = rel ? curY + y : y;
      const segs = mjxArcToBeziers(curX, curY, rx, ry, phi, laf !== 0, sf !== 0, ax, ay);
      if (segs.length === 0) {
        ops.push({ t: 'L', p: [ax, ay] });
      } else {
        for (let si = 0; si < segs.length; si++) ops.push({ t: 'C', p: segs[si] });
      }
      curX = ax;
      curY = ay;
      lastSeg = '';
    }
  }
  return ops;
}

// Affine CTMs as {a,b,c,d,e,f}: x' = a*x + c*y + e, y' = b*x + d*y + f.
// mjxMul(m1, m2) returns C with C(p) = m1(m2(p)).
function mjxIdentity() {
  return { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 };
}

function mjxMul(m1, m2) {
  return {
    a: m1.a * m2.a + m1.c * m2.b,
    b: m1.b * m2.a + m1.d * m2.b,
    c: m1.a * m2.c + m1.c * m2.d,
    d: m1.b * m2.c + m1.d * m2.d,
    e: m1.a * m2.e + m1.c * m2.f + m1.e,
    f: m1.b * m2.e + m1.d * m2.f + m1.f,
  };
}

function mjxApply(m, x, y) {
  return [m.a * x + m.c * y + m.e, m.b * x + m.d * y + m.f];
}

function mjxTranslateM(tx, ty) {
  return { a: 1, b: 0, c: 0, d: 1, e: tx, f: ty || 0 };
}

function mjxScaleM(sx, sy) {
  return { a: sx, b: 0, c: 0, d: sy, e: 0, f: 0 };
}

function mjxRotateM(deg) {
  const r = deg * Math.PI / 180;
  const co = Math.cos(r);
  const si = Math.sin(r);
  return { a: co, b: si, c: -si, d: co, e: 0, f: 0 };
}

function mjxParseTransformList(str) {
  let m = mjxIdentity();
  if (!str) return m;
  const re = /([a-zA-Z]+)\s*\(([^)]*)\)/g;
  let t;
  while ((t = re.exec(str)) !== null) {
    const name = t[1];
    const args = mjxSplitNums(t[2]);
    let local = null;
    if (name === 'translate') {
      local = mjxTranslateM(args.length > 0 ? args[0] : 0, args.length > 1 ? args[1] : 0);
    } else if (name === 'scale') {
      const sx = args.length > 0 ? args[0] : 1;
      local = mjxScaleM(sx, args.length > 1 ? args[1] : sx);
    } else if (name === 'rotate') {
      const r = mjxRotateM(args.length > 0 ? args[0] : 0);
      if (args.length > 2) {
        local = mjxMul(
          mjxTranslateM(args[1], args[2]),
          mjxMul(r, mjxTranslateM(-args[1], -args[2])),
        );
      } else {
        local = r;
      }
    } else if (name === 'matrix' && args.length >= 6) {
      local = { a: args[0], b: args[1], c: args[2], d: args[3], e: args[4], f: args[5] };
    } else {
      throw new Error(
        'Unsupported SVG transform "' + name + '" in: ' + String(str).substring(0, 80),
      );
    }
    m = mjxMul(m, local);
  }
  return m;
}

function mjxTransformOps(ops, m) {
  const out = [];
  for (let i = 0; i < ops.length; i++) {
    const op = ops[i];
    if (op.t === 'Z') {
      out.push({ t: 'Z', p: [] });
      continue;
    }
    const q = [];
    for (let k = 0; k < op.p.length; k += 2) {
      const r = mjxApply(m, op.p[k], op.p[k + 1]);
      q.push(r[0], r[1]);
    }
    out.push({ t: op.t, p: q });
  }
  return out;
}

function mjxRectOps(x, y, w, h) {
  return [
    { t: 'M', p: [x, y] },
    { t: 'L', p: [x + w, y] },
    { t: 'L', p: [x + w, y + h] },
    { t: 'L', p: [x, y + h] },
    { t: 'Z', p: [] },
  ];
}

// Stroked rect outline (fill="none") as a ring: outer loop expanded by
// half the stroke width, inner loop shrunk by half (SVG strokes center
// on the path). Under merged even-odd fill the pair resolves to an
// outline band instead of a solid slab. Falls back to null when the
// stroke swallows the rect (degenerate inner loop).
function mjxRectRingOps(x, y, w, h, sw) {
  if (!(sw > 0) || !(w > 0) || !(h > 0)) return null;
  const o = sw / 2;
  const ix = x + o;
  const iy = y + o;
  const iw = w - sw;
  const ih = h - sw;
  if (!(iw > 0) || !(ih > 0)) return null;
  return [
    { t: 'M', p: [x - o, y - o] },
    { t: 'L', p: [x + w + o, y - o] },
    { t: 'L', p: [x + w + o, y + h + o] },
    { t: 'L', p: [x - o, y + h + o] },
    { t: 'Z', p: [] },
    { t: 'M', p: [ix, iy] },
    { t: 'L', p: [ix + iw, iy] },
    { t: 'L', p: [ix + iw, iy + ih] },
    { t: 'L', p: [ix, iy + ih] },
    { t: 'Z', p: [] },
  ];
}

// Points-list shapes (<polygon> closed, <polyline> open) as ops.
// Returns null when fewer than 2 usable points.
function mjxPolyOps(points, closed) {
  const pts = [];
  for (let k = 0; k + 1 < points.length; k += 2) {
    const x = points[k];
    const y = points[k + 1];
    if (isNaN(x) || isNaN(y)) return null;
    pts.push([x, y]);
  }
  if (pts.length < 2) return null;
  const ops = [{ t: 'M', p: [pts[0][0], pts[0][1]] }];
  for (let j = 1; j < pts.length; j++) ops.push({ t: 'L', p: [pts[j][0], pts[j][1]] });
  if (closed) ops.push({ t: 'Z', p: [] });
  return ops;
}

// Stroked <line> as a filled parallelogram (stroke-width across the line).
// Returns null when degenerate.
function mjxLineOps(x1, y1, x2, y2, w) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.sqrt(dx * dx + dy * dy);
  if (!(len > 1e-9) || !(w > 0)) return null;
  const nx = (-dy / len) * (w / 2);
  const ny = (dx / len) * (w / 2);
  return [
    { t: 'M', p: [x1 + nx, y1 + ny] },
    { t: 'L', p: [x2 + nx, y2 + ny] },
    { t: 'L', p: [x2 - nx, y2 - ny] },
    { t: 'L', p: [x1 - nx, y1 - ny] },
    { t: 'Z', p: [] },
  ];
}

// ---- axis-aligned rect clipping (for nested-svg viewports) ----

function mjxPointInRect(p, r) {
  return p[0] >= r.x0 && p[0] <= r.x1 && p[1] >= r.y0 && p[1] <= r.y1;
}

// Liang-Barsky: visible portion of p->q inside r as [q0, q1], or null.
function mjxClipLine(p, q, r) {
  let t0 = 0;
  let t1 = 1;
  const dx = q[0] - p[0];
  const dy = q[1] - p[1];
  const ps = [-dx, dx, -dy, dy];
  const qs = [p[0] - r.x0, r.x1 - p[0], p[1] - r.y0, r.y1 - p[1]];
  for (let e = 0; e < 4; e++) {
    const pn = ps[e];
    const qn = qs[e];
    if (Math.abs(pn) < 1e-12) {
      if (qn < 0) return null;
    } else {
      const t = qn / pn;
      if (pn < 0) {
        if (t > t1) return null;
        if (t > t0) t0 = t;
      } else {
        if (t < t0) return null;
        if (t < t1) t1 = t;
      }
    }
  }
  if (t0 > t1) return null;
  return [
    [p[0] + t0 * dx, p[1] + t0 * dy],
    [p[0] + t1 * dx, p[1] + t1 * dy],
  ];
}

function mjxCubicPoint(p0, p1, p2, p3, t) {
  const u = 1 - t;
  const a = u * u * u;
  const b = 3 * u * u * t;
  const c = 3 * u * t * t;
  const d = t * t * t;
  return [
    a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0],
    a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1],
  ];
}

function mjxSplitCubicAt(p0, p1, p2, p3, t) {
  function lerp(a, b) {
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
  }
  const q0 = lerp(p0, p1);
  const q1 = lerp(p1, p2);
  const q2 = lerp(p2, p3);
  const r0 = lerp(q0, q1);
  const r1 = lerp(q1, q2);
  const s = lerp(r0, r1);
  return [
    [p0, q0, r0, s],
    [s, r1, q2, p3],
  ];
}

// Inside parameter spans of one cubic vs rect (recursive subdivision).
// Returns sorted merged [t0, t1] spans.
function mjxCubicSpans(p0, p1, p2, p3, r, depth) {
  const bx0 = Math.min(p0[0], p1[0], p2[0], p3[0]);
  const bx1 = Math.max(p0[0], p1[0], p2[0], p3[0]);
  const by0 = Math.min(p0[1], p1[1], p2[1], p3[1]);
  const by1 = Math.max(p0[1], p1[1], p2[1], p3[1]);
  if (bx1 < r.x0 || bx0 > r.x1 || by1 < r.y0 || by0 > r.y1) return [];
  if (bx0 >= r.x0 && bx1 <= r.x1 && by0 >= r.y0 && by1 <= r.y1) return [[0, 1]];
  if (depth >= 24) {
    return mjxPointInRect(mjxCubicPoint(p0, p1, p2, p3, 0.5), r) ? [[0, 1]] : [];
  }
  const halves = mjxSplitCubicAt(p0, p1, p2, p3, 0.5);
  const out = [];
  const left = mjxCubicSpans(halves[0][0], halves[0][1], halves[0][2], halves[0][3], r, depth + 1);
  let li;
  for (li = 0; li < left.length; li++) out.push([left[li][0] / 2, left[li][1] / 2]);
  const right = mjxCubicSpans(halves[1][0], halves[1][1], halves[1][2], halves[1][3], r, depth + 1);
  for (li = 0; li < right.length; li++) {
    out.push([0.5 + right[li][0] / 2, 0.5 + right[li][1] / 2]);
  }
  out.sort(function (a, b) {
    return a[0] - b[0];
  });
  const merged = [];
  for (li = 0; li < out.length; li++) {
    const last = merged[merged.length - 1];
    if (last && out[li][0] <= last[1] + 1e-9) {
      if (out[li][1] > last[1]) last[1] = out[li][1];
    } else {
      merged.push([out[li][0], out[li][1]]);
    }
  }
  return merged;
}

// Sub-curve of p0..p3 over parameter span [t0, t1] (de Casteljau).
function mjxExtractSpan(p0, p1, p2, p3, t0, t1) {
  const first = mjxSplitCubicAt(p0, p1, p2, p3, t1);
  if (t0 <= 1e-12) return first[0];
  const second = mjxSplitCubicAt(first[0][0], first[0][1], first[0][2], first[0][3], t0 / t1);
  return second[1];
}

// Clip one M-led subpath to an axis-aligned rect. Closed loops stay
// closed; cubics are subdivided at rect crossings so caps survive.
function mjxClipLoop(start, segs, closed, rect) {
  // Collect visible runs first; closed loops get stitched into ONE loop
  // with boundary connectors (else open slivers fill ~zero area).
  const runs = [];
  let curRun = null;
  let cur = [start[0], start[1]];
  function runM(p) {
    curRun = [{ t: 'M', p: [p[0], p[1]] }];
    runs.push(curRun);
  }
  function runEmit(op) {
    const last = curRun[curRun.length - 1];
    if (op.t === 'L' && last.p[0] === op.p[0] && last.p[1] === op.p[1]) return;
    curRun.push(op);
  }
  const edges = segs.slice();
  if (closed) edges.push({ t: 'Z', p: [] });
  for (let si = 0; si < edges.length; si++) {
    const e = edges[si];
    if (e.t === 'L') {
      const part = mjxClipLine(cur, [e.p[0], e.p[1]], rect);
      if (part) {
        if (!curRun) runM(part[0]);
        runEmit({ t: 'L', p: [part[1][0], part[1][1]] });
        if (part[1][0] !== e.p[0] || part[1][1] !== e.p[1]) curRun = null;
      } else {
        curRun = null;
      }
      cur = [e.p[0], e.p[1]];
    } else if (e.t === 'C') {
      const p0 = cur;
      const p1 = [e.p[0], e.p[1]];
      const p2 = [e.p[2], e.p[3]];
      const p3 = [e.p[4], e.p[5]];
      const spans = mjxCubicSpans(p0, p1, p2, p3, rect, 0);
      if (spans.length === 0) {
        curRun = null;
      } else {
        for (let k = 0; k < spans.length; k++) {
          const sub = mjxExtractSpan(p0, p1, p2, p3, spans[k][0], spans[k][1]);
          if (!curRun) runM([sub[0][0], sub[0][1]]);
          runEmit({
            t: 'C',
            p: [sub[1][0], sub[1][1], sub[2][0], sub[2][1], sub[3][0], sub[3][1]],
          });
        }
        if (spans[spans.length - 1][1] < 1 - 1e-9) curRun = null;
      }
      cur = [p3[0], p3[1]];
    } else if (e.t === 'Z') {
      const part = mjxClipLine(cur, start, rect);
      if (part) {
        if (!curRun) runM(part[0]);
        runEmit({ t: 'L', p: [part[1][0], part[1][1]] });
      } else {
        curRun = null;
      }
      cur = [start[0], start[1]];
    }
  }
  // Drop degenerate runs (lone M, zero-length).
  const kept = [];
  for (let ri = 0; ri < runs.length; ri++) {
    const r = runs[ri];
    if (r.length < 2) continue;
    if (r.length === 2 && r[1].t === 'L' && r[1].p[0] === r[0].p[0] && r[1].p[1] === r[0].p[1]) continue;
    kept.push(r);
  }
  if (kept.length === 0) return [];
  if (!closed) {
    const out = [];
    for (let ri = 0; ri < kept.length; ri++) {
      for (let k = 0; k < kept[ri].length; k++) out.push(kept[ri][k]);
    }
    return out;
  }
  // Stitch runs end-to-start along the clip boundary into one loop.
  const out = [];
  function lastPtOf(run) {
    const o = run[run.length - 1];
    if (o.t === 'M') return o.p;
    if (o.t === 'L') return [o.p[0], o.p[1]];
    return [o.p[4], o.p[5]]; // C end
  }
  out.push(kept[0][0]);
  for (let k = 1; k < kept[0].length; k++) out.push(kept[0][k]);
  for (let ri = 1; ri < kept.length; ri++) {
    const prevEnd = lastPtOf(out);
    const st = kept[ri][0].p;
    if (st[0] !== prevEnd[0] || st[1] !== prevEnd[1]) {
      out.push({ t: 'L', p: [st[0], st[1]] });
    }
    for (let k = 1; k < kept[ri].length; k++) out.push(kept[ri][k]);
  }
  out.push({ t: 'Z', p: [] });
  return out;
}

// Clip an op list (M-led subpaths) to an axis-aligned rect in the ops'
// own coordinate space. Returns a new op list, possibly empty.
function mjxClipOpsToRect(ops, rect) {
  const out = [];
  let i = 0;
  while (i < ops.length) {
    if (ops[i].t !== 'M') {
      i++;
      continue;
    }
    const start = [ops[i].p[0], ops[i].p[1]];
    const segs = [];
    let closed = false;
    let j = i + 1;
    while (j < ops.length && ops[j].t !== 'M') {
      if (ops[j].t === 'Z') closed = true;
      else if (ops[j].t === 'L' || ops[j].t === 'C') segs.push(ops[j]);
      j++;
    }
    const clipped = mjxClipLoop(start, segs, closed, rect);
    for (let k = 0; k < clipped.length; k++) out.push(clipped[k]);
    i = j;
  }
  // Drop lone-M subpaths left by total clip-away.
  const clean = [];
  for (let k = 0; k < out.length; k++) {
    if (out[k].t === 'M') {
      const nx = out[k + 1];
      if (!nx || nx.t === 'M') continue;
      if (nx.t === 'Z' && (!out[k + 2] || out[k + 2].t === 'M')) {
        k++;
        continue;
      }
    }
    clean.push(out[k]);
  }
  return clean;
}

// Ops bbox helper (final-space, for sibling-trim decisions).
function mjxOpsBBox(ops) {
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (let i = 0; i < ops.length; i++) {
    const p = ops[i].p;
    for (let k = 0; k + 1 < p.length; k += 2) {
      const x = p[k];
      const y = p[k + 1];
      if (!isFinite(x) || !isFinite(y)) return null;
      if (x < x0) x0 = x;
      if (x > x1) x1 = x;
      if (y < y0) y0 = y;
      if (y > y1) y1 = y;
    }
  }
  if (x0 === Infinity) return null;
  return { x0: x0, y0: y0, x1: x1, y1: y1 };
}

// Full MathJax SVG string (AFTER rewriteSvgSize, so width/height are pt)
// -> glyph list. Each glyph: {kind: 'glyph'|'rule', ops: [...]} with ops
// in pt relative to the SVG origin (viewBox min mapped to 0,0).
// This is the in-memory replacement for the retired Document.load +
// harvestGeometry helper path: Affinity placed helper SVG content at its
// spread origin, so parsed svg-local coords play the same role downstream
// as the old baked harvest coords did.
function mjxParseSvg(svg) {
  const rootM = /<svg[^>]*>/.exec(svg);
  if (!rootM) throw new Error('No <svg> root found');
  const root = rootM[0];
  const vb = mjxSplitNums(mjxAttr(root, 'viewBox'));
  if (vb.length < 4) throw new Error('SVG root has no viewBox');
  const minx = vb[0];
  const miny = vb[1];
  const vbw = vb[2];
  const vbh = vb[3];
  if (!(vbw > 0) || !(vbh > 0)) throw new Error('SVG viewBox has non-positive size');
  const wPt = mjxParsePt(mjxAttr(root, 'width'));
  if (!(wPt > 0)) {
    throw new Error('SVG root width is not usable: ' + mjxAttr(root, 'width'));
  }
  const s = wPt / vbw;
  const rootMap = { a: s, b: 0, c: 0, d: s, e: -minx * s, f: -miny * s };

  const defs = {};
  const defsM = /<defs>([\s\S]*?)<\/defs>/.exec(svg);
  if (defsM) {
    const defRe = /<path[^>]*>/g;
    let dm;
    while ((dm = defRe.exec(defsM[1])) !== null) {
      const id = mjxAttr(dm[0], 'id');
      const d = mjxAttr(dm[0], 'd');
      // d may be "" (space glyphs have no outline) — still register it.
      if (id && d != null) defs[id] = d;
    }
  }
  const body = defsM
    ? svg.substring(0, defsM.index) + svg.substring(defsM.index + defsM[0].length)
    : svg;

  const glyphs = [];
  // Elements MathJax emits that carry no vector outlines (e.g. <text>
  // for glyphs missing from its SVG font: upright Greek, ℃, €,
  // \unicode). Counted so the run can warn instead of silently
  // dropping characters.
  const dropped = { text: 0 };
  // Frame stack, innermost last. Each frame carries its LOCAL transform
  // (mapping its content one level out) and, for nested-svg viewports,
  // a clip rect in the frame's own content space (so rects stay
  // axis-aligned whatever outer transforms do). gstack tracks plain
  // group ancestry so shafts can find sibling heads for joint trimming.
  const frames = [{ L: mjxIdentity(), rect: null }];
  const gstack = [0];
  let nextGid = 1;
  let seenRootSvg = false;
  const tagRe = /<\/?([a-zA-Z]+)[^>]*>/g;
  let tm;
  while ((tm = tagRe.exec(body)) !== null) {
    const full = tm[0];
    const el = tm[1];
    const isClose = full.charAt(1) === '/';
    if (el === 'g') {
      if (isClose) {
        if (frames.length > 1) frames.pop();
        if (gstack.length > 1) gstack.pop();
      } else {
        frames.push({
          L: mjxParseTransformList(mjxAttr(full, 'transform')),
          rect: null,
        });
        gstack.push(nextGid++);
        if (/\/\s*>$/.test(full)) {
          if (frames.length > 1) frames.pop();
          if (gstack.length > 1) gstack.pop();
        }
      }
    } else if (el === 'svg') {
      if (isClose) {
        if (frames.length > 1) frames.pop();
      } else if (!seenRootSvg) {
        seenRootSvg = true; // root <svg>: rootMap below already accounts for it
      } else {
        // Nested viewport (extensible-arrow shafts, brace segments):
        // offset into place, scale viewBox to size, clip content to it.
        const vx = mjxParsePt(mjxAttr(full, 'x'));
        const vy = mjxParsePt(mjxAttr(full, 'y'));
        const vw = mjxParsePt(mjxAttr(full, 'width'));
        const vh = mjxParsePt(mjxAttr(full, 'height'));
        const vb2 = mjxSplitNums(mjxAttr(full, 'viewBox'));
        const ox = isNaN(vx) ? 0 : vx;
        const oy = isNaN(vy) ? 0 : vy;
        if (vb2.length >= 4 && vb2[2] > 0 && vb2[3] > 0 && vw > 0 && vh > 0) {
          const sx2 = vw / vb2[2];
          const sy2 = vh / vb2[3];
          const V = mjxMul(
            mjxTranslateM(ox, oy),
            mjxMul(
              { a: sx2, b: 0, c: 0, d: sy2, e: 0, f: 0 },
              mjxTranslateM(-vb2[0], -vb2[1]),
            ),
          );
          frames.push({
            L: V,
            rect: { x0: vb2[0], y0: vb2[1], x1: vb2[0] + vb2[2], y1: vb2[1] + vb2[3] },
          });
        } else {
          frames.push({ L: mjxTranslateM(ox, oy), rect: null });
        }
        if (/\/\s*>$/.test(full) && frames.length > 1) frames.pop();
      }
    } else if (!isClose && el === 'text') {
      dropped.text++;
    } else if (!isClose && (el === 'use' || el === 'rect' || el === 'line' || el === 'path' || el === 'polygon' || el === 'polyline')) {
      let rawOps = null;
      let kind = 'glyph';
      if (el === 'use') {
        let href = mjxAttr(full, 'xlink:href') || mjxAttr(full, 'href');
        if (!href) throw new Error('SVG <use> without href');
        if (href.charAt(0) === '#') href = href.substring(1);
        const d = defs[href];
        if (d === undefined) throw new Error('SVG <use> references unknown id "' + href + '"');
        // Empty d = whitespace glyph (no outline); advance is carried by
        // siblings' absolute translates, so there is nothing to place.
        if (!d) continue;
        rawOps = mjxParsePathOps(d);
      } else if (el === 'rect') {
        const rx = mjxParsePt(mjxAttr(full, 'x'));
        const ry = mjxParsePt(mjxAttr(full, 'y'));
        const rw = mjxParsePt(mjxAttr(full, 'width'));
        const rh = mjxParsePt(mjxAttr(full, 'height'));
        const fill = mjxAttr(full, 'fill');
        const sw = mjxParsePt(mjxAttr(full, 'stroke-width'));
        // Stroked outline (menclose box): ring, not slab. Anything else
        // (fraction rules, overbars): solid loop as before.
        if (fill === 'none' && sw > 0) {
          const ring = mjxRectRingOps(
            isNaN(rx) ? 0 : rx, isNaN(ry) ? 0 : ry, rw, rh, sw,
          );
          if (!ring) continue;
          rawOps = ring;
        } else {
          rawOps = mjxRectOps(isNaN(rx) ? 0 : rx, isNaN(ry) ? 0 : ry, rw, rh);
        }
        kind = 'rule';
      } else if (el === 'line') {
        const x1 = mjxParsePt(mjxAttr(full, 'x1'));
        const y1 = mjxParsePt(mjxAttr(full, 'y1'));
        const x2 = mjxParsePt(mjxAttr(full, 'x2'));
        const y2 = mjxParsePt(mjxAttr(full, 'y2'));
        const w = mjxParsePt(mjxAttr(full, 'stroke-width'));
        const loop = mjxLineOps(x1, y1, x2, y2, isNaN(w) ? 0 : w);
        if (!loop) continue;
        rawOps = loop;
        kind = 'rule';
      } else if (el === 'path') {
        rawOps = mjxParsePathOps(mjxAttr(full, 'd') || '');
      } else if (el === 'polygon' || el === 'polyline') {
        const loop = mjxPolyOps(mjxSplitNums(mjxAttr(full, 'points')), el === 'polygon');
        if (!loop) continue;
        rawOps = loop;
        kind = 'rule';
      }
      // Element's own transform, then frames innermost-first (clip before
      // mapping at viewport frames, so rects stay axis-aligned), then root.
      // pg = innermost plain-group ancestor: shaft and head uses inside one
      // arrow assembly share it, so joints can be trimmed to butt joints.
      let ops = mjxTransformOps(rawOps, mjxParseTransformList(mjxAttr(full, 'transform')));
      let alive = ops.length > 0;
      let inViewport = false;
      for (let fi = frames.length - 1; fi >= 1 && alive; fi--) {
        if (frames[fi].rect) {
          inViewport = true;
          ops = mjxClipOpsToRect(ops, frames[fi].rect);
          if (ops.length === 0) alive = false;
        }
        if (alive) ops = mjxTransformOps(ops, frames[fi].L);
      }
      if (!alive) continue; // fully clipped away
      glyphs.push({
        kind: kind,
        ops: mjxTransformOps(ops, rootMap),
        shaft: inViewport,
        pg: gstack[gstack.length - 1],
      });
    }
    // everything else (svg root, title, desc, stray closers): ignored
  }
  mjxTrimShaftJoints(glyphs);
  const crossings = mjxDetectCrossings(glyphs);
  for (let gi = 0; gi < glyphs.length; gi++) {
    delete glyphs[gi].shaft;
    delete glyphs[gi].pg;
  }
  return { glyphs: glyphs, dropped: dropped, crossings: crossings, widthPt: wPt, scale: s };
}

// Crossing detection: proper outline crossings between glyph loops.
// Under merged even-odd fill exactly these void real ink (cancel
// strikes through glyphs, X centers) — so detection here means the
// fallback is always correct, never aesthetic. Butt joints and
// abutments only touch at endpoints (excluded); kerned pairs, accents
// and stacked labels never properly cross. Runs AFTER trim so fixed
// joints stay silent. Returns the crossing count.
function mjxFlattenOps(ops) {
  const segs = [];
  let cx = 0;
  let cy = 0;
  let sx = 0;
  let sy = 0;
  let open = false;
  function emit(x1, y1, x2, y2) {
    if (!isFinite(x1) || !isFinite(y1) || !isFinite(x2) || !isFinite(y2)) return;
    if (x1 === x2 && y1 === y2) return;
    segs.push([x1, y1, x2, y2]);
  }
  for (let i = 0; i < ops.length; i++) {
    const op = ops[i];
    if (op.t === 'M') {
      cx = op.p[0];
      cy = op.p[1];
      sx = cx;
      sy = cy;
      open = true;
    } else if (!open) {
      continue;
    } else if (op.t === 'L') {
      emit(cx, cy, op.p[0], op.p[1]);
      cx = op.p[0];
      cy = op.p[1];
    } else if (op.t === 'C') {
      let px = cx;
      let py = cy;
      for (let k = 1; k <= 4; k++) {
        const t = k / 4;
        const u = 1 - t;
        const qx =
          u * u * u * cx +
          3 * u * u * t * op.p[0] +
          3 * u * t * t * op.p[2] +
          t * t * t * op.p[4];
        const qy =
          u * u * u * cy +
          3 * u * u * t * op.p[1] +
          3 * u * t * t * op.p[3] +
          t * t * t * op.p[5];
        emit(px, py, qx, qy);
        px = qx;
        py = qy;
      }
      cx = op.p[4];
      cy = op.p[5];
    } else if (op.t === 'Z') {
      emit(cx, cy, sx, sy);
      cx = sx;
      cy = sy;
    }
  }
  return segs;
}

function mjxOrient(ax, ay, bx, by, cx, cy) {
  return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
}

// Proper crossing: interiors intersect (orientation straddle, strict)
// AND the crossing point is clear of all four endpoints (butt joints
// share exact endpoints; abutments only touch).
function mjxSegsCrossProper(s1, s2) {
  const d1 = mjxOrient(s2[0], s2[1], s2[2], s2[3], s1[0], s1[1]);
  const d2 = mjxOrient(s2[0], s2[1], s2[2], s2[3], s1[2], s1[3]);
  const d3 = mjxOrient(s1[0], s1[1], s1[2], s1[3], s2[0], s2[1]);
  const d4 = mjxOrient(s1[0], s1[1], s1[2], s1[3], s2[2], s2[3]);
  if (!((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0))) return false;
  if (!((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) return false;
  // Intersection parameter along s1; reject endpoint touches (dust eps).
  const dx = s1[2] - s1[0];
  const dy = s1[3] - s1[1];
  const ex = s2[2] - s2[0];
  const ey = s2[3] - s2[1];
  const den = dx * ey - dy * ex;
  if (Math.abs(den) < 1e-18) return false;
  const t = ((s2[0] - s1[0]) * ey - (s2[1] - s1[1]) * ex) / den;
  const u = ((s2[0] - s1[0]) * dy - (s2[1] - s1[1]) * dx) / den;
  const eps = 1e-6;
  return t > eps && t < 1 - eps && u > eps && u < 1 - eps;
}

// Intersection point of two properly-crossing segments, or null.
// Caller must check mjxSegsCrossProper first.
function mjxSegXPoint(s1, s2) {
  const dx = s1[2] - s1[0];
  const dy = s1[3] - s1[1];
  const ex = s2[2] - s2[0];
  const ey = s2[3] - s2[1];
  const den = dx * ey - dy * ex;
  if (Math.abs(den) < 1e-18) return null;
  const t = ((s2[0] - s1[0]) * ey - (s2[1] - s1[1]) * ex) / den;
  return [s1[0] + t * dx, s1[1] + t * dy];
}

function mjxDetectCrossings(glyphs) {
  const lists = [];
  let gi;
  for (gi = 0; gi < glyphs.length; gi++) {
    lists.push(mjxFlattenOps(glyphs[gi].ops));
  }
  let hits = 0;
  for (gi = 0; gi < glyphs.length; gi++) {
    const a = lists[gi];
    if (a.length === 0) continue;
    for (let gj = gi + 1; gj < glyphs.length; gj++) {
      const b = lists[gj];
      if (b.length === 0) continue;
      // Cheap bbox precheck first.
      let ax0 = Infinity;
      let ay0 = Infinity;
      let ax1 = -Infinity;
      let ay1 = -Infinity;
      let k;
      for (k = 0; k < a.length; k++) {
        const s = a[k];
        if (s[0] < ax0) ax0 = s[0];
        if (s[1] < ay0) ay0 = s[1];
        if (s[2] < ax0) ax0 = s[2];
        if (s[3] < ay0) ay0 = s[3];
        if (s[0] > ax1) ax1 = s[0];
        if (s[1] > ay1) ay1 = s[1];
        if (s[2] > ax1) ax1 = s[2];
        if (s[3] > ay1) ay1 = s[3];
      }
      let bx0 = Infinity;
      let by0 = Infinity;
      let bx1 = -Infinity;
      let by1 = -Infinity;
      for (k = 0; k < b.length; k++) {
        const s = b[k];
        if (s[0] < bx0) bx0 = s[0];
        if (s[1] < by0) by0 = s[1];
        if (s[2] < bx0) bx0 = s[2];
        if (s[3] < by0) by0 = s[3];
        if (s[0] > bx1) bx1 = s[0];
        if (s[1] > by1) by1 = s[1];
        if (s[2] > bx1) bx1 = s[2];
        if (s[3] > by1) by1 = s[3];
      }
      if (!(Math.min(ax1, bx1) > Math.max(ax0, bx0) + 0.05)) continue;
      if (!(Math.min(ay1, by1) > Math.max(ay0, by0) + 0.05)) continue;
      // Distinct crossing points (clustered at 1e-3pt): a single tangent
      // touch encloses zero area (invisible at any zoom), so only pairs
      // with 2+ separated crossings void visible ink.
      const found = [];
      for (let si = 0; si < a.length; si++) {
        for (let sj = 0; sj < b.length; sj++) {
          if (!mjxSegsCrossProper(a[si], b[sj])) continue;
          const p = mjxSegXPoint(a[si], b[sj]);
          if (!p) continue;
          let seen = false;
          for (let q = 0; q < found.length; q++) {
            const dx = found[q][0] - p[0];
            const dy = found[q][1] - p[1];
            if (dx * dx + dy * dy < 1e-6) {
              seen = true;
              break;
            }
          }
          if (!seen) found.push(p);
        }
      }
      if (found.length >= 2) hits++;
    }
  }
  return hits;
}

// Butt-joint pass: arrow parts slide under each other by design
// (same-colour overpaint in browsers). Merged single fills would knock
// overlaps out, so trim covered ends back to the covering edge.
// Two classes: viewport shafts (trim against any overlapping head) and
// wide same-assembly glyph pairs (arrowhead stubs slid inside each
// other, e.g. the two heads of \xleftrightarrow). Guards (end
// coverage, thickness intersection, majority/containment) exclude
// kerned pairs, accents, labels and abutting segments. Skips anything
// ambiguous (keeps today's geometry) and never empties.
function mjxTrimShaftJoints(glyphs) {
  const boxes = [];
  let bi;
  for (bi = 0; bi < glyphs.length; bi++) {
    boxes.push(mjxOpsBBox(glyphs[bi].ops));
  }
  function pieceInside(horiz, a, b, sb, hb) {
    const e = 1e-6;
    if (horiz) {
      return (
        a >= hb.x0 - e && b <= hb.x1 + e && sb.y0 >= hb.y0 - e && sb.y1 <= hb.y1 + e
      );
    }
    return (
      a >= hb.y0 - e && b <= hb.y1 + e && sb.x0 >= hb.x0 - e && sb.x1 <= hb.x1 + e
    );
  }
  // Same thin strip (shared baseline + thickness): stub pairs coincide;
  // labels, accents and curls do not. Tolerance scales with thickness.
  function sameStrip(horiz, sb, hb, thick) {
    const tol = 0.05 * thick + 1e-9;
    if (horiz) {
      return Math.abs(sb.y0 - hb.y0) <= tol && Math.abs(sb.y1 - hb.y1) <= tol;
    }
    return Math.abs(sb.x0 - hb.x0) <= tol && Math.abs(sb.x1 - hb.x1) <= tol;
  }
  for (bi = 0; bi < glyphs.length; bi++) {
    const g = glyphs[bi];
    const sb = boxes[bi];
    if (!sb) continue;
    const w = sb.x1 - sb.x0;
    const h = sb.y1 - sb.y0;
    if (!(w > 0) || !(h > 0)) continue;
    const horiz = w >= h;
    let lo = horiz ? sb.x0 : sb.y0;
    let hi = horiz ? sb.x1 : sb.y1;
    const span = hi - lo;
    if (!(span > 0)) continue;
    // Shafts always eligible; other glyphs only as wide same-assembly
    // pairs (arrowhead stubs). Curls, kerned pairs and labels fail the
    // overlap-fraction rule below.
    const isShaft = !!g.shaft;
    let changed = false;
    for (let hj = 0; hj < glyphs.length; hj++) {
      if (hj === bi) continue;
      const head = glyphs[hj];
      if (head.shaft) continue;
      if (!isShaft && head.pg !== g.pg) continue;
      const hb = boxes[hj];
      if (!hb) continue;
      // Real 2D intersection required (not just axial projection): heads
      // share the bar's thickness, labels above/below do not. Brace
      // ornaments live in different groups than bar segments, so for
      // shafts no ancestry matching — geometry guards alone decide.
      const ix0 = Math.max(sb.x0, hb.x0);
      const ix1 = Math.min(sb.x1, hb.x1);
      const iy0 = Math.max(sb.y0, hb.y0);
      const iy1 = Math.min(sb.y1, hb.y1);
      if (ix1 <= ix0 || iy1 <= iy0) continue;
      if (isShaft) {
        const perp = horiz ? (iy1 - iy0) / h : (ix1 - ix0) / w;
        if (!(perp >= 0.3)) continue;
      }
      const hLo = horiz ? hb.x0 : hb.y0;
      const hHi = horiz ? hb.x1 : hb.y1;
      // Overlap must cover the target end (not a mid-bar crossing). Shaft
      // tongues are small end-overlaps (40% gate); head-head stubs may
      // overlap most of the target, so the fraction rule below decides.
      const endCovered =
        hLo < hi && hHi >= hi - span * 0.05 && (isShaft ? hLo > lo + span * 0.4 : hLo > lo);
      if (endCovered) {
        if (isShaft) {
          if (hLo > lo + span * 0.5 && hLo < hi) {
            hi = hLo;
            changed = true;
          }
        } else if (
          hLo > lo &&
          hLo < hi &&
          (hi - hLo) / span >= 0.5 &&
          pieceInside(horiz, hLo, hi, sb, hb) &&
          sameStrip(horiz, sb, hb, h)
        ) {
          // Head-head stub pairs trim single-sided (earlier glyph cut at
          // the later glyph's edge) so overlapping pairs can never open
          // a gap from both sides at once.
          hi = hLo;
          changed = true;
        }
      } else if (hHi > lo && hLo <= lo + span * 0.05 && hHi < hi - span * 0.4) {
        if (isShaft) {
          if (hHi < hi - span * 0.5 && hHi > lo) {
            lo = hHi;
            changed = true;
          }
        }
        // NOTE: no left-side trims for head-head pairs (single-sided by
        // construction; see above).
      }
    }
    if (!changed) continue;
    if (isShaft && (hi <= lo || hi - lo < span * 0.5)) continue; // keep majority or skip
    if (!isShaft && hi <= lo) continue;
    const rect = horiz
      ? { x0: lo, y0: sb.y0, x1: hi, y1: sb.y1 }
      : { x0: sb.x0, y0: lo, x1: sb.x1, y1: hi };
    const cut = mjxClipOpsToRect(g.ops, rect);
    if (cut.length === 0) continue;
    g.ops = cut;
    boxes[bi] = mjxOpsBBox(cut);
  }
}

// ==== MJX-PURE-END ====

// SDK adapter: parsed glyph ops -> harvested-shape clones. Output feeds
// the insert paths as [{polyCurve, kind}].
function mjxOpsToPolyCurve(glyphOps) {
  const pc = PolyCurve.create();
  let cb = null;
  function flush() {
    if (cb !== null) {
      try {
        pc.addCurve(cb.createCurve());
      } catch (e) {
        /* ignore */
      }
      cb = null;
    }
  }
  for (const op of glyphOps) {
    if (op.t === 'M') {
      flush();
      cb = CurveBuilder.create();
      cb.beginXY(op.p[0], op.p[1]);
    } else if (op.t === 'L') {
      if (!cb) {
        cb = CurveBuilder.create();
        cb.beginXY(op.p[0], op.p[1]);
      } else {
        cb.lineToXY(op.p[0], op.p[1]);
      }
    } else if (op.t === 'C') {
      if (!cb) {
        cb = CurveBuilder.create();
        cb.beginXY(op.p[4], op.p[5]);
      } else {
        cb.addBezierXY(op.p[0], op.p[1], op.p[2], op.p[3], op.p[4], op.p[5]);
      }
    } else if (op.t === 'Z') {
      if (cb) {
        try {
          cb.close();
        } catch (e) {
          /* ignore */
        }
      }
    }
  }
  flush();
  return pc;
}

function mjxGlyphsToHarvested(glyphs) {
  const harvested = [];
  for (const g of glyphs) {
    if (!g.ops || g.ops.length === 0) continue; // whitespace: nothing to place
    try {
      harvested.push({
        polyCurve: mjxOpsToPolyCurve(g.ops),
        kind: g.kind === 'rule' ? 'shape' : 'curve',
      });
    } catch (err) {
      log('  parse skip (' + g.kind + '): ' + (err && err.message ? err.message : String(err)));
    }
  }
  return harvested;
}

// ============================================================
// Render (in-memory: SVG string straight to curves, no helper document)
// ============================================================

function latexToSvgString(latex, settings, quiet) {
  const fn = getTex2Svg();
  let svg = fn(latex, { display: !!settings.display, em: 16, ex: 8 });
  svg = rewriteSvgSize(svg, settings.fontSize);
  if (!quiet) {
    log(
      "SVG sized for " +
        settings.fontSize +
        "pt" +
        (settings.display ? " display" : " inline") +
        " (em-to-pt scale=" +
        CONFIG.EM_TO_PT_SCALE +
        ")",
    );
  }
  return svg;
}

// ============================================================
// Render (in-memory: SVG string straight to curves)
// ============================================================

function renderAndHarvest(latex, settings) {
  if (!latex || !latex.trim()) {
    throw new Error("Source is empty — type a formula or pick an example first.");
  }
  const t0 = Date.now();
  const svg = latexToSvgString(latex.trim(), settings);
  let parsed;
  try {
    parsed = mjxParseSvg(svg);
  } catch (err) {
    const reason = err && err.message ? err.message : String(err);
    throw new Error(
      "The formula could not be rendered (" + reason + "). " +
        "Try a simpler expression, or an example from the dropdown to check the setup.",
    );
  }
  const harvested = mjxGlyphsToHarvested(parsed.glyphs);
  const droppedText =
    parsed.dropped && parsed.dropped.text ? parsed.dropped.text | 0 : 0;
  const crossings = parsed.crossings | 0;
  log(
    "Render in-memory: " +
      harvested.length +
      " geometry nodes in " +
      (Date.now() - t0) +
      "ms" +
      (droppedText > 0 ? " (skipped " + droppedText + " outline-less characters)" : "") +
      (crossings > 0 ? " (" + crossings + " stroke crossings)" : ""),
  );
  if (harvested.length === 0) {
    throw new Error("No geometry was rendered. Check your LaTeX syntax.");
  }
  return { harvested: harvested, droppedText: droppedText, crossings: crossings };
}

function friendlyRenderError(msg) {
  const m = String(msg || "Unknown error");
  if (m.indexOf("tex2svg.bundle.js") >= 0) return m; // already friendly
  if (m.indexOf("No geometry was rendered") >= 0) {
    return "Nothing came out of that LaTeX — usually a typo or an unsupported command.\nCheck the formula and try again. (Try an example from the dropdown to confirm the setup works.)\n\nTechnical detail: " + m;
  }
  return m;
}

// ============================================================
// Default placement
// ============================================================

function defaultPlacementPosition(workingDoc) {
  try {
    const spread = workingDoc.currentSpread;
    const box = spread.spreadVisibleBox || spread.getSpreadBaseBox(false);
    if (box) {
      return {
        x: box.x + box.width * CONFIG.PLACE_FRACTION_X,
        y: box.y + box.height * CONFIG.PLACE_FRACTION_Y,
      };
    }
  } catch (e) {
    /* ignore */
  }
  return { x: 100, y: 100 };
}

// ============================================================
// Robust colour readback
// ============================================================

function colourFromPicker(picker) {
  try {
    const col = picker.value;
    if (!col) return { r: 0, g: 0, b: 0, alpha: 255 };
    if (col.rgba8) return clampRGBA(col.rgba8);
    if (typeof col.getRGBA8 === "function") return clampRGBA(col.getRGBA8());
    if (typeof col.toRGBA8 === "function") return clampRGBA(col.toRGBA8());
    if (col.r != null && col.g != null && col.b != null) return clampRGBA(col);
  } catch (e) {
    log("colourFromPicker: " + e.message);
  }
  return { r: 0, g: 0, b: 0, alpha: 255 };
}

function clampRGBA(c) {
  return {
    r: (c.r | 0) & 0xff,
    g: (c.g | 0) & 0xff,
    b: (c.b | 0) & 0xff,
    alpha: (c.alpha == null ? 255 : c.alpha | 0) & 0xff,
  };
}

// ============================================================
// Live canvas preview (Tier-A experiment, CONFIG.LIVE_PREVIEW)
// ============================================================

// Change-key: identical states skip re-render (typing fires constantly).
function previewKeyFor(latex, settings, placeX, placeY) {
  const c = settings.colourRGBA;
  return [
    latex,
    settings.fontSize,
    settings.display ? "d" : "i",
    settings.keepSingleObject ? "s" : "g",
    c.r | 0,
    c.g | 0,
    c.b | 0,
    (c.alpha == null ? 255 : c.alpha) | 0,
    Math.round(placeX),
    Math.round(placeY),
  ].join("|");
}

// Transient preview render: same geometry as commit, painted with the
// preview flag so it is atomically replaced and never committed.
// No tags, no delete, no container, no selection changes, no alerts.
// Returns true while a preview is showing. Never throws.
function renderPreview(workingDoc, latex, settings, placeAt) {
  let out;
  try {
    out = renderAndHarvest(latex, settings);
  } catch (e) {
    return false;
  }
  const single =
    settings.keepSingleObject && ((out.crossings | 0) === 0);
  try {
    const c = settings.colourRGBA;
    const userColour = RGBA8(
      c.r | 0,
      c.g | 0,
      c.b | 0,
      (c.alpha == null ? 255 : c.alpha) | 0,
    );
    const userFill = FillDescriptor.createSolid(userColour);
    const noFill = FillDescriptor.createNone();
    const noLine = LineStyleDescriptor.createDefault(0);
    const move = Transform.createTranslate(placeAt.x, placeAt.y);
    const builder = AddChildNodesCommandBuilder.create();
    builder.setInsertionTarget(workingDoc.currentSpread);
    if (single) {
      const merged = PolyCurve.create();
      for (const h of out.harvested) {
        const pc = h.polyCurve;
        let n = 0;
        try {
          n = pc.curveCount;
        } catch (e) {
          n = 0;
        }
        for (let i = 0; i < n; i++) {
          try {
            merged.addCurve(pc.at(i));
          } catch (e) {
            /* ignore */
          }
        }
      }
      try {
        merged.transform(move);
      } catch (e) {
        /* ignore */
      }
      builder.addPolyCurveNode(
        PolyCurveNodeDefinition.create(merged, userFill, noFill, noLine, noFill),
      );
    } else {
      for (const h of out.harvested) {
        let pc = null;
        try {
          pc = h.polyCurve.clone();
        } catch (e) {
          pc = null;
        }
        if (!pc) continue;
        try {
          pc.transform(move);
        } catch (e) {
          /* ignore */
        }
        try {
          builder.addPolyCurveNode(
            PolyCurveNodeDefinition.create(pc, userFill, noFill, noLine, noFill),
          );
        } catch (e) {
          /* ignore */
        }
      }
    }
    // createCommand(false): never auto-select — selecting while a
    // preview is active voids the painting. Second arg true paints
    // transiently (replaces the previous preview atomically).
    workingDoc.executeCommand(
      builder.createCommand(false, NodeChildType.Main),
      true,
    );
    return true;
  } catch (e) {
    return false;
  }
}

// ============================================================
// Dialog (values persist across retries in one run)
// ============================================================

function parsePlacementNumber(text, fallback) {
  const n = parseFloat(String(text).replace(",", "."));
  if (isNaN(n)) return fallback;
  return n;
}

// Comment-style static text spanning the full width, so it starts at the
// left edge instead of sitting in the value column next to an empty label
// (cf. find-replace.js, typographic-cleanup.js setIsFullWidth pattern).
function fullWidthNote(group, text) {
  const st = group.addStaticText("", text);
  try {
    if (st && typeof st.setIsFullWidth === "function") st.setIsFullWidth(true);
    else if (st) st.isFullWidth = true;
  } catch (e) {
    /* ignore */
  }
  return st;
}

function runDialogOnce(workingDoc, state, isReedit, statusMessage, originalPos) {
  const titleSuffix = isReedit
    ? "  v" + TOOL_VERSION + "  \u2014 Edit formula"
    : "  v" + TOOL_VERSION;
  const dlg = Dialog.create(TOOL_NAME + titleSuffix);
  dlg.initialWidth = 440;
  dlg.isResizable = true;

  const col = dlg.addColumn();
  col.widthProportion = 1;

  if (isReedit && state.reeditLabel) {
    const ctx = col.addGroup("Editing");
    fullWidthNote(ctx, state.reeditLabel);
  }

  const sourceGroup = col.addGroup("LaTeX source");
  const srcBox = sourceGroup.addTextBox("", state.latex || "");
  srcBox.isMultiLine = true;
  srcBox.rowSpan = 6;
  srcBox.isFullWidth = true;

  // Blank spacer row so the popup sits clear of the text entry above
  // it, without a group header/divider between them.
  const exampleGap = sourceGroup.addStaticText("", " ");
  try {
    if (exampleGap && typeof exampleGap.setIsFullWidth === "function") {
      exampleGap.setIsFullWidth(true);
    }
  } catch (e) {
    /* ignore */
  }
  const exampleLabels = EXAMPLES.map(function (e) { return e.label; });
  const exampleCombo = sourceGroup.addComboBox(
    "Example (loads into source above)",
    exampleLabels,
    state.exampleIndex || 0,
  );

  // Live load: picking an example fills the source box in the SAME
  // dialog — no close/reopen. Proven pattern: per-control
  // onValueChangedHandler (cf. typographic-proportions.js trimList).
  // If the SDK ever drops the handler, the post-OK fallback in main()
  // still loads the example via a single re-show.
  let lastExampleIdx = state.exampleIndex || 0;
  let exampleLiveApplied = false;
  try {
    exampleCombo.onValueChangedHandler = function () {
      try {
        const idx = exampleCombo.selectedIndex;
        if (idx === lastExampleIdx) return;
        lastExampleIdx = idx;
        if (idx > 0 && EXAMPLES[idx] && EXAMPLES[idx].code) {
          srcBox.text = EXAMPLES[idx].code;
          exampleLiveApplied = true;
          try {
            onTick();
          } catch (e) {
            /* status/preview refresh optional */
          }
        }
      } catch (e) {
        /* ignore mid-edit states */
      }
    };
  } catch (e) {
    /* handler unsupported — main() fallback covers it */
  }

  const settingsGroup = col.addGroup("Settings");

  const fontLabels = FONT_SIZES.map(function (n) { return String(n) + " pt"; });
  let fontIndex = FONT_SIZES.indexOf(state.settings.fontSize);
  if (fontIndex < 0) fontIndex = defaultFontSizeIndex();
  const fontCombo = settingsGroup.addComboBox(
    "Font size",
    fontLabels,
    fontIndex,
  );

  const initialColour = RGBA8(
    state.settings.colourRGBA.r | 0,
    state.settings.colourRGBA.g | 0,
    state.settings.colourRGBA.b | 0,
    (state.settings.colourRGBA.alpha == null
      ? 255
      : state.settings.colourRGBA.alpha) | 0,
  );
  const colourPicker = settingsGroup.addColourPicker("Colour", initialColour);

  // Own section with a dividing line above it: the two options are
  // unrelated to font/colour above. enableSeparator pattern cf.
  // bulk-find-replace.js sibling groups.
  const optGroup = col.addGroup("Options");
  try {
    optGroup.enableSeparator = true;
  } catch (e) {
    /* ignore */
  }

  // Two-column options row: checkbox 1 + note in the left cell,
  // checkbox 2 + note in the right cell. Scoped ColumnStack (not
  // dialog columns) so Source/Placement/Status are unaffected —
  // cf. apply-character-styles.js addColumnStack precedent.
  const optStack = optGroup.addColumnStack();
  const optLeft = optStack.addColumn().addGroup("");
  const optRight = optStack.addColumn().addGroup("");

  const singleCheck = optLeft.addCheckBox(
    "Keep as single object",
    !!state.settings.keepSingleObject,
  );
  try {
    if (singleCheck && typeof singleCheck.setIsFullWidth === "function") {
      singleCheck.setIsFullWidth(true);
    }
  } catch (e) {
    /* ignore */
  }
  fullWidthNote(
    optLeft,
    "One curve layer, not a glyph group.",
  );

  const displayCheck = optRight.addCheckBox(
    "Display equation",
    !!state.settings.display,
  );
  try {
    if (displayCheck && typeof displayCheck.setIsFullWidth === "function") {
      displayCheck.setIsFullWidth(true);
    }
  } catch (e) {
    /* ignore */
  }
  fullWidthNote(
    optRight,
    "Big standalone style (like \\[ ... \\]). Same formula, just larger with full-size symbols.",
  );

  let xBox = null;
  let yBox = null;
  if (!isReedit) {
    const placeGroup = col.addGroup("Placement (spread units)");
    xBox = placeGroup.addTextBox("X", String(Math.round(state.placeX)));
    yBox = placeGroup.addTextBox("Y", String(Math.round(state.placeY)));
  } else {
    const placeGroup = col.addGroup("Placement");
    fullWidthNote(
      placeGroup,
      "Replaces the formula in place — its position is kept.",
    );
  }

  const statusGroup = col.addGroup("Status");
  const defaultStatus = isReedit
    ? "OK replaces the formula in place. Cancel keeps the original."
    : "OK renders the formula and places it on the spread. Cancel discards — nothing is changed.";
  const statusText = fullWidthNote(statusGroup, statusMessage || defaultStatus);

  // Tier-B live status: every control change re-renders quietly and
  // reports glyph count or the friendly error IN the dialog — never an
  // alert, never an insert, never an undo. Change-key gated so idle
  // ticks cost nothing. Colour picker emits no dialog events (SDK), so
  // colour stays OK-time-only; it never affects the count anyway.
  let lastStatusKey = null;
  function refreshStatus() {
    try {
      const latex = normaliseLatex(srcBox.text);
      const fIdx = fontCombo.selectedIndex;
      const fs = FONT_SIZES[fIdx] || CONFIG.DEFAULT_FONT_SIZE;
      const disp = !!displayCheck.value;
      const key = latex + "|" + fs + "|" + disp;
      if (key === lastStatusKey) return;
      lastStatusKey = key;
      if (!statusText) return;
      if (!latex) {
        statusText.text = defaultStatus;
        return;
      }
      try {
        const svg = latexToSvgString(latex, { fontSize: fs, display: disp }, true);
        const parsed = mjxParseSvg(svg);
        const n = parsed.glyphs.length;
        const skipped =
          parsed.dropped && parsed.dropped.text ? parsed.dropped.text | 0 : 0;
        statusText.text =
          n +
          (n === 1 ? " outline" : " outlines") +
          " ready — OK to render." +
          (skipped > 0 ? " (" + skipped + " outline-less skipped)" : "");
      } catch (err) {
        const msg = err && err.message ? err.message : String(err);
        statusText.text = "Not rendering yet: " + String(msg).split("\n")[0];
      }
    } catch (e) {
      /* never break the dialog for a status refresh */
    }
  }
  // Tier-A live preview state (per dialog run): key-gated so idle ticks
  // cost nothing; no debounce timers (unproven in modal dialogs).
  let lastPreviewKey = null;
  let previewActive = false;
  function clearPreview() {
    if (!previewActive) return;
    previewActive = false;
    try {
      if (workingDoc) workingDoc.clearPreviews();
    } catch (e) {
      /* ignore */
    }
  }
  function currentPlace() {
    if (isReedit) return originalPos || defaultPlacementPosition(workingDoc);
    const px = xBox ? parsePlacementNumber(xBox.text, state.placeX) : state.placeX;
    const py = yBox ? parsePlacementNumber(yBox.text, state.placeY) : state.placeY;
    return { x: px, y: py };
  }
  function refreshPreview() {
    if (!CONFIG.LIVE_PREVIEW) return;
    try {
      const latex = normaliseLatex(srcBox.text);
      const fIdx = fontCombo.selectedIndex;
      const settings = {
        fontSize: FONT_SIZES[fIdx] || CONFIG.DEFAULT_FONT_SIZE,
        colourRGBA: colourFromPicker(colourPicker),
        display: !!displayCheck.value,
        keepSingleObject: !!singleCheck.value,
      };
      const place = currentPlace();
      const key = previewKeyFor(latex, settings, place.x, place.y);
      if (key === lastPreviewKey) return;
      lastPreviewKey = key;
      if (!latex) {
        clearPreview();
        return;
      }
      let ok = false;
      try {
        ok = renderPreview(workingDoc, latex, settings, place);
      } catch (e) {
        ok = false;
      }
      if (ok) {
        previewActive = true;
      } else {
        // Keep the key (no hammering); a later edit changes it and retries.
        clearPreview();
      }
    } catch (e) {
      /* never break the dialog for a preview refresh */
    }
  }
  function onTick() {
    refreshStatus();
    refreshPreview();
  }
  try {
    dlg.onControlValueChangedHandler = onTick;
  } catch (e) {
    /* dialog-wide tick unsupported */
  }
  // Per-control ticks: some builds only fire these (cf. barcode attachTick).
  const tickTargets = [srcBox, fontCombo, displayCheck, singleCheck];
  for (let ti = 0; ti < tickTargets.length; ti++) {
    try {
      const ctrl = tickTargets[ti];
      if (ctrl) {
        if (typeof ctrl.setOnValueChangedHandler === "function") {
          ctrl.setOnValueChangedHandler(onTick);
        } else {
          ctrl.onValueChangedHandler = onTick;
        }
      }
    } catch (e) {
      /* control-level tick unsupported */
    }
  }
  // Initial paint: keep a retry-loop error visible until the user edits.
  try {
    if (statusMessage) {
      const latex0 = normaliseLatex(srcBox.text);
      const f0 = FONT_SIZES[fontCombo.selectedIndex] || CONFIG.DEFAULT_FONT_SIZE;
      lastStatusKey = latex0 + "|" + f0 + "|" + (!!displayCheck.value);
    } else {
      onTick();
    }
  } catch (e) {
    /* ignore */
  }

  const hintGroup = col.addGroup("");
  fullWidthNote(
    hintGroup,
    "Tip: pick an example to load it into the source box, tweak if you like, then OK to render. " +
      "To edit later, select the formula — any part of it — and run this script again. " +
      "Formulas with crossing strokes (e.g. cancel) place as a group.",
  );

  const result = dlg.runModal();
  const okValue =
    DialogResult.Ok && DialogResult.Ok.value != null
      ? DialogResult.Ok.value
      : DialogResult.Ok;
  const resultValue = result && result.value != null ? result.value : result;
  if (resultValue !== okValue) {
    // Cancel: discard the transient preview; the re-edit original (if
    // any) was never touched, so nothing needs restoring.
    clearPreview();
    return null;
  }
  // OK: drop the transient preview first so it can never double with
  // (or be mistaken for) the real committed nodes below.
  clearPreview();

  const idx = fontCombo.selectedIndex;
  const fontSize = FONT_SIZES[idx] || CONFIG.DEFAULT_FONT_SIZE;
  return {
    latex: normaliseLatex(srcBox.text),
    exampleIndex: exampleCombo ? exampleCombo.selectedIndex : 0,
    exampleLiveApplied: exampleLiveApplied,
    settings: {
      fontSize: fontSize,
      colourRGBA: colourFromPicker(colourPicker),
      display: !!displayCheck.value,
      keepSingleObject: !!singleCheck.value,
    },
    placeX: xBox ? parsePlacementNumber(xBox.text, state.placeX) : state.placeX,
    placeY: yBox ? parsePlacementNumber(yBox.text, state.placeY) : state.placeY,
  };
}

// ============================================================
// Insert + commit
// ============================================================

// Single-object branch: one merged curve layer. Tags go directly on the
// node (no container), so re-edit detection finds them on first step.
function insertSingleAndCommit(
  workingDoc,
  latex,
  settings,
  harvested,
  userFill,
  noFill,
  noLine,
  originalPos,
  thingToDelete,
) {
  workingDoc.executeCommand(
    DocumentCommand.createSetCurrentSpread(workingDoc.currentSpread),
  );

  // Placement first: validate BEFORE inserting anything, so a bad
  // position aborts with the document untouched (never garbage-commit).
  const placeAt = originalPos || defaultPlacementPosition(workingDoc);
  assertSanePlaceAt(workingDoc, placeAt);

  const merged = PolyCurve.create();
  let subpaths = 0;
  for (const h of harvested) {
    let n = 0;
    try {
      n = h.polyCurve.curveCount;
    } catch (e) {
      n = 0;
    }
    for (let i = 0; i < n; i++) {
      try {
        merged.addCurve(h.polyCurve.at(i));
        subpaths++;
      } catch (e) {
        /* skip bad subpath */
      }
    }
  }
  if (subpaths === 0) {
    throw new Error(
      "The formula rendered but its outlines could not be merged. " +
        "Untick 'Keep as single object' and retry as a group.",
    );
  }

  let singleDef;
  try {
    // Canonical 3.3 order (probed in-app): brushFill, penFill, lineStyle.
    singleDef = PolyCurveNodeDefinition.create(
      merged,
      userFill,
      noFill,
      noLine,
      noFill,
    );
  } catch (err) {
    const reason = err && err.message ? err.message : String(err);
    throw new Error(
      "The merged single object could not be built (" + reason + "). " +
        "Untick 'Keep as single object' and retry as a group.",
    );
  }

  // Name it like the group path does, so the Layers row is identifiable
  // (otherwise the SDK default "Curves" shows) — same userDescription
  // pattern as vertical-line.js.
  const sizeIndicator =
    String(settings.fontSize) + "pt" + (settings.display ? "/disp" : "");
  const labelLatex =
    latex.length <= 24 ? latex : latex.substring(0, 22) + "...";
  try {
    singleDef.userDescription =
      "Formula [" + sizeIndicator + "]: " + labelLatex;
  } catch (e) {
    /* ignore */
  }

  const builder = AddChildNodesCommandBuilder.create();
  builder.setInsertionTarget(workingDoc.currentSpread);
  builder.addPolyCurveNode(singleDef);
  // Select-after-insert (true): forces tree invalidation so the view
  // paints the new node — the vertical-line/mandala pattern. The group
  // path gets this free via its container insert + Inside move.
  const addCmd = builder.createCommand(true, NodeChildType.Main);
  workingDoc.executeCommand(addCmd);
  const newNodes = addCmd.newNodes || [];
  if (newNodes.length === 0) {
    throw new Error("Insert succeeded but produced no objects. Please retry.");
  }
  const singleNode = newNodes[0];
  log("Added 1 merged curve (" + subpaths + " subpaths)");

  try {
    const b = singleNode.spreadVisibleBox || singleNode.getSpreadBaseBox(false);
    if (b) {
      log(
        "Pre-position formula bbox: " +
          b.width.toFixed(1) +
          " x " +
          b.height.toFixed(1) +
          " (units)",
      );
    }
  } catch (e) {
    /* ignore */
  }

  const singleSel = Selection.create(workingDoc, singleNode);
  const tagStrs = settingsToTagStrings(settings);
  const subCmds = [];

  subCmds.push(
    DocumentCommand.createTransform(
      singleSel,
      Transform.createTranslate(placeAt.x, placeAt.y),
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      singleSel,
      TAG_KEY_SOURCE,
      String(latex),
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      singleSel,
      TAG_KEY_VERSION,
      String(TOOL_VERSION),
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      singleSel,
      TAG_KEY_FONT_SIZE,
      tagStrs.fontSize,
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      singleSel,
      TAG_KEY_COLOUR,
      tagStrs.colour,
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      singleSel,
      TAG_KEY_DISPLAY,
      tagStrs.display,
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      singleSel,
      TAG_KEY_SINGLE_OBJECT,
      tagStrs.singleObject,
    ),
  );

  if (thingToDelete) {
    try {
      const delSel = Selection.create(workingDoc, thingToDelete);
      subCmds.push(DocumentCommand.createDeleteSelection(delSel, true));
    } catch (e) {
      log("Could not build delete: " + e.message);
    }
  }

  if (subCmds.length > 0) {
    try {
      workingDoc.executeCommand(createCompoundCommand(subCmds));
      log("Compound (" + subCmds.length + " sub-commands) executed");
    } catch (e) {
      log("Compound failed: " + e.message);
      for (const cmd of subCmds) {
        try {
          workingDoc.executeCommand(cmd);
        } catch (e2) {
          /* ignore */
        }
      }
    }
  }

  // Post-placement fingerprint: if a future run ever logs a sane box
  // here yet paints nothing, the fault is view invalidation, not geometry.
  try {
    const vb =
      singleNode.spreadVisibleBox || singleNode.getSpreadBaseBox(false);
    let where = "unknown-parent";
    try {
      const par = singleNode.parent;
      where = par ? par.name || par.description || "node" : "no-parent";
    } catch (e) {
      /* ignore */
    }
    if (vb) {
      log(
        "Placed formula bbox: " +
          vb.x.toFixed(1) +
          "," +
          vb.y.toFixed(1) +
          " " +
          vb.width.toFixed(1) +
          " x " +
          vb.height.toFixed(1) +
          " parent=" +
          where,
      );
    } else {
      log("Placed formula bbox: unreadable parent=" + where);
    }
  } catch (e) {
    log("Placed verify failed: " + (e && e.message ? e.message : String(e)));
  }

  return { added: 1, outlines: subpaths, group: singleNode, single: true };
}

function insertAndCommit(
  workingDoc,
  latex,
  settings,
  harvested,
  originalPos,
  thingToDelete,
) {
  workingDoc.executeCommand(
    DocumentCommand.createSetCurrentSpread(workingDoc.currentSpread),
  );

  const c = settings.colourRGBA;
  const userColour = RGBA8(
    c.r | 0,
    c.g | 0,
    c.b | 0,
    (c.alpha == null ? 255 : c.alpha) | 0,
  );
  const userFill = FillDescriptor.createSolid(userColour);
  const noFill = FillDescriptor.createNone();
  const noLine = LineStyleDescriptor.createDefault(0);

  // Placement sanity (both branches): validate BEFORE inserting anything,
  // so a bad position aborts with the document untouched. Each branch
  // re-validates at its own top; this catches it before any command runs.
  const placeAtCheck = originalPos || defaultPlacementPosition(workingDoc);
  assertSanePlaceAt(workingDoc, placeAtCheck);

  // Single-object mode (default): merge every harvested outline into one
  // PolyCurve and place a single curve layer. Clones already carry baked
  // spread-space transforms — concatenation only, never re-transform.
  if (settings.keepSingleObject) {
    return insertSingleAndCommit(
      workingDoc,
      latex,
      settings,
      harvested,
      userFill,
      noFill,
      noLine,
      originalPos,
      thingToDelete,
    );
  }

  const acn = AddChildNodesCommandBuilder.create();
  acn.setInsertionTarget(workingDoc.currentSpread);
  let queued = 0;
  let firstSkipReason = null;
  for (const h of harvested) {
    try {
      // Canonical 3.3 order (probed in-app): brushFill, penFill, lineStyle.
      // cf. barcode-generator.js, calendar-wizard.js.
      const def = PolyCurveNodeDefinition.create(
        h.polyCurve,
        userFill,
        noFill,
        noLine,
        noFill,
      );
      acn.addPolyCurveNode(def);
      queued++;
    } catch (err) {
      const reason = err && err.message ? err.message : String(err);
      if (!firstSkipReason) firstSkipReason = reason;
      log("  insert skip (" + h.kind + "): " + reason);
    }
  }
  if (queued === 0) {
    throw new Error(
      "The formula rendered but none of its shapes could be placed." +
        (firstSkipReason ? " First error: " + firstSkipReason : "") +
        " Try a simpler expression.",
    );
  }

  const addCmd = acn.createCommand(false, NodeChildType.Main);
  workingDoc.executeCommand(addCmd);
  const newCurves = addCmd.newNodes || [];
  if (newCurves.length === 0) {
    throw new Error("Insert succeeded but produced no objects. Please retry.");
  }
  log("Added " + newCurves.length + " curves");

  try {
    let totalBox = null;
    for (const n of newCurves) {
      const b = n.spreadVisibleBox || n.getSpreadBaseBox(false);
      if (!b) continue;
      if (!totalBox)
        totalBox = {
          x: b.x,
          y: b.y,
          right: b.x + b.width,
          bottom: b.y + b.height,
        };
      else {
        if (b.x < totalBox.x) totalBox.x = b.x;
        if (b.y < totalBox.y) totalBox.y = b.y;
        if (b.x + b.width > totalBox.right) totalBox.right = b.x + b.width;
        if (b.y + b.height > totalBox.bottom) totalBox.bottom = b.y + b.height;
      }
    }
    if (totalBox) {
      const w = (totalBox.right - totalBox.x).toFixed(1);
      const h = (totalBox.bottom - totalBox.y).toFixed(1);
      log("Pre-position formula bbox: " + w + " x " + h + " (units)");
    }
  } catch (e) {
    /* ignore */
  }

  const placeAt = originalPos || defaultPlacementPosition(workingDoc);
  const curvesSel = Selection.create(workingDoc, newCurves);

  const sizeIndicator =
    String(settings.fontSize) + "pt" + (settings.display ? "/disp" : "");
  const labelLatex =
    latex.length <= 24 ? latex : latex.substring(0, 22) + "...";
  const groupTitle = "Formula [" + sizeIndicator + "]: " + labelLatex;

  const groupDef = ContainerNodeDefinition.create(groupTitle);
  const groupBuilder = AddChildNodesCommandBuilder.create();
  groupBuilder.addContainerNode(groupDef);
  groupBuilder.setInsertionTargetSelection(curvesSel);
  const groupCmd = groupBuilder.createCommand(false, NodeChildType.Main);
  workingDoc.executeCommand(groupCmd);
  const groupNode = (groupCmd.newNodes && groupCmd.newNodes[0]) || null;
  if (!groupNode) throw new Error("Could not group the formula shapes. Please retry.");

  const groupSel = Selection.create(workingDoc, groupNode);
  const tagStrs = settingsToTagStrings(settings);
  const subCmds = [];

  subCmds.push(
    DocumentCommand.createMoveNodes(
      curvesSel,
      groupNode,
      NodeMoveType.Inside,
      NodeChildType.Main,
    ),
  );
  subCmds.push(
    DocumentCommand.createTransform(
      groupSel,
      Transform.createTranslate(placeAt.x, placeAt.y),
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      groupSel,
      TAG_KEY_SOURCE,
      String(latex),
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      groupSel,
      TAG_KEY_VERSION,
      String(TOOL_VERSION),
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      groupSel,
      TAG_KEY_FONT_SIZE,
      tagStrs.fontSize,
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      groupSel,
      TAG_KEY_COLOUR,
      tagStrs.colour,
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      groupSel,
      TAG_KEY_DISPLAY,
      tagStrs.display,
    ),
  );
  subCmds.push(
    DocumentCommand.createSetTagValueForKey(
      groupSel,
      TAG_KEY_SINGLE_OBJECT,
      tagStrs.singleObject,
    ),
  );

  if (thingToDelete) {
    try {
      const delSel = Selection.create(workingDoc, thingToDelete);
      subCmds.push(DocumentCommand.createDeleteSelection(delSel, true));
    } catch (e) {
      log("Could not build delete: " + e.message);
    }
  }

  if (subCmds.length > 0) {
    try {
      workingDoc.executeCommand(createCompoundCommand(subCmds));
      log("Compound (" + subCmds.length + " sub-commands) executed");
    } catch (e) {
      log("Compound failed: " + e.message);
      for (const cmd of subCmds) {
        try {
          workingDoc.executeCommand(cmd);
        } catch (e2) {
          /* ignore */
        }
      }
    }
  }

  return { added: newCurves.length, group: groupNode };
}

// Placement sanity: finite numbers inside the current spread's visible
// box expanded by one spread size per side (pasteboard included).
// Anything else (NaN, +-MAX sentinel boxes, wild offsets) is rejected
// so one bad placement can never poison the next re-edit. Falls back
// to a finite + bounded check when the spread box is unreadable.
function isSanePlacement(workingDoc, p) {
  if (!p || !isFinite(p.x) || !isFinite(p.y)) return false;
  try {
    const spread = workingDoc.currentSpread;
    const box = spread
      ? spread.spreadVisibleBox || spread.getSpreadBaseBox(false)
      : null;
    if (box && isFinite(box.x) && isFinite(box.y) &&
        isFinite(box.width) && isFinite(box.height) &&
        box.width > 0 && box.height > 0) {
      return (
        p.x >= box.x - box.width &&
        p.x <= box.x + 2 * box.width &&
        p.y >= box.y - box.height &&
        p.y <= box.y + 2 * box.height
      );
    }
  } catch (e) {
    /* fall through to bounded check */
  }
  return Math.abs(p.x) < 1e7 && Math.abs(p.y) < 1e7;
}

function assertSanePlaceAt(workingDoc, placeAt) {
  if (!isSanePlacement(workingDoc, placeAt)) {
    throw new Error(
      "Computed placement (" + (placeAt && placeAt.x) + "," +
        (placeAt && placeAt.y) + ") is not usable. Nothing was changed — " +
        "your original formula is untouched. Retry with explicit X/Y placement.",
    );
  }
}

// ============================================================
// Detection
// ============================================================

function detectMode(workingDoc) {
  let sel = null;
  try {
    sel = workingDoc.selection;
  } catch (e) {
    return { mode: "fresh" };
  }
  if (!sel || sel.length === 0) return { mode: "fresh" };
  // Multi-select: use the first node but say so in the dialog.
  let primary = null;
  try {
    primary = sel.at(0).node;
  } catch (e) {
    return { mode: "fresh" };
  }
  if (!primary) return { mode: "fresh" };

  const found = findOurFormulaAncestor(primary);
  if (found) {
    let pos = null;
    try {
      const box =
        found.node.spreadVisibleBox || found.node.getSpreadBaseBox(false);
      if (box) {
        const cand = { x: box.x, y: box.y };
        if (isSanePlacement(workingDoc, cand)) {
          pos = cand;
        } else {
          log(
            "Stale re-edit position (" + cand.x + "," + cand.y +
              ") rejected — falling back to default placement. " +
              "The old formula is still replaced, just not at garbage coords.",
          );
        }
      }
    } catch (e) {
      /* ignore */
    }
    let label = null;
    try {
      label = found.node.name || found.node.description || null;
    } catch (e) {
      /* ignore */
    }
    return {
      mode: "reedit",
      source: found.source,
      settings: readFormulaSettings(found.node),
      oldFormulaNode: found.node,
      pos: pos,
      multi: sel.length > 1,
      label: label,
    };
  }
  // Something else is selected (not our formula): fresh insert, but say so.
  return { mode: "fresh", selCount: sel.length };
}

// ============================================================
// Entry
// ============================================================

(function main() {
  try {
    const workingDoc = Document.current;
    if (!workingDoc) {
      app.alert(
        "Open a document first, then run " + TOOL_NAME + " again.",
        TOOL_NAME,
      );
      return;
    }

    // Fail fast on broken library setup: instructions before any dialog.
    // Bundle source stays cached for the render step below.
    if (!checkBundleSetup()) return;

    log(TOOL_NAME + " v" + TOOL_VERSION);

    const detection = detectMode(workingDoc);
    log("Mode: " + detection.mode);

    const defPos = defaultPlacementPosition(workingDoc);
    const state = {
      latex: "",
      exampleIndex: 0,
      settings: {
        fontSize: CONFIG.DEFAULT_FONT_SIZE,
        colourRGBA: {
          r: CONFIG.DEFAULT_COLOUR_RGBA.r,
          g: CONFIG.DEFAULT_COLOUR_RGBA.g,
          b: CONFIG.DEFAULT_COLOUR_RGBA.b,
          alpha: CONFIG.DEFAULT_COLOUR_RGBA.alpha,
        },
        display: !!CONFIG.DEFAULT_DISPLAY,
        keepSingleObject: !!CONFIG.DEFAULT_KEEP_SINGLE_OBJECT,
      },
      placeX: defPos.x,
      placeY: defPos.y,
      reeditLabel: null,
    };
    let originalPos = null;
    let thingToDelete = null;

    if (detection.mode === "reedit") {
      state.latex = detection.source;
      state.settings = detection.settings;
      originalPos = detection.pos;
      thingToDelete = detection.oldFormulaNode;
      state.reeditLabel =
        (detection.label ? '"' + detection.label + '" — ' : "") +
        "re-render with your new settings. The original is kept if you Cancel." +
        (detection.multi ? " (Multiple objects selected — using the first formula found.)" : "");
    } else if (detection.selCount > 0) {
      log("Selection is not one of our formulas — fresh insert");
    }

    let statusForNextDialog = null;
    let attempts = 0;
    const MAX_ATTEMPTS = CONFIG.MAX_ATTEMPTS;

    while (attempts < MAX_ATTEMPTS) {
      attempts++;
      log("Attempt " + attempts);

      const dialogResult = runDialogOnce(
        workingDoc,
        state,
        detection.mode === "reedit",
        statusForNextDialog,
        originalPos,
      );
      if (!dialogResult) {
        log("User cancelled");
        return;
      }

      // Legacy fallback: if the live example loader (see runDialogOnce)
      // is unsupported by the SDK, the source box still holds the old
      // text at OK time — load the example and re-show once so the user
      // sees it before rendering. With live loading this never fires:
      // the source already contains the example code.
      if (
        !dialogResult.exampleLiveApplied &&
        dialogResult.exampleIndex > 0 &&
        (!dialogResult.latex ||
          dialogResult.latex === state.latex ||
          dialogResult.latex === "" ||
          dialogResult.latex === "E = mc^2")
      ) {
        const ex = EXAMPLES[dialogResult.exampleIndex];
        if (ex && ex.code) {
          state.latex = ex.code;
          state.settings = dialogResult.settings;
          state.exampleIndex = 0;
          state.placeX = dialogResult.placeX;
          state.placeY = dialogResult.placeY;
          statusForNextDialog =
            "Example loaded (" + ex.label + ") — review it above, then OK to render.";
          // Don't count example-loading against the retry budget.
          attempts--;
          continue;
        }
      }

      state.latex = dialogResult.latex;
      state.settings = dialogResult.settings;
      state.exampleIndex = 0;
      state.placeX = dialogResult.placeX;
      state.placeY = dialogResult.placeY;

      if (!state.latex) {
        statusForNextDialog = "Source is empty — type a formula or pick an example first.";
        continue;
      }

      log(
        "Dialog committed: latex.len=" +
          state.latex.length +
          " fontSize=" +
          state.settings.fontSize +
          " display=" +
          state.settings.display +
          " single=" +
          state.settings.keepSingleObject +
          " colour=" +
          state.settings.colourRGBA.r +
          "," +
          state.settings.colourRGBA.g +
          "," +
          state.settings.colourRGBA.b +
          " placeSrc=" +
          (originalPos
            ? "reedit(" + originalPos.x + "," + originalPos.y + ")"
            : "fresh(" + state.placeX + "," + state.placeY + ")"),
      );

      let harvested;
      let droppedText = 0;
      let forcedGroup = false;
      try {
        const t0 = Date.now();
        const out = renderAndHarvest(state.latex, state.settings);
        harvested = out.harvested;
        droppedText = out.droppedText | 0;
        const crossings = out.crossings | 0;
        // Crossing strokes (cancel through glyphs, X centers) would void
        // under merged fill: route to the proven group path instead.
        // The choice is logged and reported, never silent.
        if (state.settings.keepSingleObject && crossings > 0) {
          forcedGroup = true;
          state.settings = Object.assign({}, state.settings, {
            keepSingleObject: false,
          });
          log(
            "Crossing strokes detected (" + crossings + " pairs) — " +
              "placing as an editable group so overlaps survive.",
          );
        }
        log(
          "Render OK: " +
            harvested.length +
            " glyphs in " +
            (Date.now() - t0) +
            "ms" +
            (droppedText > 0 ? " (skipped " + droppedText + " outline-less characters)" : ""),
        );
      } catch (err) {
        const msg = err && err.message ? err.message : String(err);
        log("Render error: " + msg);
        statusForNextDialog = friendlyRenderError(msg);
        continue;
      }

      const placeAt =
        originalPos || { x: state.placeX, y: state.placeY };
      const ins = insertAndCommit(
        workingDoc,
        state.latex,
        state.settings,
        harvested,
        placeAt,
        thingToDelete,
      );
      void ins;

      if (CONFIG.SUCCESS_ALERT) {
        const verb = detection.mode === "reedit" ? "Re-rendered" : "Inserted";
        const shapeNote = ins && ins.single
          ? "1 object (" + ins.outlines + " outlines)"
          : harvested.length + " shapes";
        const droppedNote = droppedText > 0
          ? "\n\nNote: " + droppedText + " character(s) had no vector outline " +
            "(e.g. upright Greek, ℃, €, \\unicode) and were skipped — see the guide's workarounds."
          : "";
        const crossNote = forcedGroup
          ? "\n\nNote: crossing strokes detected — placed as an editable " +
            "group so overlaps survive (single fill would void them)."
          : "";
        app.alert(
          verb +
            " formula (" +
            shapeNote +
            ", " +
            state.settings.fontSize +
            "pt" +
            (state.settings.display ? ", display" : ", inline") +
            ") at X " +
            Math.round(placeAt.x) +
            ", Y " +
            Math.round(placeAt.y) +
            "." +
            droppedNote +
            crossNote +
            "\n\n" +
            "To edit later: select the formula — any part of it — and run " +
            TOOL_NAME +
            " again.",
          TOOL_NAME,
        );
      }
      return;
    }

    // Retry budget exhausted: a preview from the last dialog may still
    // be showing — clear it before reporting, so nothing lingers.
    try {
      workingDoc.clearPreviews();
    } catch (e) {
      /* ignore */
    }
    app.alert(
      "Still failing after " + MAX_ATTEMPTS + " attempts — nothing was changed.\n" +
        "Try a simpler LaTeX expression, or pick an example from the dropdown to check the setup.",
      TOOL_NAME,
    );
  } catch (err) {
    const msg = err && err.message ? err.message : String(err);
    log("FAILED: " + msg);
    if (err && err.stack) console.log(err.stack);
    try {
      if (workingDoc) workingDoc.clearPreviews();
    } catch (e) {
      /* ignore */
    }
    app.alert("Error: " + msg, TOOL_NAME);
  }
})();
