/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    bringhurst-kerning-highlighter.js
Description:    Recreates the kerning test page from Bringhurst's "The Elements of Typographic Style" (4th ed.). Places a text frame on the current spread with kerning-problem pairs highlighted and italic runs italicised.

Author:         Les Pruszynski (Middledot)
Version:        1.1.0
Created:        —
Last updated:   04/10/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/



'use strict';

const { Document } = require("/document");
const { NodeChildType, FrameTextNodeDefinition } = require("/nodes");
const { StoryDelta } = require("/storydelta");
const { StoryBuilder } = require("/storybuilder");
const { Selection, TextSelection } = require("/selections");
const { RGBA8 } = require("/colours");
const { FillDescriptor } = require("/fills");
const Commands = require("/commands");
const { AddChildNodesCommandBuilder } = Commands;
const { Dialog, DialogResult } = require("/dialog");
const { UnitType } = require("/units");
const { Rectangle } = require("/geometry");

function showAlert(msg, title) {
    try {
        const { app } = require('/application');
        app.alert(msg, title || "Bringhurst's Kerning Highlighter");
    } catch (e) {
        try { alert(msg); } catch (_) {}
    }
}

function isModalOk(res) {
    try {
        if (res == DialogResult.Ok) return true;
        if (res && res.value === DialogResult.Ok.value) return true;
    } catch (e) {}
    return false;
}

// ============================================================
// CONFIGURATION
// Test text from Bringhurst, "Elements of Typographic Style" 4th ed.
// ============================================================
const TEST_TEXT = `“Ask Jeff” or ‘Ask Jeff’. Take the chef d’œuvre!
Two of [of] (of) ‘of’ “of” of? of! of*. Two of
[of] (of) ‘of’ “of” of? of! of*. Ydes, Yffignac
Ygrande, Les Woëvres, the Fôret de Wœvres,
the Voire and Vauvise are in France, but Ypress is
in Belgium. Yves is in heaven; D’Amboise is in
jail. Lyford’s in Texas & L’Anse-aux-Griffons in
Québec; the Łyna in Poland. Yriarte, Yciar and
Ysaûe are at Yale. Kyoto and Ryotsu are both
in Japan, Kwikpak on the Yukon delta, Kvæven
in Norway, Kyulu in Kenya, not in Rwanda.…
Walton’s in West Virginia, but «Wren» is in
Oregon. Tlalpan is near Xochimilco in México,
The Zygos & Xylophagou are in Cyprus. Zwettl
in Austria, Fænø in Denmark, the Vøringsfossen
and Værøy in Norway. Tchula is in Mississippi,
the Tittabawassee in Michigan. Twodot is here
in Montana, Ywamun in Burma. Yggdrasil and
Ymir, Yngvi and Vóden, Vídrð and Skeggjöld
and Týr are all in the Eddas. Tørberget and Våg,
of course, are in Norway, Ktipas and Tmolos
in Greece, but Vázquez is in Argentina, Vreden
in Germany, Von-Vincke-Straße in Münster,
Vdovino in Russia, Ytterbium in the periodic
table. Are Toussaint L’Ouverture, Wölfflin,
Wolfe, Miłosz and Wū Wǔ all in the library?
1510–1620, 11:00 pm, and the 1980s are over.`;

// ============================================================
// KERNING PAIR POSITIONS
// To be updated once highlights are re-applied in Affinity.
// ============================================================
const KERNING_PAIRS = [
  0, // “A
  8, // f”
  14, // ‘A
  23, // ’.
  28, // ke
  40, // d’
  41, // ’œ
  58, // f]
  63, // f)
  68, // f’
  73, // f”
  77, // f?
  85, // f*
  98, // f]
  103, // f)
  113, // f”
  117, // f?
  121, // f!
  125, // f*
  129, // Yd
  135, // Yf
  144, // Yg
  170, // Fô
  179, // Wœ
  250, // Yv
  263, // av
  264, // ve
  270, // ’A
  311, // L’
  312, // ’A
  362, // Yr
  371, // Yc
  381, // Ys
  384, // ûe
  394, // Ya
  400, // Ky
  411, // yo
  436, // Kw
  453, // ko
  464, // Kv
  482, // Ky
  494, // ya
  505, // Rw
  510, // a.
  545, // «W
  549, // n»
  582, // Xo
  608, // Zy
  609, // yg
  616, // Xy
  642, // Zw
  652, // Au
  661, // Fæ
  682, // Vø
  700, // Væ
  717, // Tc
  801, // Yw
  818, // Yg
  832, // Ym
  838, // Yn
  848, // Vó
  855, // Ví
  866, // ke
  869, // gj
  880, // ýr
  905, // Tø
  919, // Vå
  950, // Kt
  961, // Tm
  983, // Vá
  1030, // n-
  1057, // Vd
  1076, // Yt
  1123, // L’
  1124, // ’O
  1136, // Wö
  1167, // Wǔ
  1190, // 15
  1191, // 51
  1192, // 10
  1193, // 0–
  1194, // –1
  1195, // 16
  1201, // 11
  1202, // 1:
  1203, // :0
  1204, // 00
  1219, // 19
  1222, // 0s
];

// Italic ranges verified from source document.
// Each entry is { begin, end } in story indices.
const ITALIC_RANGES = [
  { begin: 89, end: 126 }, // "Two of ... of*" — lines 2 & 3
];

// ============================================================
// HELPERS
// ============================================================
const MARGIN_MM = 10;

function mmToPx(mm, dpi) {
  return (mm * dpi) / 25.4;
}
function pxToMm(px, dpi) {
  return (px * 25.4) / dpi;
}

// ============================================================
// MAIN ENTRY POINT
// ============================================================
function main() {
  const doc = Document.current;
  if (!doc) {
    showAlert("Open a document first.");
    return;
  }

  const DEFAULT_HIGHLIGHT = RGBA8(200, 200, 200, 255);
  const DEFAULT_FONT_SIZE_PT = 10;

  // Dialog
  const dlg = Dialog.create("Bringhurst's Kerning Highlighter");
  const col = dlg.addColumn();

  const gFont = col.addGroup("Font");
  const fontPick = gFont.addFontPicker("Family");
  fontPick.isFullWidth = true;

  const gSize = col.addGroup("Size");
  const sizePick = gSize.addUnitValueEditor(
    "Size",
    UnitType.Point,
    UnitType.Point,
    DEFAULT_FONT_SIZE_PT,
    4,
    144,
  );

  const gColour = col.addGroup("Highlight Colour");
  const colourPick = gColour.addColourPicker("Colour", DEFAULT_HIGHLIGHT);

  if (!isModalOk(dlg.runModal())) {
    console.log("Bringhurst's Kerning Highlighter: cancelled.");
    return;
  }

  const chosenColour = colourPick.value || DEFAULT_HIGHLIGHT;
  const chosenSizePt = sizePick.value || DEFAULT_FONT_SIZE_PT;
  const chosenSizePx = chosenSizePt * (doc.dpi / 72);
  const chosenFamily = fontPick.fontFamily;

  if (!chosenFamily) {
    showAlert("Please choose a font family before applying.");
    return;
  }

  const dpi = doc.dpi;

  // Frame dimensions (page minus margins, all in pixels)
  const spread = [...doc.spreads][0];
  const extents = spread.getSpreadExtents({ includeSpread: true });
  const marginPx = mmToPx(MARGIN_MM, dpi);
  const frameW = extents.width - marginPx * 2;
  const frameH = extents.height - marginPx * 2;

  console.log(
    "Page:  " +
      pxToMm(extents.width, dpi).toFixed(1) +
      " x " +
      pxToMm(extents.height, dpi).toFixed(1) +
      " mm",
  );
  console.log(
    "Frame: " +
      pxToMm(frameW, dpi).toFixed(1) +
      " x " +
      pxToMm(frameH, dpi).toFixed(1) +
      " mm",
  );

  // Create text frame
  const builder = StoryBuilder.create();
  builder.setToFrameTextDefaultStyle(72, 0);
  builder.applyGlyphDelta(StoryDelta.createFamilyName(chosenFamily.name));
  builder.applyGlyphDelta(
    StoryDelta.createGlyphDouble("FontSize", chosenSizePx),
  );
  builder.addText(TEST_TEXT);

  const nodeDef = FrameTextNodeDefinition.createFromStoryBuilder(
    new Rectangle(marginPx, marginPx, frameW, frameH),
    builder,
  );

  const cmdBuilder = AddChildNodesCommandBuilder.create();
  cmdBuilder.addNode(nodeDef);
  doc.executeCommand(cmdBuilder.createCommand(true, NodeChildType.Main));

  // Retrieve the newly created frame from the selection
  let frame = null;
  for (const item of doc.selection.items) {
    if (item.node && item.node.isTextNode) {
      frame = item.node;
      break;
    }
  }
  if (!frame) {
    showAlert("Text frame creation failed.");
    return;
  }

  const story = frame.storyInterface.story;
  const storyLen = story.length;

  // Apply italic
  for (const r of ITALIC_RANGES) {
    if (r.end <= storyLen) {
      const sel = Selection.create(doc, frame);
      sel.addSubSelectionForNode(
        frame,
        TextSelection.create([{ begin: r.begin, end: r.end }]),
      );
      doc.executeCommand(
        Commands.DocumentCommand.createFormatText(
          sel,
          StoryDelta.createItalic(true),
        ),
      );
    }
  }

  // Apply highlights
  const ranges = [];
  for (const start of KERNING_PAIRS) {
    const end = start + 2;
    if (end <= storyLen) ranges.push({ begin: start, end });
  }

  if (ranges.length) {
    const sel = Selection.create(doc, frame);
    sel.addSubSelectionForNode(frame, TextSelection.create(ranges));
    doc.executeCommand(
      Commands.DocumentCommand.createFormatText(
        sel,
        StoryDelta.createHighlightFill(
          FillDescriptor.createSolid(chosenColour),
        ),
      ),
    );
  }

  console.log(
    "Applied " +
      ranges.length +
      " highlights and " +
      ITALIC_RANGES.length +
      " italic runs — " +
      chosenFamily.name +
      " " +
      chosenSizePt.toFixed(1) +
       "pt.",
  );
}

try { main(); } catch (e) {
    showAlert('Script error:\n' + (e && e.message ? e.message : e), "Bringhurst's Kerning Highlighter");
}
