/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    sudoku-generator.js
Description:    Generates a Sudoku puzzle and draws it onto the current document. If no document is open, a new A4 portrait document at 300 dpi is created automatically.

Author:         Les Pruszynski (Middledot)
Version:        2.0.0
Created:        —
Last updated:   27/10/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/

'use strict';

const { app } = require('/application');
const { Document, NewDocumentOptions, DocumentPreset } = require('/document');
const { AddChildNodesCommandBuilder } = require('/commands');
const { Dialog, DialogResult } = require('/dialog');
const { ShapeNodeDefinition, ArtTextNodeDefinition, ContainerNodeDefinition, NodeChildType } = require('/nodes');
const { ShapeRectangle } = require('/shapes');
const { FillDescriptor } = require('/fills');
const {
    LineStyle, LineStyleDescriptor,
    LineCap, LineJoin,
} = require('/linestyle');
const { RGBA8 } = require('/colours');
const { StoryBuilder } = require('/storybuilder');
const { GlyphAttDoubleType } = require('/glyphatts');
const { ParagraphAlignXType } = require('/paragraphatts');
const { Font, FontFamily } = require('/fonts');
const { UnitType } = require('/units');
const { Selection } = require('/selections');

const CONFIG = {
  GRID_MIN_MM: 40,
  GRID_MAX_MM: 500,
  GRID_DEFAULT_PCT: 0.6,
  FONT_POLL_MS: 350,
  PAGE_MARGIN_MM: 10,
  TITLE_ALLOWANCE_MM: { show: 22, hide: 6 },
  DIFFICULTIES: [
    { name: 'Easy',   empty: 36 },
    { name: 'Medium', empty: 46 },
    { name: 'Hard',   empty: 52 },
    { name: 'Expert', empty: 58 },
  ],
  FONT_PREFERENCE: ['Helvetica Neue', 'Helvetica', 'Avenir Next', 'Avenir',
    'SF Pro Display', 'Arial', 'Verdana'],
  CELL_STROKE_WEIGHT: 0.6,
  BOX_STROKE_WEIGHT: 2.0,
  OUTER_STROKE_WEIGHT: 2.5,
  TITLE_SIZE_MIN_PT: 14,
  TITLE_SIZE_MAX_PT: 28,
  TITLE_SIZE_SCALE: 0.13,
  TITLE_Y_OFFSET: 0.07,
  TITLE_Y_OFFSET_MIN_MM: 3,
  REFERENCE_GRID_MM: 180,
  DEFAULT_DPI: 300,
  A4_MM: { width: 210, height: 297 },
};

// ---------------------------------------------------------------------------
// Puzzle generation (backtracking + unique-solution dig)
// ---------------------------------------------------------------------------

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function isValid(g, row, col, n) {
    for (let i = 0; i < 9; i++) {
        if (g[row][i] === n) return false;
        if (g[i][col] === n) return false;
    }
    const br = Math.floor(row / 3) * 3;
    const bc = Math.floor(col / 3) * 3;
    for (let r = br; r < br + 3; r++)
        for (let c = bc; c < bc + 3; c++)
            if (g[r][c] === n) return false;
    return true;
}

function fillGrid(g) {
    for (let row = 0; row < 9; row++)
        for (let col = 0; col < 9; col++)
            if (g[row][col] === 0) {
                const nums = shuffle([1,2,3,4,5,6,7,8,9]);
                for (const n of nums) {
                    if (isValid(g, row, col, n)) {
                        g[row][col] = n;
                        if (fillGrid(g)) return true;
                        g[row][col] = 0;
                    }
                }
                return false;
            }
    return true;
}

function countSolutions(g, limit) {
    for (let row = 0; row < 9; row++)
        for (let col = 0; col < 9; col++)
            if (g[row][col] === 0) {
                let total = 0;
                for (let n = 1; n <= 9; n++) {
                    if (isValid(g, row, col, n)) {
                        g[row][col] = n;
                        total += countSolutions(g, limit - total);
                        g[row][col] = 0;
                        if (total >= limit) return total;
                    }
                }
                return total;
            }
    return 1;
}

function cloneGrid(g) { return g.map(r => r.slice()); }

function generateSudoku(targetEmpty) {
    const solution = Array.from({ length: 9 }, () => Array(9).fill(0));
    fillGrid(solution);
    const puzzle = cloneGrid(solution);
    const positions = shuffle(Array.from({ length: 81 }, (_, i) => i));
    let removed = 0;
    for (const p of positions) {
        if (removed >= targetEmpty) break;
        const r = Math.floor(p / 9), c = p % 9;
        const saved = puzzle[r][c];
        puzzle[r][c] = 0;
        const trial = cloneGrid(puzzle);
        if (countSolutions(trial, 2) !== 1) puzzle[r][c] = saved;
        else removed++;
    }
    return { puzzle, solution, removed };
}

// ---------------------------------------------------------------------------
// Dialog
// ---------------------------------------------------------------------------

const DIFFICULTIES = [
    { name: 'Easy',   empty: 36 },
    { name: 'Medium', empty: 46 },
    { name: 'Hard',   empty: 52 },
    { name: 'Expert', empty: 58 },
];

function buildDialog(defaultGridMm, maxGridMm) {
    const dlg = Dialog.create('Generate Sudoku');
    const col = dlg.addColumn();
    const g1 = col.addGroup('Puzzle');
    dlg.difficulty = g1.addComboBox('Difficulty', CONFIG.DIFFICULTIES.map(d => d.name), 1);

    // Full-width checkboxes start flush at the dialog's left edge rather
    // than aligned under where combo-box/unit-editor values begin.
    const gTitle = col.addGroup('Title');
    dlg.showTitle = gTitle.addCheckBox('Show title above grid', true).setIsFullWidth(true);
    dlg.showDifficultyInTitle = gTitle.addCheckBox('Show the difficulty level in the title', true).setIsFullWidth(true);
    dlg.titleOnSeparateLayer = gTitle.addCheckBox('Title on a separate layer', false).setIsFullWidth(true);

    const g2 = col.addGroup('Layout');
    dlg.gridSize = g2.addUnitValueEditor(
        'Grid size', UnitType.Millimetre, UnitType.Millimetre,
        defaultGridMm, CONFIG.GRID_MIN_MM, maxGridMm
    ).setPrecision(1).setShowPopupSlider(true);

    const g3 = col.addGroup('Font');
    dlg.fontPicker = g3.addFontPicker('Choose font');
    const defaultFont = pickFontFromFamily(pickFontFamily());
    if (defaultFont) dlg.fontPicker.setFont(defaultFont);

    return dlg;
}

// ---------------------------------------------------------------------------
// Font / drawing helpers
// ---------------------------------------------------------------------------

function pickFontFamily() {
    for (const name of CONFIG.FONT_PREFERENCE) {
        const fam = FontFamily.all.find(f => f.name === name);
        if (fam) return fam;
    }
    return FontFamily.all[0] || null;
}

// Font.create() always throws INVALID_ARGS in this SDK regardless of which
// fonts are installed (see docs/sdk-issues.md BUG-023; same bug worked
// around in html-importer.js). Resolve a concrete Font via FontFamily
// lookup instead.
//
// Biases toward bold/semibold over regular: a regular weight reads too
// light for sudoku clue numbers. Falls back to regular, then the family's
// first font, if no bold variant exists.
function pickFontFromFamily(fam) {
    const fonts = fam && fam.fonts;
    if (!fonts || fonts.length === 0) return Font.createDefault();
    return fonts.find(f => f.isBold && !f.isItalic)
        || fonts.find(f => !f.isBold && !f.isItalic)
        || fonts[0];
}

// Resolve the font to draw with from the dialog's font picker. The picker
// is pre-populated with the auto-detected default (see buildDialog), so it
// is never actually blank when the dialog opens — but the fallback chain
// below still covers the control somehow reporting nothing. An exact style
// the user picked (or the pre-set default, left unchanged) is honored
// as-is; a family-only pick goes through the bold-preferring
// pickFontFromFamily().
function resolveFont(dlg) {
    if (dlg.fontPicker.font) return dlg.fontPicker.font;
    const fam = dlg.fontPicker.fontFamily || pickFontFamily();
    return pickFontFromFamily(fam);
}

function makeRectDef(x, y, w, h, fill, stroke, lineStyleDesc) {
    const def = ShapeNodeDefinition.createDefault();
    def.shape = ShapeRectangle.create();
    def.setBoundingRectangle({ x, y, width: w, height: h });
    if (fill) def.addBrushFillDescriptor(FillDescriptor.createSolid(fill));
    if (stroke && lineStyleDesc)
        def.addLineDescriptors(FillDescriptor.createSolid(stroke), lineStyleDesc);
    return def;
}

function makeLineStyleDesc(weightPx) {
    const ls = LineStyle.createDefaultWithWeight(weightPx);
    ls.cap = LineCap.Butt;
    ls.join = LineJoin.Miter;
    return LineStyleDescriptor.create(ls, { isScale: true }); // scale-with-object ON
}

function makeTextStory(doc, text, sizePx, font, colour) {
    const sb = StoryBuilder.create();
    sb.setToArtisticTextDefaultStyle(doc.dpi, doc.format);
    const ga = sb.glyphAtts.clone();
    ga.setDoubleValue(GlyphAttDoubleType.Height, sizePx);
    if (font) ga.font = font;
    ga.brushFill = FillDescriptor.createSolid(colour);
    sb.setGlyphAtts(ga);
    const pa = sb.paragraphAtts.clone();
    pa.alignXType = ParagraphAlignXType.Centre;
    sb.setParagraphAtts(pa);
    sb.addText(text);
    return sb;
}

// Create a named container and return it (barcode-generator pattern — see
// docs/sdk-issues.md BUG-024: the container must be committed via its own
// executeCommand before its node reference exists to target children at).
function createContainer(doc, name) {
    const cb = AddChildNodesCommandBuilder.create();
    cb.addContainerNode(ContainerNodeDefinition.create(name));
    const cmd = cb.createCommand(false);
    doc.executeCommand(cmd);
    return cmd.newNodes[0];
}

// ---------------------------------------------------------------------------
// Draw the puzzle into the document
// ---------------------------------------------------------------------------

function drawPuzzle(doc, puzzle, originXmm, originYmm, sizeMm, title, font, groupName, preview, titleOnSeparateLayer) {
    const dpi = doc.dpi;
    const mm2px = dpi / 25.4;
    const xPx = originXmm * mm2px;
    const yPx = originYmm * mm2px;
    const sizePx = sizeMm * mm2px;
    const cellPx = sizePx / 9;

    const ls = sizeMm / CONFIG.REFERENCE_GRID_MM;

    const black = RGBA8(0, 0, 0, 255);
    const white = RGBA8(255, 255, 255, 255);

    const ptsToPx = dpi / 72;

    const cellDesc = makeLineStyleDesc(CONFIG.CELL_STROKE_WEIGHT * ls * ptsToPx);
    const boxDesc  = makeLineStyleDesc(CONFIG.BOX_STROKE_WEIGHT * ls * ptsToPx);
    const outDesc  = makeLineStyleDesc(CONFIG.OUTER_STROKE_WEIGHT * ls * ptsToPx);

    // Clue numbers + optional title: content and target cell/title centre,
    // no nodes created yet (their rendered size isn't known until a text
    // node with this content/font/size actually exists — see below).
    const fontPx = cellPx * 0.55;
    const textSpecs = [];
    for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
            const v = puzzle[r][c];
            if (!v) continue;
            textSpecs.push({
                text: String(v), sizePx: fontPx,
                cx: xPx + (c + 0.5) * cellPx,
                cy: yPx + (r + 0.5) * cellPx,
            });
        }
    }
    let titleSpecIndex = -1;
    if (title) {
        titleSpecIndex = textSpecs.length;
        const titlePts = Math.max(CONFIG.TITLE_SIZE_MIN_PT, Math.min(CONFIG.TITLE_SIZE_MAX_PT, sizeMm * CONFIG.TITLE_SIZE_SCALE));
        textSpecs.push({
            text: title, sizePx: titlePts * (dpi / 72),
            cx: xPx + sizePx / 2,
            cy: yPx - Math.max(CONFIG.TITLE_Y_OFFSET_MIN_MM, sizeMm * CONFIG.TITLE_Y_OFFSET) * mm2px,
        });
    }
    // Only meaningful with an actual title; drawn flat during preview
    // either way (preview never groups anything, so there's nothing to
    // visibly separate until the real commit).
    const separateTitle = titleSpecIndex !== -1 && !!titleOnSeparateLayer;

    // DocumentCommand.newNodes/enumerateNewNodes only resolves AFTER a
    // command has actually been executed (reading it beforehand throws
    // INVALID_OP or returns undefined) — so a text node's true rendered
    // bounding box can't be known until it exists in the document. Measure
    // it with a throwaway PREVIEW execution (never enters undo history,
    // reverted by clearPreviews), then build the real nodes already
    // positioned at their final, centred coordinates in ONE command, so
    // the whole puzzle still commits as a single undo step.
    const measureBuilder = AddChildNodesCommandBuilder.create();
    textSpecs.forEach(spec => {
        const sb = makeTextStory(doc, spec.text, spec.sizePx, font, black);
        measureBuilder.addNode(ArtTextNodeDefinition.createFromStoryBuilder({ x: -1000000, y: -1000000 }, sb));
    });
    const measureCmd = measureBuilder.createCommand();
    doc.executeCommand(measureCmd, true);
    const offsets = measureCmd.newNodes.filter(n => n.isArtTextNode).toReversed().map(tn => {
        const bb = tn.spreadVisibleBox;
        return { ox: bb.x + 1000000, oy: bb.y + 1000000, width: bb.width, height: bb.height };
    });
    doc.clearPreviews();

    // Creating the named container is itself a real, non-preview command —
    // calling it on every live-preview tick would spam undo history. During
    // preview the shapes draw flat on the spread with no container; grouping
    // only happens on the final (preview === false) commit.
    const container = preview ? null : createContainer(doc, groupName);
    const builder = AddChildNodesCommandBuilder.create();
    builder.autoName = false;
    if (!preview) builder.setInsertionTarget(container);

    // 81 cell rectangles (white fill = background).
    for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
            builder.addShapeNode(makeRectDef(
                xPx + c * cellPx, yPx + r * cellPx, cellPx, cellPx,
                white, black, cellDesc
            ));
        }
    }

    // Nine 3x3-box outlines.
    for (let br = 0; br < 3; br++) {
        for (let bc = 0; bc < 3; bc++) {
            builder.addShapeNode(makeRectDef(
                xPx + bc * 3 * cellPx, yPx + br * 3 * cellPx,
                3 * cellPx, 3 * cellPx,
                null, black, boxDesc
            ));
        }
    }

    // Outer border on top (no fill, just stroke).
    builder.addShapeNode(makeRectDef(
        xPx, yPx, sizePx, sizePx, null, black, outDesc
    ));

    // Clue numbers and title, created directly at their final centred
    // position (derived from the measured offsets above) — no post-hoc
    // transform pass needed.
    const placeText = (targetBuilder, i) => {
        const spec = textSpecs[i];
        const off = offsets[i];
        const sb = makeTextStory(doc, spec.text, spec.sizePx, font, black);
        const x = spec.cx - off.width / 2 - off.ox;
        const y = spec.cy - off.height / 2 - off.oy;
        targetBuilder.addNode(ArtTextNodeDefinition.createFromStoryBuilder({ x, y }, sb));
    };

    // On the real commit, a separated title is left out of the grouped
    // builder and added afterward as its own ungrouped node instead; during
    // preview it always stays in the one flat builder regardless (nothing
    // is ever grouped in preview, so there's nothing to separate yet).
    textSpecs.forEach((spec, i) => {
        if (i === titleSpecIndex && separateTitle && !preview) return;
        placeText(builder, i);
    });

    doc.executeCommand(builder.createCommand(false), preview);

    if (separateTitle && !preview) {
        const titleBuilder = AddChildNodesCommandBuilder.create();
        placeText(titleBuilder, titleSpecIndex);
        const titleCmd = titleBuilder.createCommand(false);
        doc.executeCommand(titleCmd);
        // Fixed name rather than relying on content-based auto-naming —
        // "Sudoku" or the difficulty name alone would be easy to mistake
        // for the puzzle's own sudoku-<Difficulty> container.
        const titleNode = titleCmd.newNodes && titleCmd.newNodes[0];
        if (titleNode) titleNode.name = 'Sudoku title';
    }
}

// ---------------------------------------------------------------------------
// Document handling
// ---------------------------------------------------------------------------

function ensureDocument() {
    const doc = Document.current;
    if (doc) return doc;
    const presets = DocumentPreset.all;
    if (presets.length === 0) {
        throw new Error("No document presets available; can't auto-create A4.");
    }
    const opts = NewDocumentOptions.createFromPreset(presets[0]);
    opts.units = UnitType.Millimetre;
    opts.width = CONFIG.A4_MM.width;
    opts.height = CONFIG.A4_MM.height;
    opts.isLandscape = false;
    opts.dpi = CONFIG.DEFAULT_DPI;
    opts.bleed = { left: 0, right: 0, top: 0, bottom: 0 };
    return Document.createFromOptions(opts);
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

function main() {
    try {
        const doc = ensureDocument();
        const dpi = doc.dpi;
        const mm2px = dpi / 25.4;
        const pageWmm = doc.widthPixels / mm2px;
        const pageHmm = doc.heightPixels / mm2px;

        // Worst-case (title shown) page-fit cap — the dialog's own
        // min/max bounds can't be changed after creation, so this is
        // fixed once here rather than tracking the title checkboxes live.
        const maxFitMm = Math.min(
            pageWmm - CONFIG.PAGE_MARGIN_MM * 2,
            pageHmm - CONFIG.TITLE_ALLOWANCE_MM.show - CONFIG.PAGE_MARGIN_MM * 2
        );
        const sliderMaxMm = Math.min(CONFIG.GRID_MAX_MM, Math.max(CONFIG.GRID_MIN_MM, maxFitMm));
        const defaultMm = Math.min(sliderMaxMm, Math.max(CONFIG.GRID_MIN_MM, Math.round(maxFitMm * CONFIG.GRID_DEFAULT_PCT)));

        const dlg = buildDialog(defaultMm, sliderMaxMm);

        // Live preview: redraw on canvas as dialog controls change, before
        // OK is clicked (see docs/sdk-issues.md BUG-017/BUG-018 and the
        // barcode-generator/pinned-vertical-line precedent this mirrors).
        // Puzzle generation is stochastic (Math.random()-driven backtracking
        // in generateSudoku()), so the grid is cached and only regenerated
        // when the difficulty selection actually changes — otherwise every
        // grid-size/title/font tick would scramble all 81 clue numbers.
        let cachedDiffIdx = -1;
        let cachedPuzzle = null;

        function computeLayout() {
            const diff = CONFIG.DIFFICULTIES[dlg.difficulty.selectedIndex];
            const includeTitle = dlg.showTitle.value;
            const includeDifficultyInTitle = dlg.showDifficultyInTitle.value;
            const requestedMm = dlg.gridSize.value;

            // The two checkboxes are independent: either can produce a
            // title line on its own. "Sudoku · <Difficulty>" only when both
            // are on; the bullet is dropped whenever only one side is shown.
            let titleText = null;
            if (includeTitle && includeDifficultyInTitle) titleText = `Sudoku \xB7 ${diff.name}`;
            else if (includeTitle) titleText = 'Sudoku';
            else if (includeDifficultyInTitle) titleText = diff.name;
            const hasTitle = titleText !== null;

            const titleAllowanceMm = hasTitle ? CONFIG.TITLE_ALLOWANCE_MM.show : CONFIG.TITLE_ALLOWANCE_MM.hide;
            const maxW = pageWmm - CONFIG.PAGE_MARGIN_MM * 2;
            const maxH = pageHmm - titleAllowanceMm - CONFIG.PAGE_MARGIN_MM * 2;
            const sizeMm = Math.max(CONFIG.GRID_MIN_MM, Math.min(requestedMm, Math.min(maxW, maxH)));

            const font = resolveFont(dlg);

            if (dlg.difficulty.selectedIndex !== cachedDiffIdx) {
                cachedPuzzle = generateSudoku(diff.empty).puzzle;
                cachedDiffIdx = dlg.difficulty.selectedIndex;
            }

            const totalHmm = sizeMm + (hasTitle ? titleAllowanceMm : 0);
            const xMm = (pageWmm - sizeMm) / 2;
            const yMm = (pageHmm - totalHmm) / 2 + (hasTitle ? titleAllowanceMm : 0);

            const groupName = `sudoku-${diff.name}`;
            // Only meaningful when a title is actually shown; drawPuzzle
            // applies this gate itself too, so passing it through unguarded
            // here is harmless.
            const titleOnSeparateLayer = dlg.titleOnSeparateLayer.value;

            return { puzzle: cachedPuzzle, sizeMm, xMm, yMm, titleText, font, groupName, titleOnSeparateLayer };
        }

        // Stable font identity for change-key comparisons — avoids relying
        // on Font's implicit toString() (untested what it actually returns).
        function fontKeyFor(dlg) {
            const f = dlg.fontPicker.font;
            if (f) return f.postscriptName || f.familyName || '';
            return dlg.fontPicker.text || '';
        }

        let lastPreviewKey = null;

        let lastTitleLayerEnabled = null;

        function refreshPreview() {
            // "Title on a separate layer" only means anything when a title
            // is actually shown — grey it out otherwise. Plain `isEnabled =`
            // sets the model but doesn't repaint the widget on this SDK
            // build (confirmed live: stayed enabled regardless — see
            // docs/sdk-issues.md BUG-026), so a hide/show cycle nudges the
            // redraw — only on actual change, to avoid flickering the
            // control on every tick.
            try {
                const shouldEnable = dlg.showTitle.value || dlg.showDifficultyInTitle.value;
                if (shouldEnable !== lastTitleLayerEnabled) {
                    lastTitleLayerEnabled = shouldEnable;
                    dlg.titleOnSeparateLayer.isEnabled = shouldEnable;
                    dlg.titleOnSeparateLayer.isVisible = false;
                    dlg.titleOnSeparateLayer.isVisible = true;
                }
            } catch (e) {}
            try {
                const layout = computeLayout();
                const key = [cachedDiffIdx, layout.sizeMm, layout.titleText, fontKeyFor(dlg)].join('|');
                if (key === lastPreviewKey) return;
                lastPreviewKey = key;
                drawPuzzle(doc, layout.puzzle, layout.xMm, layout.yMm, layout.sizeMm, layout.titleText, layout.font, layout.groupName, true, layout.titleOnSeparateLayer);
            } catch (e) {
                console.warn('Sudoku preview failed: ' + (e && e.message ? e.message : e));
            }
        }

        function attachTick(ctrl) {
            try {
                if (!ctrl) return;
                if (typeof ctrl.setOnValueChangedHandler === 'function') ctrl.setOnValueChangedHandler(refreshPreview);
                else ctrl.onValueChangedHandler = refreshPreview;
            } catch (e) {}
        }
        attachTick(dlg.difficulty);
        attachTick(dlg.showTitle);
        attachTick(dlg.showDifficultyInTitle);
        attachTick(dlg.gridSize);
        attachTick(dlg.fontPicker);
        try { dlg.onControlValueChangedHandler = refreshPreview; } catch (e) {}

        // FontPicker fires no onValueChangedHandler events on this SDK
        // (same bare-DialogControl inheritance shape as ColourPicker —
        // see docs/sdk-issues.md BUG-025, which also confirms /timers
        // callbacks DO fire while Dialog.runModal() is blocking). Worked
        // around with a poll instead of an event handler. The try/catch
        // stays as a defensive fallback — if a future SDK build ever
        // breaks this, font changes just go back to OK-time-only.
        let fontPollTimer = null;
        try {
            const { setInterval } = require('/timers');
            let lastPolledFontKey = fontKeyFor(dlg);
            fontPollTimer = setInterval(CONFIG.FONT_POLL_MS, () => {
                try {
                    // /timers' setInterval wrapper calls the callback one
                    // more time even when cancelled (ASIO-style: cancelling
                    // a pending wait still delivers a final callback, with
                    // an error the wrapper ignores) — guard with the
                    // dialog's own authoritative state so that trailing
                    // tick can never draw a preview after the dialog has
                    // already closed, which would otherwise strand it on
                    // the canvas with nothing left to clear it.
                    if (!dlg.isRunningModal) return;
                    const key = fontKeyFor(dlg);
                    if (key !== lastPolledFontKey) {
                        lastPolledFontKey = key;
                        refreshPreview();
                    }
                } catch (e) {}
            });
        } catch (e) {
            fontPollTimer = null;
        }

        refreshPreview();

        const result = dlg.runModal();
        if (fontPollTimer) { try { fontPollTimer.cancel(); } catch (e) {} }
        try { doc.clearPreviews(); } catch (e) {}
        if (result != DialogResult.Ok) return;

        const layout = computeLayout();
        drawPuzzle(doc, layout.puzzle, layout.xMm, layout.yMm, layout.sizeMm, layout.titleText, layout.font, layout.groupName, false, layout.titleOnSeparateLayer);
    } catch (e) {
        console.error('Script failed:', e.message);
        const { app } = require('/application');
        app.alert(`Script failed: ${e.message}`, 'Error');
    }
}

try { main(); } catch (e) { console.error('ERROR: ' + (e && e.message ? e.message : e)); }
