/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    sudoku-generator.js
Description:    Generates a Sudoku puzzle and draws it onto the current document. If no document is open, a new A4 portrait document at 300 dpi is created automatically.

Author:         Les Pruszynski (Middledot)
Version:        1.0.1
Created:        —
Last updated:   08/06/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/




'use strict';

const { app } = require('/application');
const { Document, NewDocumentOptions, DocumentPreset } = require('/document');
const {
    CompoundCommandBuilder,
    DocumentCommand,
    AddChildNodesCommandBuilder,
} = require('/commands');
const { Dialog, DialogResult } = require('/dialog');
const { ShapeNodeDefinition, ArtTextNodeDefinition, ContainerNodeDefinition, NodeChildType } = require('/nodes');
const { ShapeRectangle } = require('/shapes');
const { FillDescriptor } = require('/fills');
const {
    LineStyle, LineStyleDescriptor,
    LineCap, LineJoin,
} = require('/linestyle');
const { RGBA8 } = require('/colours');
const { StoryBuilder } = require('/storybuilder');
const { GlyphAttDoubleType } = require('/glyphatts');
const { ParagraphAlignXType } = require('/paragraphatts');
const { Font, FontWeight, FontWidth, FontFamily } = require('/fonts');
const { Transform } = require('/geometry');
const { UnitType } = require('/units');
const { Selection } = require('/selections');

// ---------------------------------------------------------------------------
// Puzzle generation (backtracking + unique-solution dig)
// ---------------------------------------------------------------------------

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function isValid(g, row, col, n) {
    for (let i = 0; i < 9; i++) {
        if (g[row][i] === n) return false;
        if (g[i][col] === n) return false;
    }
    const br = Math.floor(row / 3) * 3;
    const bc = Math.floor(col / 3) * 3;
    for (let r = br; r < br + 3; r++)
        for (let c = bc; c < bc + 3; c++)
            if (g[r][c] === n) return false;
    return true;
}

function fillGrid(g) {
    for (let row = 0; row < 9; row++)
        for (let col = 0; col < 9; col++)
            if (g[row][col] === 0) {
                const nums = shuffle([1,2,3,4,5,6,7,8,9]);
                for (const n of nums) {
                    if (isValid(g, row, col, n)) {
                        g[row][col] = n;
                        if (fillGrid(g)) return true;
                        g[row][col] = 0;
                    }
                }
                return false;
            }
    return true;
}

function countSolutions(g, limit) {
    for (let row = 0; row < 9; row++)
        for (let col = 0; col < 9; col++)
            if (g[row][col] === 0) {
                let total = 0;
                for (let n = 1; n <= 9; n++) {
                    if (isValid(g, row, col, n)) {
                        g[row][col] = n;
                        total += countSolutions(g, limit - total);
                        g[row][col] = 0;
                        if (total >= limit) return total;
                    }
                }
                return total;
            }
    return 1;
}

function cloneGrid(g) { return g.map(r => r.slice()); }

function generateSudoku(targetEmpty) {
    const solution = Array.from({ length: 9 }, () => Array(9).fill(0));
    fillGrid(solution);
    const puzzle = cloneGrid(solution);
    const positions = shuffle(Array.from({ length: 81 }, (_, i) => i));
    let removed = 0;
    for (const p of positions) {
        if (removed >= targetEmpty) break;
        const r = Math.floor(p / 9), c = p % 9;
        const saved = puzzle[r][c];
        puzzle[r][c] = 0;
        const trial = cloneGrid(puzzle);
        if (countSolutions(trial, 2) !== 1) puzzle[r][c] = saved;
        else removed++;
    }
    return { puzzle, solution, removed };
}

// ---------------------------------------------------------------------------
// Dialog
// ---------------------------------------------------------------------------

const DIFFICULTIES = [
    { name: 'Easy',   empty: 36 },
    { name: 'Medium', empty: 46 },
    { name: 'Hard',   empty: 52 },
    { name: 'Expert', empty: 58 },
];

function buildDialog(defaultGridMm) {
    const dlg = Dialog.create('Generate Sudoku');
    const col = dlg.addColumn();
    const g1 = col.addGroup('Puzzle');
    dlg.difficulty = g1.addComboBox('Difficulty', DIFFICULTIES.map(d => d.name), 1);
    dlg.showTitle  = g1.addCheckBox('Show title above grid', true);

    const g2 = col.addGroup('Layout');
    dlg.gridSize = g2.addUnitValueEditor(
        'Grid size', UnitType.Millimetre, UnitType.Millimetre,
        defaultGridMm, 40, 500
    ).setPrecision(1);
    return dlg;
}

// ---------------------------------------------------------------------------
// Font / drawing helpers
// ---------------------------------------------------------------------------

function pickFontFamily() {
    const families = FontFamily.all.map(f => f.name);
    const want = [
        'Helvetica Neue', 'Helvetica', 'Avenir Next', 'Avenir',
        'SF Pro Display', 'Arial', 'Verdana'
    ];
    for (const w of want) if (families.includes(w)) return w;
    return families.length ? families[0] : null;
}

function makeRectDef(x, y, w, h, fill, stroke, lineStyleDesc) {
    const def = ShapeNodeDefinition.createDefault();
    def.shape = ShapeRectangle.create();
    def.setBoundingRectangle({ x, y, width: w, height: h });
    if (fill) def.addBrushFillDescriptor(FillDescriptor.createSolid(fill));
    if (stroke && lineStyleDesc)
        def.addLineDescriptors(FillDescriptor.createSolid(stroke), lineStyleDesc);
    return def;
}

function makeLineStyleDesc(weightPx) {
    const ls = LineStyle.createDefaultWithWeight(weightPx);
    ls.cap = LineCap.Butt;
    ls.join = LineJoin.Miter;
    return LineStyleDescriptor.create(ls, { isScale: true }); // scale-with-object ON
}

function makeTextStory(doc, text, sizePx, fontFamily, colour, weight) {
    const sb = StoryBuilder.create();
    sb.setToArtisticTextDefaultStyle(doc.dpi, doc.format);
    const ga = sb.glyphAtts.clone();
    ga.setDoubleValue(GlyphAttDoubleType.Height, sizePx);
    if (fontFamily) {
        try { ga.font = Font.create(fontFamily, weight, false, FontWidth.Normal); } catch (e) {}
    }
    ga.brushFill = FillDescriptor.createSolid(colour);
    sb.setGlyphAtts(ga);
    const pa = sb.paragraphAtts.clone();
    pa.alignXType = ParagraphAlignXType.Centre;
    sb.setParagraphAtts(pa);
    sb.addText(text);
    return sb;
}

// ---------------------------------------------------------------------------
// Draw the puzzle into the document
// ---------------------------------------------------------------------------

function drawPuzzle(doc, puzzle, originXmm, originYmm, sizeMm, title, fontFamily) {
    const dpi = doc.dpi;
    const mm2px = dpi / 25.4;
    const xPx = originXmm * mm2px;
    const yPx = originYmm * mm2px;
    const sizePx = sizeMm * mm2px;
    const cellPx = sizePx / 9;

    // Scale line weights with grid size (reference: ~180mm default on A4).
    const ls = sizeMm / 180;

    const black = RGBA8(0, 0, 0, 255);
    const white = RGBA8(255, 255, 255, 255);

    const ptsToPx = doc.dpi / 72;

    const cellDesc = makeLineStyleDesc(0.6 * ls * ptsToPx);
    const boxDesc  = makeLineStyleDesc(2.0 * ls * ptsToPx);
    const outDesc  = makeLineStyleDesc(2.5 * ls * ptsToPx);

    // Step 1: Create a group node named "Sudoku".
    const gBuilder = AddChildNodesCommandBuilder.create();
    gBuilder.addContainerNode(ContainerNodeDefinition.create('Sudoku'));
    const gCmd = gBuilder.createCommand(false, NodeChildType.Main);
    doc.executeCommand(gCmd);
    const groupNode = gCmd.newNodes[0];

    // Step 2: Add all puzzle elements inside the group.
    const builder = AddChildNodesCommandBuilder.create();
    builder.setInsertionTarget(groupNode);

    // 81 cell rectangles (white fill = background).
    for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
            builder.addShapeNode(makeRectDef(
                xPx + c * cellPx, yPx + r * cellPx, cellPx, cellPx,
                white, black, cellDesc
            ));
        }
    }

    // Nine 3x3-box outlines.
    for (let br = 0; br < 3; br++) {
        for (let bc = 0; bc < 3; bc++) {
            builder.addShapeNode(makeRectDef(
                xPx + bc * 3 * cellPx, yPx + br * 3 * cellPx,
                3 * cellPx, 3 * cellPx,
                null, black, boxDesc
            ));
        }
    }

    // Outer border on top (no fill, just stroke).
    builder.addShapeNode(makeRectDef(
        xPx, yPx, sizePx, sizePx, null, black, outDesc
    ));

    // Clue numbers (placed off-screen initially).
    const fontPx = cellPx * 0.55;
    const positions = [];
    for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
            const v = puzzle[r][c];
            if (!v) continue;
            const sb = makeTextStory(doc, String(v), fontPx, fontFamily, black, FontWeight.Medium);
            const def = ArtTextNodeDefinition.createFromStoryBuilder({ x: -1000000, y: -1000000 }, sb);
            builder.addNode(def);
            positions.push({
                cx: xPx + (c + 0.5) * cellPx,
                cy: yPx + (r + 0.5) * cellPx,
            });
        }
    }

    // Optional title (in points, scales gently with grid size).
    if (title) {
        const titlePts = Math.max(14, Math.min(28, sizeMm * 0.13));
        const titlePx = titlePts * (dpi / 72);
        const sb = makeTextStory(doc, title, titlePx, fontFamily, black, FontWeight.Bold);
        const def = ArtTextNodeDefinition.createFromStoryBuilder({ x: -1000000, y: -1000000 }, sb);
        builder.addNode(def);
        positions.push({
            cx: xPx + sizePx / 2,
            cy: yPx - Math.max(10, sizeMm * 0.07) * mm2px,
        });
    }

    // Execute once - single undo entry for all shapes + texts.
    const cmd = builder.createCommand();
    doc.executeCommand(cmd);

    // Translate each art-text node to its cell centre.
    // NOTE: cmd.newNodes returns nodes in REVERSE insertion order, so we
    // reverse the positions array to align with it.
    const textNodes = cmd.newNodes.filter(n => n.isArtTextNode);
    const orderedPositions = positions.slice().reverse();
    const compound = CompoundCommandBuilder.create();
    const n = Math.min(textNodes.length, orderedPositions.length);
    for (let i = 0; i < n; i++) {
        const tn = textNodes[i];
        const bb = tn.spreadVisibleBox;
        const tx = orderedPositions[i].cx - (bb.x + bb.width / 2);
        const ty = orderedPositions[i].cy - (bb.y + bb.height / 2);
        compound.addCommand(DocumentCommand.createTransform(
            tn.selfSelection,
            Transform.createTranslate(tx, ty)
        ));
    }
    doc.executeCommand(compound.createCommand());
}

// ---------------------------------------------------------------------------
// Document handling
// ---------------------------------------------------------------------------

function ensureDocument() {
    const doc = Document.current;
    if (doc) return doc;
    const presets = DocumentPreset.all;
    if (presets.length === 0) {
        throw new Error("No document presets available; can't auto-create A4.");
    }
    const opts = NewDocumentOptions.createFromPreset(presets[0]);
    opts.units = UnitType.Millimetre;
    opts.width = 210;
    opts.height = 297;
    opts.isLandscape = false;
    opts.dpi = 300;
    opts.bleed = { left: 0, right: 0, top: 0, bottom: 0 };
    return Document.createFromOptions(opts);
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

function main() {
    const doc = ensureDocument();
    const dpi = doc.dpi;
    const mm2px = dpi / 25.4;
    const pageWmm = doc.widthPixels / mm2px;
    const pageHmm = doc.heightPixels / mm2px;

    // Default grid: as big as fits, leaving a margin and space for the
    // title. Aim for ~80% of the smaller usable page dimension.
    const defaultMm = Math.round(
        Math.min(pageWmm - 20, pageHmm - 50) * 0.95
    );

    const dlg = buildDialog(defaultMm);
    if (dlg.runModal() != DialogResult.Ok) return;

    const diff = DIFFICULTIES[dlg.difficulty.selectedIndex];
    const includeTitle = dlg.showTitle.value;
    const requestedMm = dlg.gridSize.value;

    // Clamp to fit the page (with title allowance if requested).
    const titleAllowanceMm = includeTitle ? 22 : 6;
    const maxW = pageWmm - 10;
    const maxH = pageHmm - titleAllowanceMm - 10;
    const sizeMm = Math.max(40, Math.min(requestedMm, Math.min(maxW, maxH)));

    const fontFamily = pickFontFamily();
    const { puzzle } = generateSudoku(diff.empty);

    // Centre on page.
    const totalHmm = sizeMm + (includeTitle ? titleAllowanceMm : 0);
    const xMm = (pageWmm - sizeMm) / 2;
    const yMm = (pageHmm - totalHmm) / 2 + (includeTitle ? titleAllowanceMm : 0);

    const titleText = includeTitle ? `Sudoku · ${diff.name}` : null;
    drawPuzzle(doc, puzzle, xMm, yMm, sizeMm, titleText, fontFamily);
}

module.exports.main = main;
main();
