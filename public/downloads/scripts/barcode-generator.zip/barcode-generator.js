/*
================================================================================
Copyright (c) 2026, Les Pruszynski (Middledot).
All rights reserved.

BSD 3-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------
Script Name:    barcode-generator.js
Description:    Generates EAN-13/ISBN barcodes natively inside Affinity as a single grouped vector node. Glyph outlines (human-readable digits above and below the bars, plus the closing > marker) are extracted directly from BWIPP-generated SVG references and reproduced exactly using PolyCurveNodes — no font dependency. Output is grouped under a container named "ISBN: <formatted-isbn>".

Author:         Les Pruszynski (Middledot)
Version:        1.1.18
Created:        —
Last updated:   09/10/2026
Compatibility:  Affinity by Canva 3.3

Contact:        lpruszynski@middledot.com
================================================================================
*/




'use strict';

const { app } = require('/application');
const { Document } = require('/document');
const { Dialog, DialogResult } = require('/dialog');
const { PolyCurveNodeDefinition, ShapeNodeDefinition,
        ContainerNodeDefinition } = require('/nodes');
const { ShapeRectangle } = require('/shapes');
const { AddChildNodesCommandBuilder } = require('/commands');
const { PolyCurve, CurveBuilder } = require('/geometry');
const { Colour, RGBA8 } = require('/colours');
const { FillDescriptor } = require('/fills');
const { LineStyleDescriptor } = require('/linestyle');
const { UnitType } = require('/units');
const { HttpRequest, RequestMethod } = require('/network');

const GLYPHS = {
    bottom: {  // sans-serif HRI font, baseline at y=140 in SVG
        "0": { w: 10.41, h: 16.15, top: 124.02, d: "M5.29 16.15L5.21 16.15Q3.92 16.13 2.97 15.73Q2.02 15.36 1.45 14.75Q0.89 14.13 0.56 13.15Q0.21 12.17 0.11 11.17Q0 10.19 0 8.86Q0 7.67 0.02 6.83Q0.06 5.98 0.19 5Q0.32 4 0.54 3.34Q0.78 2.65 1.17 1.96Q1.56 1.29 2.1 0.9Q2.64 0.5 3.43 0.25Q4.21 0 5.21 0Q6.18 0 6.96 0.25Q7.74 0.5 8.29 0.9Q8.83 1.29 9.24 1.96Q9.63 2.65 9.85 3.34Q10.09 4.02 10.22 5Q10.35 5.98 10.37 6.83Q10.41 7.69 10.41 8.86Q10.41 9.69 10.37 10.38Q10.33 11.04 10.17 11.83Q10.04 12.63 9.83 13.23Q9.61 13.81 9.2 14.38Q8.79 14.94 8.26 15.31Q7.74 15.69 6.98 15.92Q6.22 16.15 5.29 16.15M1.95 7.15L1.95 8.86Q1.95 9.79 1.99 10.46Q2.06 11.13 2.25 11.9Q2.43 12.67 2.77 13.15Q3.12 13.65 3.73 13.98Q4.34 14.29 5.21 14.29L5.66 14.29Q6.27 14.29 6.75 14.06Q7.22 13.81 7.51 13.36Q7.81 12.92 8 12.42Q8.2 11.9 8.29 11.25Q8.39 10.58 8.42 10.04Q8.46 9.5 8.46 8.86L8.46 7.9Q8.46 7.25 8.44 6.88Q8.44 6.48 8.42 5.9Q8.39 5.29 8.33 4.96Q8.26 4.61 8.16 4.13Q8.05 3.65 7.87 3.36Q7.7 3.06 7.46 2.75Q7.2 2.44 6.9 2.27Q6.57 2.09 6.14 1.98Q5.73 1.88 5.21 1.88Q4.66 1.88 4.23 2Q3.82 2.11 3.49 2.31Q3.17 2.52 2.9 2.84Q2.67 3.13 2.49 3.5Q2.32 3.86 2.21 4.29Q2.1 4.71 2.06 5.19Q2.02 5.65 1.97 6.15Q1.95 6.63 1.95 7.15Z" },
        "1": { w: 6.55, h: 16.04, top: 124.06, d: "M0.28 4.82Q0 4.52 0 4.15Q0 3.71 0.28 3.5L4.25 0.23Q4.54 0 4.88 0L5.58 0Q5.97 0 6.25 0.3Q6.55 0.57 6.55 0.94L6.55 15.11Q6.55 15.48 6.25 15.77Q5.97 16.04 5.58 16.04Q5.19 16.04 4.88 15.77Q4.6 15.5 4.6 15.11L4.6 2.42L1.63 4.86Q1.35 5.09 0.98 5.09Q0.56 5.09 0.28 4.82Z" },
        "2": { w: 9.61, h: 15.88, top: 124.0, d: "M0.28 2.69Q0 2.4 0 2.04Q0 1.52 0.41 1.25Q2.38 0 4.84 0Q6.81 0 8.13 1.21Q9.48 2.4 9.48 4.33Q9.48 5.1 9.2 5.81Q8.91 6.54 8.55 7Q8.2 7.46 7.5 8.02Q6.81 8.58 6.44 8.83Q6.09 9.08 5.33 9.56Q4.51 10.08 4.14 10.35Q3.77 10.63 3.25 11.17Q2.73 11.69 2.49 12.35Q2.25 13 2.21 13.9L2.21 14L8.63 14Q9.04 14 9.33 14.29Q9.61 14.56 9.61 14.94Q9.61 15.31 9.31 15.6Q9.02 15.88 8.63 15.88L1.21 15.88Q0.82 15.88 0.52 15.6Q0.23 15.31 0.23 14.94L0.23 14.5Q0.23 12.88 0.45 12.17Q0.82 10.92 1.84 9.94Q2.86 8.94 4.34 7.98Q6.38 6.67 6.92 5.92Q7.53 5.17 7.53 4.33Q7.53 3.23 6.72 2.54Q5.96 1.88 4.84 1.88Q2.88 1.88 1.54 2.79Q1.3 2.96 0.97 2.96Q0.58 2.96 0.28 2.69Z" },
        "3": { w: 10.22, h: 16.09, top: 124.08, d: "M0.45 15.3Q0 14.96 0 14.46Q0 14.07 0.28 13.8Q0.58 13.5 0.97 13.5Q1.1 13.5 1.34 13.59Q2.73 14.19 4.25 14.19Q5.9 14.19 7.03 13.4Q8.18 12.59 8.26 11.05L8.26 10.84Q8.26 9.77 7.57 9.02Q6.92 8.3 5.96 7.98Q5.03 7.69 3.88 7.69Q3.51 7.69 3.23 7.42Q2.95 7.13 2.95 6.73Q2.95 6.36 3.14 6.15L7.14 1.9L1.04 1.9Q0.65 1.9 0.34 1.63Q0.06 1.34 0.06 0.94Q0.06 0.55 0.34 0.28Q0.63 0 1.04 0L8.7 0Q9.09 0 9.37 0.3Q9.68 0.57 9.68 0.94L9.68 1.69Q9.68 2.03 9.37 2.32L5.88 6L6.05 6.05Q7.9 6.5 9.07 7.73Q10.22 8.96 10.22 10.82L10.22 11.15Q10.11 13.42 8.37 14.75Q6.68 16.09 4.25 16.09Q3.64 16.09 3.04 16.02Q2.43 15.96 1.67 15.82Q0.91 15.65 0.45 15.3Z" },
        "4": { w: 10.41, h: 16.04, top: 124.06, d: "M0.28 12.15Q0 11.88 0 11.48L0 10.59Q0 10.42 0.11 10.19L4.73 0.55Q4.81 0.32 5.05 0.17Q5.29 0 5.55 0Q5.94 0 6.22 0.3Q6.51 0.57 6.51 0.94Q6.51 1.15 6.4 1.34L2.06 10.54L6.29 10.54L6.29 8.02Q6.29 7.65 6.57 7.38Q6.85 7.09 7.22 7.09Q7.59 7.09 7.87 7.38Q8.18 7.65 8.18 8.02L8.18 10.54L9.44 10.54Q9.85 10.54 10.13 10.84Q10.41 11.11 10.41 11.48Q10.41 11.86 10.11 12.15Q9.83 12.42 9.44 12.42L8.18 12.42L8.18 15.11Q8.18 15.48 7.87 15.75Q7.59 16.04 7.22 16.04Q6.85 16.04 6.57 15.77Q6.29 15.48 6.29 15.11L6.29 12.42L0.97 12.42Q0.58 12.42 0.28 12.15Z" },
        "5": { w: 8.99, h: 16.09, top: 124.08, d: "M0.28 15.82Q0 15.55 0 15.15Q0 14.73 0.28 14.46Q0.59 14.19 0.98 14.19Q5.36 14.19 6.64 11.84Q7.03 11.13 7.03 10.48Q7.03 8.96 6.29 8.19Q5.32 7.09 2.87 7.09Q2.19 7.09 1.5 7.15L1.41 7.15Q1.02 7.15 0.72 6.9Q0.44 6.63 0.44 6.25L0.44 6.19L0.74 0.88Q0.78 0.5 1.04 0.25Q1.32 0 1.72 0L7.88 0Q8.29 0 8.57 0.3Q8.85 0.57 8.85 0.94Q8.85 1.32 8.55 1.61Q8.27 1.9 7.88 1.9L2.63 1.9L2.45 5.17L2.87 5.17Q5.62 5.17 7.29 6.52Q8.99 7.86 8.99 10.48Q8.99 11.59 8.49 12.55Q7.97 13.52 7.18 14.21Q5.1 16.09 0.98 16.09Q0.59 16.09 0.28 15.82M1.48 7.15Q1.48 7.15 1.5 7.15Q1.5 7.15 1.48 7.15Z" },
        "6": { w: 10.41, h: 16.11, top: 124.06, d: "M1.52 14.75Q0.06 13.4 0 11.17L0 10.92Q0 8.32 1.49 5.94Q2.1 4.96 2.97 3.88Q3.82 2.77 4.4 2.13Q4.99 1.46 6.07 0.27Q6.31 0 6.75 0Q7.11 0 7.4 0.3Q7.68 0.57 7.68 0.94Q7.68 1.3 7.44 1.59Q4.99 4.25 3.84 5.86L3.69 6.07L3.92 6.02Q4.55 5.9 5.21 5.9Q7.57 5.9 8.98 7.32Q10.41 8.75 10.41 11.17Q10.41 13.36 8.94 14.73Q7.46 16.11 5.21 16.11Q2.95 16.11 1.52 14.75M2.82 8.69Q1.95 9.59 1.95 11.17Q1.95 12.59 2.86 13.42Q3.75 14.23 5.21 14.23Q6.64 14.23 7.53 13.4Q8.46 12.57 8.46 11.17Q8.46 9.54 7.61 8.67Q6.79 7.77 5.21 7.77Q3.66 7.77 2.82 8.69Z" },
        "7": { w: 10.41, h: 16.02, top: 124.08, d: "M0.28 1.63Q0 1.34 0 0.94Q0 0.55 0.28 0.28Q0.56 0 0.97 0L9.44 0Q9.85 0 10.13 0.3Q10.41 0.57 10.41 0.94Q10.41 2.53 9.13 4.38Q8.74 4.96 7.61 6.32Q6.49 7.69 6.01 8.55Q4.6 11.05 4.6 15.07Q4.6 15.46 4.32 15.75Q4.03 16.02 3.66 16.02Q3.3 16.02 3.01 15.75Q2.73 15.48 2.73 15.07Q2.73 10.52 4.38 7.59Q4.88 6.73 6.01 5.3Q7.16 3.84 7.53 3.3Q8.05 2.46 8.24 2.05L8.29 1.9L0.97 1.9Q0.58 1.9 0.28 1.63Z" },
        "8": { w: 10.41, h: 16.17, top: 124.0, d: "M3.51 2.29Q2.69 2.71 2.69 3.5Q2.69 4.02 2.88 4.42Q3.08 4.81 3.53 5.15Q3.97 5.46 4.25 5.63Q4.55 5.79 5.16 6.08L5.21 6.08L5.25 6.08Q5.86 5.81 6.16 5.65Q6.46 5.48 6.9 5.17Q7.33 4.83 7.53 4.44Q7.72 4.02 7.72 3.5Q7.72 2.71 6.9 2.29Q6.09 1.88 5.21 1.88Q4.32 1.88 3.51 2.29M5.21 8.23Q1.93 9.88 1.93 11.83Q1.93 13 2.9 13.65Q3.82 14.29 5.21 14.29L5.64 14.29Q6.79 14.29 7.61 13.56Q8.46 12.83 8.46 11.83Q8.46 9.85 5.29 8.23L5.25 8.19L5.21 8.23M1.49 14.96Q0 13.75 0 11.83Q0 9.31 3.08 7.27L3.21 7.19L3.08 7.1Q0.73 5.73 0.73 3.5Q0.73 1.98 2.12 1Q3.49 0 5.21 0Q6.9 0 8.29 1Q9.68 2 9.68 3.5Q9.68 4.73 9.07 5.58Q8.44 6.42 7.33 7.1L7.2 7.19L7.33 7.27Q10.41 9.31 10.41 11.83Q10.41 13.48 9.15 14.75Q7.9 16.02 6.12 16.17L5.21 16.17Q2.97 16.17 1.49 14.96Z" },
        "9": { w: 10.41, h: 16.1, top: 124.0, d: "M2.9 2.9Q1.95 3.9 1.95 5.29Q1.95 6.65 2.86 7.5Q3.73 8.33 5.21 8.33Q7.79 8.33 8.24 6.81Q8.46 6.13 8.46 5.29Q8.46 3.73 7.55 2.81Q6.66 1.88 5.21 1.88Q3.84 1.88 2.9 2.9M1.47 8.79Q0 7.4 0 5.29Q0 3.13 1.56 1.56Q3.08 0 5.21 0Q7.4 0 8.89 1.46Q10.41 2.92 10.41 5.29Q10.41 6.77 9.96 7.96Q9.5 9.15 8.68 10.52Q6.88 13.54 4.27 15.85Q3.99 16.1 3.66 16.1Q3.3 16.1 3.01 15.83Q2.73 15.56 2.73 15.17Q2.73 14.77 3.04 14.48Q5.1 12.58 6.57 10.29L6.68 10.08L6.46 10.13Q5.9 10.21 5.21 10.21Q2.9 10.21 1.47 8.79Z" },
    },
    top: {  // slab/digital ISBN-label font, baseline at y=13 in SVG
        "I": { w: 7.2, h: 11.28, top: 1.33, d: "M0 10.55Q0 10.26 0.2 10.04Q0.42 9.82 0.72 9.82L2.86 9.82L2.86 1.46L0.72 1.46Q0.42 1.46 0.2 1.24Q0 1.03 0 0.72Q0 0.43 0.2 0.22Q0.42 0 0.72 0L6.46 0Q6.77 0 6.98 0.22Q7.2 0.43 7.2 0.72Q7.2 1.03 6.98 1.24Q6.77 1.46 6.46 1.46L4.32 1.46L4.32 9.82L6.46 9.82Q6.77 9.82 6.98 10.04Q7.2 10.26 7.2 10.55Q7.2 10.85 6.98 11.07Q6.77 11.28 6.46 11.28L0.72 11.28Q0.42 11.28 0.2 11.07Q0 10.85 0 10.55Z" },
        "S": { w: 7.2, h: 11.28, top: 1.33, d: "M0 9.33Q0 9.03 0.2 8.81Q0.42 8.59 0.72 8.59Q1.02 8.59 1.24 8.81Q1.46 9.03 1.46 9.33Q1.46 9.53 1.6 9.68Q1.75 9.82 1.95 9.82L5.55 9.82Q5.74 9.82 5.74 9.63L0.33 2.66Q0 2.2 0 1.65L0 1.61Q0 0.96 0.47 0.48Q0.97 0 1.63 0L5.23 0Q6.03 0 6.61 0.58Q7.2 1.16 7.2 1.95Q7.2 2.26 6.98 2.47Q6.77 2.69 6.46 2.69Q6.16 2.69 5.94 2.47Q5.74 2.26 5.74 1.95Q5.74 1.77 5.58 1.62Q5.44 1.46 5.23 1.46L1.63 1.46Q1.46 1.46 1.46 1.61L1.46 1.65L1.46 1.71L6.84 8.62Q7.2 9.06 7.2 9.63Q7.17 10.31 6.69 10.81Q6.23 11.28 5.55 11.28L1.95 11.28Q1.15 11.28 0.57 10.71Q0 10.13 0 9.33Z" },
        "B": { w: 7.2, h: 11.28, top: 1.33, d: "M0 11.28L0 0L4.28 0Q5.46 0 6.33 0.87Q7.2 1.74 7.2 2.92L7.2 3.46Q7.2 4.75 6.19 5.64Q7.2 6.54 7.2 7.83L7.2 8.36Q7.2 9.55 6.33 10.42Q5.46 11.28 4.28 11.28L0 11.28 M1.46 9.82L4.28 9.82Q4.87 9.82 5.31 9.39Q5.74 8.94 5.74 8.36L5.74 7.83Q5.74 7.23 5.31 6.8Q4.87 6.37 4.28 6.37L1.46 6.37L1.46 9.82 M1.46 4.9L4.28 4.9Q4.87 4.9 5.31 4.47Q5.74 4.04 5.74 3.46L5.74 2.92Q5.74 2.34 5.31 1.91Q4.87 1.46 4.28 1.46L1.46 1.46L1.46 4.9Z" },
        "N": { w: 7.2, h: 11.28, top: 1.33, d: "M0 10.55L0 0L1.92 0L5.74 8.71L5.74 0.72Q5.74 0.43 5.94 0.22Q6.16 0 6.46 0Q6.77 0 6.98 0.22Q7.2 0.43 7.2 0.72L7.2 11.28L5.26 11.28L1.46 2.6L1.46 10.55Q1.46 10.85 1.24 11.07Q1.02 11.28 0.72 11.28Q0.42 11.28 0.2 11.07Q0 10.85 0 10.55Z" },
        "0": { w: 7.2, h: 11.28, top: 1.33, d: "M0 9.82L0 1.46Q0 0.87 0.43 0.43Q0.86 0 1.46 0L5.74 0Q6.32 0 6.75 0.43Q7.2 0.87 7.2 1.46L7.2 9.82Q7.2 10.42 6.75 10.85Q6.32 11.28 5.74 11.28L1.46 11.28Q0.86 11.28 0.43 10.85Q0 10.42 0 9.82 M1.46 9.82L5.74 9.82L5.74 1.46L1.46 1.46L1.46 9.82Z" },
        "1": { w: 7.2, h: 11.28, top: 1.33, d: "M0 10.55Q0 10.26 0.2 10.04Q0.42 9.82 0.72 9.82L2.86 9.82L2.86 1.46L0.72 1.46Q0.42 1.46 0.2 1.24Q0 1.03 0 0.72Q0 0.43 0.2 0.22Q0.42 0 0.72 0L4.32 0L4.32 9.82L5.74 9.82L5.74 6.87Q5.74 6.57 5.94 6.35Q6.16 6.13 6.46 6.13Q6.77 6.13 6.98 6.35Q7.2 6.57 7.2 6.87L7.2 10.55Q7.2 10.85 6.98 11.07Q6.77 11.28 6.46 11.28L0.72 11.28Q0.42 11.28 0.2 11.07Q0 10.85 0 10.55Z" },
        "2": { w: 7.2, h: 11.28, top: 1.33, d: "M0 11.28L0 6.37Q0 5.77 0.43 5.35Q0.86 4.92 1.46 4.92L5.74 4.92L5.74 1.46L0.72 1.46Q0.42 1.46 0.2 1.24Q0 1.03 0 0.72Q0 0.43 0.2 0.22Q0.42 0 0.72 0L5.74 0Q6.32 0 6.75 0.43Q7.2 0.87 7.2 1.46L7.2 4.92Q7.2 5.5 6.77 5.93Q6.33 6.37 5.74 6.37L1.46 6.37L1.46 9.82L6.46 9.82Q6.77 9.82 6.98 10.04Q7.2 10.26 7.2 10.55Q7.2 10.85 6.98 11.07Q6.77 11.28 6.46 11.28L0 11.28Z" },
        "3": { w: 7.2, h: 11.28, top: 1.33, d: "M0 10.55Q0 10.26 0.2 10.04Q0.42 9.82 0.72 9.82L5.74 9.82L5.74 7.1Q5.74 6.81 5.51 6.6Q5.29 6.37 5 6.37L2.15 6.37Q1.85 6.37 1.63 6.16Q1.43 5.95 1.43 5.64Q1.43 5.34 1.63 5.12Q1.85 4.9 2.15 4.9L5 4.9Q5.31 4.9 5.52 4.69Q5.74 4.47 5.74 4.18L5.74 1.46L0.72 1.46Q0.42 1.46 0.2 1.24Q0 1.03 0 0.72Q0 0.43 0.2 0.22Q0.42 0 0.72 0L5.74 0Q6.32 0 6.75 0.43Q7.2 0.87 7.2 1.46L7.2 4.18Q7.2 5.02 6.62 5.64Q7.2 6.26 7.2 7.1L7.2 9.82Q7.2 10.42 6.75 10.85Q6.32 11.28 5.74 11.28L0.72 11.28Q0.42 11.28 0.2 11.07Q0 10.85 0 10.55Z" },
        "4": { w: 6.5, h: 11.28, top: 1.33, d: "M0 7.6L0 0.72Q0 0.43 0.22 0.22Q0.44 0 0.74 0Q1.04 0 1.25 0.22Q1.46 0.43 1.46 0.72L1.46 6.13L4.31 6.13L4.31 1.95Q4.31 1.65 4.53 1.45Q4.75 1.23 5.05 1.23Q5.34 1.23 5.56 1.45Q5.78 1.65 5.78 1.95L5.78 6.13Q6.08 6.13 6.28 6.35Q6.5 6.57 6.5 6.87Q6.5 7.18 6.28 7.39Q6.08 7.6 5.78 7.6L5.78 10.55Q5.78 10.85 5.56 11.07Q5.34 11.28 5.05 11.28Q4.75 11.28 4.53 11.07Q4.31 10.85 4.31 10.55L4.31 7.6L0 7.6Z" },
        "5": { w: 7.2, h: 11.28, top: 1.33, d: "M0 9.94Q0 9.63 0.2 9.43Q0.42 9.22 0.72 9.22Q0.89 9.22 1.01 9.27L2.31 9.82L5.74 9.82L5.74 6.37L1.43 6.37L1.43 0L6.46 0Q6.77 0 6.98 0.22Q7.2 0.43 7.2 0.72Q7.2 1.03 6.98 1.24Q6.77 1.46 6.46 1.46L2.89 1.46L2.89 4.9L5.74 4.9Q6.32 4.9 6.75 5.35Q7.2 5.79 7.2 6.37L7.2 9.82Q7.2 10.42 6.75 10.85Q6.32 11.28 5.74 11.28L2.46 11.28Q2.17 11.28 1.86 11.21Q1.57 11.14 1.38 11.07Q1.2 10.98 0.88 10.84Q0.56 10.68 0.43 10.62Q0 10.43 0 9.94Z" },
        "6": { w: 7.2, h: 11.28, top: 1.33, d: "M0 10.55L0 0.72Q0 0.43 0.2 0.22Q0.42 0 0.72 0L1.44 0Q1.75 0 1.95 0.22Q2.17 0.43 2.17 0.72Q2.17 1.03 1.95 1.24Q1.75 1.46 1.44 1.46L1.44 6.13L6.46 6.13Q6.77 6.13 6.98 6.35Q7.2 6.57 7.2 6.87L7.2 10.55Q7.2 10.85 6.98 11.07Q6.77 11.28 6.46 11.28L0.72 11.28Q0.42 11.28 0.2 11.07Q0 10.85 0 10.55 M1.44 9.82L5.74 9.82L5.74 7.6L1.44 7.6L1.44 9.82Z" },
        "7": { w: 7.2, h: 11.28, top: 1.33, d: "M0 1.35L0 0.72Q0 0.43 0.2 0.22Q0.42 0 0.72 0L7.2 0L7.2 4.41Q7.2 4.75 6.94 4.98L4.32 7.2L4.32 10.55Q4.32 10.85 4.1 11.07Q3.89 11.28 3.6 11.28Q3.29 11.28 3.08 11.07Q2.86 10.85 2.86 10.55L2.86 6.87Q2.86 6.54 3.12 6.31L5.74 4.08L5.74 1.46L1.44 1.46Q1.4 1.72 1.2 1.9Q0.99 2.07 0.72 2.07Q0.42 2.07 0.2 1.87Q0 1.65 0 1.35Z" },
        "8": { w: 7.2, h: 11.28, top: 1.33, d: "M0 9.82L0 6.37Q0 5.77 0.42 5.34Q0.85 4.9 1.44 4.9L1.44 0.72Q1.44 0.42 1.65 0.22Q1.85 0 2.15 0L5.03 0Q5.33 0 5.54 0.22Q5.74 0.42 5.74 0.72L5.74 4.9Q6.32 4.9 6.75 5.35Q7.2 5.79 7.2 6.37L7.2 9.82Q7.2 10.42 6.75 10.85Q6.32 11.28 5.74 11.28L1.44 11.28Q0.85 11.28 0.42 10.85Q0 10.42 0 9.82 M1.44 9.82L5.74 9.82L5.74 6.37L1.44 6.37L1.44 9.82 M2.89 4.9L4.29 4.9L4.29 1.46L2.89 1.46L2.89 4.9Z" },
        "9": { w: 7.2, h: 11.28, top: 1.33, d: "M0 4.41L0 0.72Q0 0.43 0.2 0.22Q0.42 0 0.72 0L6.46 0Q6.77 0 6.98 0.22Q7.2 0.43 7.2 0.72L7.2 10.55Q7.2 10.85 6.98 11.07Q6.77 11.28 6.46 11.28L5.74 11.28Q5.44 11.28 5.22 11.07Q5.02 10.85 5.02 10.55Q5.02 10.26 5.22 10.04Q5.44 9.82 5.74 9.82L5.74 5.15L0.72 5.15Q0.42 5.15 0.2 4.93Q0 4.72 0 4.41 M1.44 3.69L5.74 3.69L5.74 1.46L1.44 1.46L1.44 3.69Z" },
        "-": { w: 7.2, h: 2.09, top: 6.23, d: "M0 1.35L0 0.74Q0 0.44 0.2 0.22Q0.42 0 0.72 0L6.46 0Q6.77 0 6.98 0.22Q7.2 0.44 7.2 0.74L7.2 1.35Q7.2 1.65 6.98 1.87Q6.77 2.09 6.46 2.09L0.72 2.09Q0.42 2.09 0.2 1.87Q0 1.65 0 1.35Z" },
    },
    guard: {"w":12.48,"h":15.11,"top":124.71,"d":"M12.12 8.33L1.77 14.92Q1.49 15.11 1.13 15.11Q0.68 15.11 0.32 14.8Q0 14.46 0 14.02Q0 13.58 0.32 13.24L9.21 7.55L0.32 1.87Q0 1.65 0 1.09Q0 0.65 0.32 0.34Q0.68 0 1.13 0Q1.49 0 1.77 0.19Q1.77 0.19 1.77 0.19L12.12 6.78Q12.48 7.17 12.48 7.58Q12.48 8.02 12.12 8.33Z"}
};
// ============================================================
// SVG path -> Affinity curves
// ============================================================

function tokenizePath(d) {
    const tokens = [];
    const re = /([MLQCHVZmlqchvz])|(-?\d*\.?\d+)/g;
    let m;
    while ((m = re.exec(d)) !== null) {
        if (m[1]) tokens.push({type: 'cmd', val: m[1]});
        else tokens.push({type: 'num', val: parseFloat(m[2])});
    }
    return tokens;
}

// Convert an SVG path's 'd' attribute into an array of Affinity Curve
// objects (one per M-starting sub-path). Coordinates are transformed by
// (x*sx + ox, y*sy + oy). Quadratic Beziers (Q) are converted to cubic
// since Affinity supports only cubic via addBezier.
function svgPathToCurves(pathStr, sx, sy, ox, oy) {
    const tokens = tokenizePath(pathStr);
    const curves = [];
    let cb = null;
    let curX = 0, curY = 0, startX = 0, startY = 0;
    let i = 0, cmd = null;
    
    while (i < tokens.length) {
        if (tokens[i].type === 'cmd') {
            cmd = tokens[i].val;
            i++;
            if (i >= tokens.length) break;
        }
        switch (cmd) {
            case 'M': case 'm': {
                if (cb !== null) curves.push(cb.createCurve());
                cb = CurveBuilder.create();
                const x = tokens[i++].val, y = tokens[i++].val;
                cb.beginXY(x * sx + ox, y * sy + oy);
                curX = x; curY = y; startX = x; startY = y;
                cmd = (cmd === 'M') ? 'L' : 'l';
                break;
            }
            case 'L': case 'l': {
                const x = tokens[i++].val, y = tokens[i++].val;
                cb.lineToXY(x * sx + ox, y * sy + oy);
                curX = x; curY = y;
                break;
            }
            case 'Q': case 'q': {
                const cx = tokens[i++].val, cy = tokens[i++].val;
                const ex = tokens[i++].val, ey = tokens[i++].val;
                const c0x = curX + (2/3) * (cx - curX);
                const c0y = curY + (2/3) * (cy - curY);
                const c1x = ex   + (2/3) * (cx - ex);
                const c1y = ey   + (2/3) * (cy - ey);
                cb.addBezierXY(
                    c0x * sx + ox, c0y * sy + oy,
                    c1x * sx + ox, c1y * sy + oy,
                    ex  * sx + ox, ey  * sy + oy
                );
                curX = ex; curY = ey;
                break;
            }
            case 'Z': case 'z': {
                cb.close();
                curX = startX; curY = startY;
                break;
            }
            default:
                i++;
        }
    }
    if (cb !== null) curves.push(cb.createCurve());
    return curves;
}

// ============================================================
// Encoders for EAN-13 family, EAN-8, UPC-A, EAN-5 add-on, EAN-2 add-on
// (BWIPP port — direct ports of the encoding tables in Terry Burton's
// "Barcode Writer in Pure PostScript")
// ============================================================

// Digit encodings (modules sum to 7). Used for EAN-13, EAN-8 and UPC-A.
const EAN13_ENCS = [
    '3211','2221','2122','1411','1132','1231','1114','1312','1213','3112',
    '111', '11111', '111'   // 10: start guard, 11: centre guard, 12: end guard
];

// Mirror map per first (system) digit. '0' = encode as-is, '1' = reverse
// (this is what gives EAN-13 its left-half digit parity)
const EAN13_MIRRORMAPS = [
    '000000','001011','001101','001110','010011',
    '011001','011100','010101','010110','011010'
];

// EAN-5 (price add-on) digit encodings (4 modules each)
const EAN5_ENCS = [
    '3211','2221','2122','1411','1132','1231','1114','1312','1213','3112',
    '112','11'   // 10: start (bar-space-bar), 11: separator between digits
];

// EAN-5 mirror maps indexed by add-on checksum
const EAN5_MIRRORMAPS = [
    '11000','10100','10010','10001','01100',
    '00110','00011','01010','01001','00101'
];

// EAN-2 (issue add-on) reuses the EAN-5 encoding tables
const EAN2_ENCS = EAN5_ENCS;
const EAN2_MIRRORMAPS = ['00','01','10','11'];

function stripFormatting(s) {
    return s.replace(/[\s\-]/g, '');
}

// EAN-13 check digit (weights 1,3,1,3,... over 12 input digits)
function ean13CheckDigit(twelve) {
    let sum = 0;
    for (let i = 0; i < 12; i++) {
        const d = parseInt(twelve.charAt(i), 10);
        sum += (i % 2 === 0) ? d : d * 3;
    }
    return (10 - (sum % 10)) % 10;
}

// EAN-8 check digit (weights 3,1,3,1,... over 7 input digits)
function ean8CheckDigit(seven) {
    let sum = 0;
    for (let i = 0; i < 7; i++) {
        const d = parseInt(seven.charAt(i), 10);
        sum += (i % 2 === 0) ? d * 3 : d;
    }
    return (10 - (sum % 10)) % 10;
}

// UPC-A is functionally an EAN-13 with a leading zero
function upcaCheckDigit(eleven) {
    return ean13CheckDigit('0' + eleven);
}

// EAN-5 add-on checksum (weights 3,9 alternating, mod 10)
function ean5Checksum(five) {
    let sum = 0;
    for (let i = 0; i < 5; i++) {
        const d = parseInt(five.charAt(i), 10);
        sum += (i % 2 === 0) ? d * 3 : d * 9;
    }
    return sum % 10;
}

// EAN-2 add-on checksum (mod 4 of the 2-digit value)
function ean2Checksum(two) {
    return parseInt(two, 10) % 4;
}

// Input normalisation per type
// All return a canonical digit string ready for encoding.

// Returns { thirteen, userFormatted } where userFormatted holds the user's
// hyphenated input when they provided a hyphenated ISBN-13 (so we preserve
// their formatting), otherwise null (the caller should auto-hyphenate).
function normaliseISBN(input) {
    let digits = stripFormatting(input).toUpperCase();
    const hadHyphens = input.indexOf('-') !== -1;
    const originalIsThirteen = (digits.length === 13);
    if (digits.length === 10) {
        let sum = 0;
        for (let i = 0; i < 9; i++) sum += parseInt(digits.charAt(i), 10) * (10 - i);
        const last = digits.charAt(9);
        const lastVal = (last === 'X') ? 10 : parseInt(last, 10);
        if (isNaN(lastVal)) throw new Error('ISBN-10 last char must be 0-9 or X');
        sum += lastVal;
        if (sum % 11 !== 0) throw new Error('ISBN-10 check digit is incorrect.');
        digits = '978' + digits.substring(0, 9);
        digits = digits + String(ean13CheckDigit(digits));
    } else if (digits.length === 12) {
        digits = digits + String(ean13CheckDigit(digits));
    } else if (digits.length === 13) {
        const expected = ean13CheckDigit(digits.substring(0, 12));
        if (parseInt(digits.charAt(12), 10) !== expected) {
            throw new Error('ISBN-13 check digit is incorrect. Expected ' + expected + '.');
        }
    } else {
        throw new Error('ISBN must be 10, 12 (no check digit), or 13 digits.');
    }
    if (digits.substring(0, 3) !== '978' && digits.substring(0, 3) !== '979') {
        throw new Error('ISBN-13 must start with 978 or 979.');
    }
    return {
        thirteen: digits,
        userFormatted: (hadHyphens && originalIsThirteen) ? input.trim() : null
    };
}

// Live-expansion helper for the dialog: if input is a complete, valid
// ISBN-10 (or a valid 12-digit 978/979 prefix), return the 13-digit form;
// otherwise return null. Pure function — no network, no hyphenation (the
// top-label hyphenation still happens once at render time). Mirrors the
// ISBN-10 and 12-digit branches of normaliseISBN.
function tryExpandISBNTo13(input) {
    const digits = stripFormatting(input).toUpperCase();
    if (digits.length === 10) {
        let sum = 0;
        for (let i = 0; i < 9; i++) {
            const d = parseInt(digits.charAt(i), 10);
            if (isNaN(d)) return null;
            sum += d * (10 - i);
        }
        const last = digits.charAt(9);
        const lastVal = (last === 'X') ? 10 : parseInt(last, 10);
        if (isNaN(lastVal)) return null;
        sum += lastVal;
        if (sum % 11 !== 0) return null;
        const base = '978' + digits.substring(0, 9);
        return base + String(ean13CheckDigit(base));
    }
    if (digits.length === 12) {
        if (!/^[0-9]{12}$/.test(digits)) return null;
        if (digits.substring(0, 3) !== '978' && digits.substring(0, 3) !== '979') return null;
        return digits + String(ean13CheckDigit(digits));
    }
    return null;
}

// True when s is 13 digits with a valid 978/979 prefix and check digit.
function isValidISBN13Digits(s) {
    if (!/^[0-9]{13}$/.test(s)) return false;
    if (s.substring(0, 3) !== '978' && s.substring(0, 3) !== '979') return false;
    return parseInt(s.charAt(12), 10) === ean13CheckDigit(s.substring(0, 12));
}

// True when cur is prev with exactly one character deleted (any position).
// Used by the live tick to recognise mid-correction of a finished number.
function isSingleDeletion(prev, cur) {
    if (prev.length !== cur.length + 1) return false;
    let i = 0;
    while (i < cur.length && prev.charAt(i) === cur.charAt(i)) i++;
    return prev.substring(i + 1) === cur.substring(i);
}

// Live validation message for a stripped (hyphens/spaces removed, uppercased)
// ISBN entry. Returns ' ' (blank) for empty/partial input that may still
// become valid — only complete-looking input gets an error. Mirrors the
// normaliseISBN error texts so OK-time alerts agree with the live line.
function isbnErrorFor(stripped) {
    if (!stripped) return ' ';
    if (stripped.length === 10) {
        if (!/^[0-9]{9}[0-9X]$/.test(stripped)) {
            return '❌\uFE0F ISBN-10 is 9 digits plus check (0-9 or X).';
        }
        return tryExpandISBNTo13(stripped)
            ? ' '
            : '❌\uFE0F ISBN-10 check digit is incorrect.';
    }
    if (stripped.length === 12) {
        if (!/^[0-9]{12}$/.test(stripped)) {
            return '❌\uFE0F ISBN must be 10, 12 or 13 digits.';
        }
        if (stripped.substring(0, 3) !== '978' && stripped.substring(0, 3) !== '979') {
            return '❌\uFE0F ISBN-13 must start with 978 or 979.';
        }
        return ' ';  // convertible — the tick rewrites it, no error to show
    }
    if (stripped.length === 13) {
        if (!/^[0-9]{13}$/.test(stripped)) {
            return '❌\uFE0F ISBN-13 must be 13 digits.';
        }
        if (stripped.substring(0, 3) !== '978' && stripped.substring(0, 3) !== '979') {
            return '❌\uFE0F ISBN-13 must start with 978 or 979.';
        }
        const expected = ean13CheckDigit(stripped.substring(0, 12));
        return (parseInt(stripped.charAt(12), 10) === expected)
            ? ' '
            : '❌\uFE0F ISBN-13 check digit is incorrect. Expected ' + expected + '.';
    }
    if (stripped.length > 13) {
        return '❌\uFE0F too many digits — ISBN-13 is 13 digits.';
    }
    return ' ';  // shorter than 10: still typing, stay silent
}

// Add-on validation message for the live status line (all barcode types).
// Returns null when the add-on is absent or valid. Mirrors the main()
// alert texts so live and OK-time agree.
function addOnErrorFor(addOn) {
    if (!addOn) return null;
    if (addOn.length !== 2 && addOn.length !== 5) {
        return 'Add-on must be 2 or 5 digits (or blank).';
    }
    if (!/^\d+$/.test(addOn)) {
        return 'Add-on must contain only digits.';
    }
    return null;
}

function normaliseEAN13(input) {
    let digits = stripFormatting(input);
    if (digits.length === 12) {
        return digits + String(ean13CheckDigit(digits));
    } else if (digits.length === 13) {
        const expected = ean13CheckDigit(digits.substring(0, 12));
        if (parseInt(digits.charAt(12), 10) !== expected) {
            throw new Error('EAN-13 check digit is incorrect. Expected ' + expected + '.');
        }
        return digits;
    }
    throw new Error('EAN-13 must be 12 or 13 digits.');
}

function normaliseEAN8(input) {
    let digits = stripFormatting(input);
    if (digits.length === 7) {
        return digits + String(ean8CheckDigit(digits));
    } else if (digits.length === 8) {
        const expected = ean8CheckDigit(digits.substring(0, 7));
        if (parseInt(digits.charAt(7), 10) !== expected) {
            throw new Error('EAN-8 check digit is incorrect. Expected ' + expected + '.');
        }
        return digits;
    }
    throw new Error('EAN-8 must be 7 or 8 digits.');
}

function normaliseUPCA(input) {
    let digits = stripFormatting(input);
    if (digits.length === 11) {
        return digits + String(upcaCheckDigit(digits));
    } else if (digits.length === 12) {
        const expected = upcaCheckDigit(digits.substring(0, 11));
        if (parseInt(digits.charAt(11), 10) !== expected) {
            throw new Error('UPC-A check digit is incorrect. Expected ' + expected + '.');
        }
        return digits;
    }
    throw new Error('UPC-A must be 11 or 12 digits.');
}

function normaliseISSN(input) {
    // ISSN is 7 digits + final check char (digit or X). We embed it as
    // EAN-13: 977 + first 7 ISSN digits + "00" issue/price code + EAN check.
    const raw = input.replace(/[\s\-]/g, '').toUpperCase();
    if (raw.length !== 8 && raw.length !== 7) {
        throw new Error('ISSN must be 7 or 8 characters (digits, optionally with final X).');
    }
    const root = raw.substring(0, 7);
    if (!/^[0-9]{7}$/.test(root)) {
        throw new Error('ISSN root must be 7 digits.');
    }
    // Discard the ISSN's own check char; EAN-13 has its own.
    const base12 = '977' + root + '00';
    return base12 + String(ean13CheckDigit(base12));
}

// Label formatters

// Hyphenate via the proper algorithm using the live ranges data when
// available, falling back to a 3-1-5-3-1 split.
function formatISBNLabel(thirteen) {
    return hyphenateISBN13(thirteen);
}

function formatISSNLabel(thirteen) {
    // EAN-13 layout for ISSN: 977 + 7 ISSN digits + 2 issue + 1 check
    // Display as "nnnn-nnnX" where X is the original ISSN check char (we
    // approximate it as the 7th digit of the root for display only — the
    // user should use the standard ISSN-supplied check char).
    const root = thirteen.substring(3, 10);
    // Compute the ISSN check char (mod-11 with weights 8..2, X if 10)
    let sum = 0;
    for (let i = 0; i < 7; i++) sum += parseInt(root.charAt(i), 10) * (8 - i);
    const c = (11 - (sum % 11)) % 11;
    const cChar = (c === 10) ? 'X' : String(c);
    return root.substring(0, 4) + '-' + root.substring(4) + cChar;
}

// Bar encoding (SBS = start-bar-space widths)

function _w2(s) {
    const out = [];
    for (let i = 0; i < s.length; i++) out.push(s.charCodeAt(i) - 48);
    return out;
}
function _rev(s) { return s.split('').reverse().join(''); }

function encodeEAN13(thirteen) {
    const sbs = [];
    const lm = EAN13_MIRRORMAPS[parseInt(thirteen.charAt(0), 10)];
    sbs.push(..._w2(EAN13_ENCS[10]));
    for (let i = 1; i <= 6; i++) {
        let e = EAN13_ENCS[parseInt(thirteen.charAt(i), 10)];
        if (lm.charAt(i - 1) === '1') e = _rev(e);
        sbs.push(..._w2(e));
    }
    sbs.push(..._w2(EAN13_ENCS[11]));
    for (let i = 7; i <= 12; i++) {
        sbs.push(..._w2(EAN13_ENCS[parseInt(thirteen.charAt(i), 10)]));
    }
    sbs.push(..._w2(EAN13_ENCS[12]));
    return sbs;
}

// EAN-8: 67 modules total = 3 (start) + 28 (4 left digits) + 5 (centre)
//                          + 28 (4 right digits) + 3 (end)
function encodeEAN8(eight) {
    const sbs = [];
    sbs.push(..._w2(EAN13_ENCS[10]));
    for (let i = 0; i <= 3; i++) {
        sbs.push(..._w2(EAN13_ENCS[parseInt(eight.charAt(i), 10)]));
    }
    sbs.push(..._w2(EAN13_ENCS[11]));
    for (let i = 4; i <= 7; i++) {
        sbs.push(..._w2(EAN13_ENCS[parseInt(eight.charAt(i), 10)]));
    }
    sbs.push(..._w2(EAN13_ENCS[12]));
    return sbs;
}

// EAN-5 add-on: 47 modules.
// Pattern: start(112) + d1(7) + sep(11) + d2(7) + sep(11) + d3(7) + sep(11)
//        + d4(7) + sep(11) + d5(7)
// Each digit's encoding is reversed when the checksum-derived mirror map
// character is '1'.
function encodeEAN5(five) {
    const sbs = [];
    const check = ean5Checksum(five);
    const mirror = EAN5_MIRRORMAPS[check];
    for (let i = 0; i < 5; i++) {
        if (i === 0) sbs.push(..._w2(EAN5_ENCS[10]));     // start "112"
        else         sbs.push(..._w2(EAN5_ENCS[11]));     // separator "11"
        let e = EAN5_ENCS[parseInt(five.charAt(i), 10)];
        if (mirror.charAt(i) === '1') e = _rev(e);
        sbs.push(..._w2(e));
    }
    return sbs;
}

// EAN-2 add-on: same structure but 2 digits.
function encodeEAN2(two) {
    const sbs = [];
    const check = ean2Checksum(two);
    const mirror = EAN2_MIRRORMAPS[check];
    for (let i = 0; i < 2; i++) {
        if (i === 0) sbs.push(..._w2(EAN2_ENCS[10]));
        else         sbs.push(..._w2(EAN2_ENCS[11]));
        let e = EAN2_ENCS[parseInt(two.charAt(i), 10)];
        if (mirror.charAt(i) === '1') e = _rev(e);
        sbs.push(..._w2(e));
    }
    return sbs;
}

// SBS sequence -> array of {mx, mw} bars (module positions and widths).
function sbsToBars(sbs) {
    const bars = [];
    let x = 0;
    for (let i = 0; i < sbs.length; i++) {
        if (i % 2 === 0) bars.push({mx: x, mw: sbs[i]});
        x += sbs[i];
    }
    return bars;
}

// EAN-13 / ISBN guard detection. Centre guard occupies modules 45-49 with
// bars at positions 46 and 48 (each 1 module wide).
function isGuardBar13(mxStart, mxEndExclusive) {
    if (mxEndExclusive <= 3) return true;                    // start guard
    if (mxStart >= 46 && mxEndExclusive <= 49) return true;  // centre guard
    if (mxStart >= 92) return true;                          // end guard
    return false;
}

// EAN-8 guard detection. Layout: start guard modules 0-2; centre guard
// modules 31-35 (bars at 32 and 34); end guard modules 64-66.
function isGuardBar8(mxStart, mxEndExclusive) {
    if (mxEndExclusive <= 3) return true;
    if (mxStart >= 32 && mxEndExclusive <= 35) return true;
    if (mxStart >= 64) return true;
    return false;
}

// Backwards compatibility alias for the EAN-13 case
const isGuardBar = isGuardBar13;

// ============================================================
// ISBN-13 proper hyphenation (via ISBNBarcode.org ranges API)
// Data source: https://isbnbarcode.org/api/isbn-ranges.json
// (Mirrored from the International ISBN Agency, updated yearly.)
// We fetch the ranges JSON once per script run and cache it. If the fetch
// fails (offline, server issue), we fall back silently to a 3-1-5-3-1
// split which is the most common pattern.
// The hyphenation algorithm:
// 1. Determine the registration group identifier length from the first 7
// digits after the EAN prefix (978 or 979), using EAN.UCCPrefixes rules.
// 2. Split off the group identifier.
// 3. Determine the publisher identifier length from the first 7 digits of
// the remainder, using the matching RegistrationGroup's rules.
// 4. Split off the publisher; the rest (minus check digit) is the
// publication identifier.
// 5. Final form: {prefix}-{group}-{publisher}-{publication}-{check}
// ============================================================

const ISBN_RANGES_URL = 'https://isbnbarcode.org/api/isbn-ranges.json';
let _isbnRangesCache = null;

// Fetch the ranges data with a timeout. Returns the parsed object on
// success, or null on failure. The result is cached in-memory for the script
// invocation lifetime. timeoutSec defaults to 15 (render path); the live
// dialog tick passes a short timeout so an offline machine pauses briefly,
// once, instead of hanging the open dialog.
function fetchISBNRanges(timeoutSec) {
    if (_isbnRangesCache !== null) return _isbnRangesCache || null;
    try {
        const req = HttpRequest.create(ISBN_RANGES_URL, RequestMethod.Get);
        req.setTimeoutInSec(timeoutSec || 15);
        const result = req.do();
        if (!result.response || result.response.statusCode.value !== 200) {
            _isbnRangesCache = false;  // false = "tried and failed"
            return null;
        }
        _isbnRangesCache = JSON.parse(result.response.content);
        return _isbnRangesCache;
    } catch (e) {
        _isbnRangesCache = false;
        return null;
    }
}

// Look up a digit prefix in a list of {Range: "start-end", Length: "n"} rules.
// Returns the matching Length (as a number) or 0 if no rule matches or the
// matched rule has Length "0" (= unassigned/reserved range).
function _findLengthInRules(digits, rules) {
    for (const r of rules) {
        const parts = r.Range.split('-');
        const start = parts[0];
        const end   = parts[1];
        const padded = digits.padEnd(start.length, '0').substring(0, start.length);
        if (padded >= start && padded <= end) {
            return parseInt(r.Length, 10);
        }
    }
    return 0;
}

// Fallback hyphenation when the ranges data is unavailable or doesn't cover
// the input. Uses the 3-1-5-3-1 layout which fits most modern ISBNs.
function _hyphenateISBNFallback(thirteen) {
    return thirteen.substring(0, 3) + '-' +
           thirteen.charAt(3) + '-' +
           thirteen.substring(4, 9) + '-' +
           thirteen.substring(9, 12) + '-' +
           thirteen.charAt(12);
}

// Hyphenate a 13-digit ISBN using the official ranges data when possible,
// falling back to 3-1-5-3-1 if the lookup fails.
function hyphenateISBN13(thirteen) {
    const data = fetchISBNRanges();
    if (!data) return _hyphenateISBNFallback(thirteen);

    try {
        const eanPrefix = thirteen.substring(0, 3);
        const rest      = thirteen.substring(3); // 10 digits

        const uccPrefixes = data.ISBNRangeMessage['EAN.UCCPrefixes']['EAN.UCC'];
        const prefixData  = uccPrefixes.find(p => p.Prefix === eanPrefix);
        if (!prefixData) return _hyphenateISBNFallback(thirteen);

        const groupLen = _findLengthInRules(rest.substring(0, 7),
                                            prefixData.Rules.Rule);
        if (groupLen === 0) return _hyphenateISBNFallback(thirteen);

        const group      = rest.substring(0, groupLen);
        const afterGroup = rest.substring(groupLen);

        const groups = data.ISBNRangeMessage.RegistrationGroups.Group;
        const groupKey = eanPrefix + '-' + group;
        const groupData = groups.find(g => g.Prefix === groupKey);
        if (!groupData) return _hyphenateISBNFallback(thirteen);

        const pubLen = _findLengthInRules(afterGroup.substring(0, 7),
                                          groupData.Rules.Rule);
        if (pubLen === 0) return _hyphenateISBNFallback(thirteen);

        const publisher   = afterGroup.substring(0, pubLen);
        const publication = afterGroup.substring(pubLen, afterGroup.length - 1);
        const check       = afterGroup.charAt(afterGroup.length - 1);

        return eanPrefix + '-' + group + '-' + publisher +
               '-' + publication + '-' + check;
    } catch (e) {
        return _hyphenateISBNFallback(thirteen);
    }
}

// ============================================================
// Rendering
// Coordinate system: BWIPP SVG reference uses viewBox 0..231 (wide) x 0..142
// (tall) for EAN-13/ISBN; EAN-8 uses a narrower frame. In that frame:
// * 1 module = 2 SVG units
// * Bar tops at y=19; short bars to y=122; guard bars to y=133
// * Bottom HRI baseline at y=140
// * Top label baseline at y=13
// * Quiet zone left edge of bars at x=24 (= module 0)
// Default print size uses 1 SVG unit = NOMINAL_MM_PER_UNIT mm, giving a
// GS1-nominal-sized barcode (~38mm wide ISBN).
// opts.sizePct controls bar HEIGHT only (not width) — this is GS1 truncation
// behaviour. At 100% the bars reach their full nominal height (~25mm). At 60%
// they are truncated from the TOP: all bar TOPS share the same scaled-down
// top edge (data bars and guard bars line up), and the bar BOTTOMS stay
// anchored at their nominal positions (guard bars still extend lower than
// data bars at the bottom — their descender into the HRI area is preserved).
// The top label moves DOWN with the bars to stay close above the new top
// edge. The HRI digits, right-hand guard ('>'), bar widths, and all text
// sizes remain at nominal regardless of sizePct.
// ============================================================

const NOMINAL_MM_PER_UNIT = 0.165;
const BAR_TOP_Y          = 19;
const BAR_BOT_SHORT      = 122;
const BAR_BOT_GUARD_13   = 133;   // for EAN-13/ISBN/UPC-A/ISSN
const BAR_BOT_GUARD_8    = 133;   // for EAN-8
const HRI_TOP_Y          = 124;
const TOP_LABEL_TOP_Y    = 1.33;
const ADDON_BAR_BOT_Y    = 133;   // bottoms flush with main guard-bar bottoms (GS1 §5.2.3.6)
const ADDON_BAR_H        = 86;    // nominal bar height (BWIPP-derived); scaled by % like main bars

// Helper to build a glyph node from a GLYPHS entry at (svgX, svgY) and add it
// to the given AddChildNodesCommandBuilder.
function addGlyphAt(builder, glyph, svgX, svgY, sx, sy, ox, oy, fill) {
    const offX = svgX * sx + ox;
    const offY = svgY * sy + oy;
    const noFill = FillDescriptor.createNone();
    const noLine = LineStyleDescriptor.createDefault(0);
    const curves = svgPathToCurves(glyph.d, sx, sy, offX, offY);
    const pc = PolyCurve.create();
    for (const c of curves) pc.addCurve(c);
    const def = PolyCurveNodeDefinition.create(pc, fill, noFill, noLine, noFill);
    builder.addPolyCurveNode(def);
}

// Draw the top label ('ISBN ...' / 'ISSN ...') at 10-unit pitch. Labels
// wider than the bar block stay left-anchored at x=1 (BWIPP-accurate —
// preserves legacy ISBN output byte-for-byte); narrower labels (e.g. the
// short ISSN 'ISSN nnnn-nnnX') center over the bars instead of orphaning
// left. cx/blockW describe the bar block in SVG units (EAN-13 family and
// UPC-A: bars 24..214 → 119/190; EAN-8: bars 14..148 → 81/134).
function drawTopLabel(builder, topLabel, cx, blockW, labelOffsetY,
                      sx, sy, ox, oy, fill) {
    const totalW = topLabel.length * 10;  // 10-unit pitch, spaces included
    let topX = (totalW < blockW) ? cx - totalW / 2 : 1;
    for (let i = 0; i < topLabel.length; i++) {
        const ch = topLabel.charAt(i);
        if (ch === ' ') { topX += 10; continue; }
        const g = GLYPHS.top[ch];
        if (g) addGlyphAt(builder, g, topX, g.top + labelOffsetY,
                          sx, sy, ox, oy, fill);
        topX += 10;
    }
}

// Add-on block verticals from % scale: bottoms pinned at the guard-bottom
// line (GS1 §5.2.3.6), heights scaled by % exactly like main bars.
// Shared digit baseline (digit bottoms sit ADDON_DIGIT_BASE_GAP above the
// add-on bar tops). Bottom glyphs vary slightly in height (15.88–16.17),
// so each glyph is placed individually at baseline − g.h for an exact
// shared baseline; the '>' guard uses the same baseline (minus its own
// height) and reads as one text line with the digits. Text stays nominal;
// everything rides % scale via the bar tops, like the main symbol.
const ADDON_DIGIT_BASE_GAP = 6.39;  // was: 17.67 top gap − 11.28 old glyph height
const ADDON_DIGIT_MAX_H = 16.17;    // tallest bottom digit ('8'), for background cover
function addonBarTopFor(heightScale) {
    return ADDON_BAR_BOT_Y - ADDON_BAR_H * heightScale;
}
function addonDigitBaselineFor(heightScale) {
    return addonBarTopFor(heightScale) - ADDON_DIGIT_BASE_GAP;
}
function guardSvgYAfterAddonFor(heightScale) {
    return addonDigitBaselineFor(heightScale) - GLYPHS.guard.h;
}

// Add a bar rectangle to the builder.
function addBarAt(builder, svgX, svgTop, svgW, svgH, sx, sy, ox, oy, fill) {
    const noFill = FillDescriptor.createNone();
    const noLine = LineStyleDescriptor.createDefault(0);
    const rect = ShapeRectangle.create();
    const def = ShapeNodeDefinition.create(rect, {
        x: svgX * sx + ox,
        y: svgTop * sy + oy,
        width: svgW * sx,
        height: svgH * sy
    }, fill, noFill, noLine, noFill);
    builder.addShapeNode(def);
}

// Create a named container and return it.
function createContainer(doc, name) {
    const cb = AddChildNodesCommandBuilder.create();
    cb.addContainerNode(ContainerNodeDefinition.create(name));
    const cmd = cb.createCommand(false);
    doc.executeCommand(cmd);
    return cmd.newNodes[0];
}

// Draw a filled background rectangle covering the given SVG-coordinate box.
// The background is added FIRST (before bars/glyphs) so it sits behind them
// in z-order. Breathing room, in points: 2pt on left/bottom, 4pt on top
// (headroom above the top label) and right (clear of the guard area).
// Converted here to SVG units (1pt = 25.4/72 mm).
const PT2SVG = (25.4 / 72) / NOMINAL_MM_PER_UNIT;
function addBackgroundBox(builder, svgX, svgY, svgW, svgH,
                          sx, sy, ox, oy, bgFill) {
    const noFill = FillDescriptor.createNone();
    const noLine = LineStyleDescriptor.createDefault(0);
    const padL = PT2SVG * 2, padB = PT2SVG * 2;
    const padT = PT2SVG * 4, padR = PT2SVG * 4;
    const rect = ShapeRectangle.create();
    const def = ShapeNodeDefinition.create(rect, {
        x:      (svgX - padL) * sx + ox,
        y:      (svgY - padT) * sy + oy,
        width:  (svgW + padL + padR) * sx,
        height: (svgH + padT + padB) * sy
    }, bgFill, noFill, noLine, noFill);
    builder.addShapeNode(def);
}

// Draw an add-on (2 or 5 digit). Returns the rightmost SVG x reached.
//   addOnDigits: '12345' or '12'
//   baseX_svg: SVG x coordinate of the LEFT edge of the add-on (first bar starts here)
// The add-on lives in the same SVG frame as the main barcode.
function drawAddOn(builder, addOnDigits, baseX_svg, sx, sy, ox, oy, fill,
                   heightScale) {
    const isFive = addOnDigits.length === 5;
    const sbs = isFive ? encodeEAN5(addOnDigits) : encodeEAN2(addOnDigits);
    const bars = sbsToBars(sbs);

    // GS1 §5.2.3.6: bottoms pinned at the guard-bottom line, heights scaled
    // by % exactly like main bars. Digits ride the tops at the label gap.
    const barTop = addonBarTopFor(heightScale);
    const barHeight = ADDON_BAR_H * heightScale;
    for (const b of bars) {
        const xL = baseX_svg + b.mx * 2;
        const w  = b.mw * 2;
        addBarAt(builder, xL, barTop, w, barHeight,
                 sx, sy, ox, oy, fill);
    }

    // Digit x positions mirror BWIPP's measured placement (ean5-1.svg
    // reference: digit glyph origins sit 3 modules left of their pattern
    // starts, uniformly — i.e. advance-centers ≈ pattern starts, both
    // lengths via the shared txt idiom). Pattern k starts at module 4+9k
    // (4-module '112' start, 7-module patterns on a 9-module pitch), so the
    // advance is centered on the start. (v1.1.8 centered on pattern centers
    // and v1.1.17 on bar ink — both sit right of the reference, ink
    // centering additionally jittering with mirror parity. Match the
    // lineage; don't out-measure it.)
    for (let i = 0; i < addOnDigits.length; i++) {
        const ch = addOnDigits.charAt(i);
        // Add-on digits use the HRI sans shapes (BWIPP renders add-on text
        // in the HRI face): centered over their bar ink (see above),
        // sharing one baseline (per-glyph y absorbs the small height
        // variance of the bottom table).
        const g = GLYPHS.bottom[ch];
        if (!g) continue;
        const cxSvg = baseX_svg + (4 + i * 9) * 2;
        const xSvg  = cxSvg - g.w / 2;
        const ySvg  = addonDigitBaselineFor(heightScale) - g.h;
        addGlyphAt(builder, g, xSvg, ySvg,
                   sx, sy, ox, oy, fill);
    }

    // Return the rightmost SVG x reached
    const totalModules = isFive ? 47 : 20;
    return baseX_svg + totalModules * 2;
}

// ============================================================
// renderEAN13Family
// Renders the EAN-13 / ISBN / ISSN family (95-module bar block, 1 system
// digit + 6 left + 6 right HRI). The top label is optional.
// opts: {
// thirteen:       13-digit EAN string (canonical)
// topLabel:       string or null/empty -- placed above bars at 10-unit pitch
// groupName:      container name (e.g. 'ISBN: 978-1-616899-41-7')
// sizePct:        e.g. 100
// posX_mm, posY_mm: placement in page mm
// colourRGBA:     RGBA8 colour for bars and glyphs
// addOn:          '' | '12' | '12345' -- optional add-on string
// }
// ============================================================
function renderEAN13Family(doc, opts, preview) {
    const mmToPx = doc.unitValueConverter.getConversionFactor(
        UnitType.Millimetre, UnitType.Pixel);
    // Widths and text stay at nominal print size; only bar HEIGHT is scaled
    // by sizePct (GS1 truncation). Bars are truncated from the TOP — the
    // bottoms stay anchored at their nominal y, the tops move down toward
    // them. The HRI/guard/top-label positions are unchanged.
    const sx = NOMINAL_MM_PER_UNIT * mmToPx;
    const sy = NOMINAL_MM_PER_UNIT * mmToPx;
    const heightScale = (opts.sizePct || 100) / 100;
    const shortFullH  = BAR_BOT_SHORT - BAR_TOP_Y;
    // All bars share the same scaled top edge; only their bottoms differ
    // (guard bars still extend down to BAR_BOT_GUARD_13 for the descender).
    const barTop      = BAR_BOT_SHORT - shortFullH * heightScale;
    // Top label moves with the bar top, preserving the nominal gap above.
    const topLabelTop = barTop - (BAR_TOP_Y - TOP_LABEL_TOP_Y);
    const ox = opts.posX_mm * mmToPx;
    const oy = opts.posY_mm * mmToPx;
    const fill = FillDescriptor.createSolid(opts.colourRGBA);

    // Preview builds bars+glyphs flat on the spread (no container); commit
    // wraps them in the named container. Single worker, preview flag only.
    const container = preview ? null : createContainer(doc, opts.groupName);
    const builder = AddChildNodesCommandBuilder.create();
    builder.autoName = false;
    if (!preview) builder.setInsertionTarget(container);

    // Guard-after-addon geometry: with an add-on the '>' rises to near the
    // bar tops (see guardSvgYAfterAddonFor); without, it stays at the HRI
    // baseline. The raised top always sits above the label line, so the
    // background must cover it when drawn.
    const guardAfterAddon = (opts.includeGuard !== false) && opts.addOn &&
                            (opts.addOn.length === 2 || opts.addOn.length === 5);

    // --- Background box (drawn FIRST so it sits behind everything) ---
    if (opts.includeBg && opts.bgColourRGBA) {
        // EAN-13 family spans SVG x = 0..230 normally (or 0..~217 without
        // the guard). If an add-on is present, extends to ~340.
        // Background extends past the add-on when present, and past the
        // guard glyph in every guarded case (guard ends 230.13 nominal,
        // 301.13 / 355.13 past a 2-/5-digit add-on).
        const bgRight = !opts.addOn
                      ? ((opts.includeGuard !== false) ? 230 : 217)
                      : opts.addOn.length === 5
                      ? ((opts.includeGuard !== false) ? 356 : 340)
                      : ((opts.includeGuard !== false) ? 302 : 285);
        // Background box hugs the visible content: the top follows bar
        // truncation (topLabelTop already sits above the top label; bare
        // bars start at barTop) while the bottom stays anchored at the HRI
        // area — so the box tracks % height. The taller HRI add-on digits
        // can reach above the label line (notably truncated); the guard
        // shares their baseline but is shorter, so covering the digit tops
        // covers everything.
        let contentTop = (opts.topLabel || opts.addOn) ? topLabelTop : barTop;
        if (opts.addOn && (opts.addOn.length === 2 || opts.addOn.length === 5)) {
            contentTop = Math.min(contentTop, addonDigitBaselineFor(heightScale) - ADDON_DIGIT_MAX_H);
        }
        const bgFill = FillDescriptor.createSolid(opts.bgColourRGBA);
        addBackgroundBox(builder, 0, contentTop, bgRight, 142 - contentTop,
                         sx, sy, ox, oy, bgFill);
    }

    // --- Main barcode bars (truncated from the TOP) ---
    const sbs = encodeEAN13(opts.thirteen);
    const bars = sbsToBars(sbs);
    for (const b of bars) {
        const xL = 24 + b.mx * 2;
        const w  = b.mw * 2;
        const guard = isGuardBar13(b.mx, b.mx + b.mw);
        const bot = guard ? BAR_BOT_GUARD_13 : BAR_BOT_SHORT;
        addBarAt(builder, xL, barTop, w, bot - barTop, sx, sy, ox, oy, fill);
    }

    // --- Bottom HRI (stays at nominal position regardless of truncation) ---
    const t = opts.thirteen;
    // First digit (system) in left quiet zone, right-aligned at x=14
    const fc = t.charAt(0);
    addGlyphAt(builder, GLYPHS.bottom[fc], 14 - GLYPHS.bottom[fc].w, HRI_TOP_Y,
               sx, sy, ox, oy, fill);
    // Left half slots starting at x=31, 14-wide each
    for (let i = 1; i <= 6; i++) {
        const slotX = 31 + (i - 1) * 14;
        const g = GLYPHS.bottom[t.charAt(i)];
        addGlyphAt(builder, g, slotX + (14 - g.w) / 2, HRI_TOP_Y, sx, sy, ox, oy, fill);
    }
    // Right half slots starting at x=123, 14-wide each
    for (let i = 7; i <= 12; i++) {
        const slotX = 123 + (i - 7) * 14;
        const g = GLYPHS.bottom[t.charAt(i)];
        addGlyphAt(builder, g, slotX + (14 - g.w) / 2, HRI_TOP_Y, sx, sy, ox, oy, fill);
    }

    // --- Top label (if any) ---
    if (opts.topLabel) {
        // Top label follows the bar top down (so it stays close above the
        // truncated bars rather than floating up at the nominal position).
        const labelOffsetY = topLabelTop - TOP_LABEL_TOP_Y;
        drawTopLabel(builder, opts.topLabel, 119, 190,
                     labelOffsetY, sx, sy, ox, oy, fill);
    }

    // --- Right-hand quiet-zone guard ('>') ---
    // After the add-on when present (add-on start is fixed at 245; guard
    // clears its 40/94-unit block plus the nominal 3.65 gap → 288.65 /
    // 342.65), else at the nominal 217.65. Shares the price digits'
    // baseline with an add-on (one text line); HRI baseline otherwise.
    if (opts.includeGuard !== false) {
        const addOnW = !opts.addOn ? 0 : opts.addOn.length === 5 ? 94 : 40;
        const guardX = opts.addOn ? 245 + addOnW + 3.65 : 217.65;
        const guardSvgY = guardAfterAddon ? guardSvgYAfterAddonFor(heightScale)
                                          : GLYPHS.guard.top;
        addGlyphAt(builder, GLYPHS.guard, guardX, guardSvgY,
                   sx, sy, ox, oy, fill);
    }

    // --- Add-on (if any) ---
    if (opts.addOn && (opts.addOn.length === 2 || opts.addOn.length === 5)) {
        // Add-on starts 12 SVG units to the right of the guard's right edge.
        // The guard ends at approximately x = 230 in the source SVG.
        // (Bar bottoms, not tops, align with the main guards — GS1 §5.2.3.6;
        // see drawAddOn.)
        const addOnStartSvg = 245;
        drawAddOn(builder, opts.addOn, addOnStartSvg, sx, sy, ox, oy, fill,
                  heightScale);
    }

    // createCommand(false): never auto-select new nodes — selecting while a
    // preview is active voids the painting (commit selects the container
    // manually afterwards; cf. 21-make-grid, which also passes false).
    doc.executeCommand(builder.createCommand(false), preview);
    return container;
}

// ============================================================
// renderEAN8
// EAN-8 layout: 67 modules total (3+28+5+28+3), 8 digits with 4 below each
// half of the bars. No top label.
// ============================================================
function renderEAN8(doc, opts, preview) {
    const mmToPx = doc.unitValueConverter.getConversionFactor(
        UnitType.Millimetre, UnitType.Pixel);
    // Widths and text stay at nominal; only bar HEIGHT scales (from the TOP).
    const sx = NOMINAL_MM_PER_UNIT * mmToPx;
    const sy = NOMINAL_MM_PER_UNIT * mmToPx;
    const heightScale = (opts.sizePct || 100) / 100;
    const shortFullH  = BAR_BOT_SHORT - BAR_TOP_Y;
    // All bars share the same scaled top edge; guard bottoms stay at
    // BAR_BOT_GUARD_8 (descender preserved).
    const barTop      = BAR_BOT_SHORT - shortFullH * heightScale;
    const topLabelTop = barTop - (BAR_TOP_Y - TOP_LABEL_TOP_Y);
    const ox = opts.posX_mm * mmToPx;
    const oy = opts.posY_mm * mmToPx;
    const fill = FillDescriptor.createSolid(opts.colourRGBA);

    // Preview builds bars+glyphs flat on the spread (no container); commit
    // wraps them in the named container. Single worker, preview flag only.
    const container = preview ? null : createContainer(doc, opts.groupName);
    const builder = AddChildNodesCommandBuilder.create();
    builder.autoName = false;
    if (!preview) builder.setInsertionTarget(container);

    // EAN-8 bars run 14..148; an add-on starts 15 units past bar end,
    // mirroring the family's gap past the guard glyph.
    const addOnStartSvg8 = 163;
    const addOnSvgW = !opts.addOn ? 0
                    : opts.addOn.length === 5 ? 47 * 2
                    : opts.addOn.length === 2 ? 20 * 2 : 0;
    // Guard x: nominal 151.65 (3.65 past bar end 148); after the add-on
    // when present (add-on start is fixed, guard clears it). Baseline height.
    const guardOn8 = opts.includeGuard !== false;
    const guardX8 = opts.addOn ? addOnStartSvg8 + addOnSvgW + 3.65 : 151.65;
    const guardAfterAddon8 = guardOn8 && opts.addOn &&
                             (opts.addOn.length === 2 || opts.addOn.length === 5);

    // --- Background box (drawn FIRST so it sits behind everything) ---
    if (opts.includeBg && opts.bgColourRGBA) {
        // EAN-8 spans SVG x = 0..162 (14 left quiet + 134 bars + 14 right quiet),
        // extending past the add-on and the guard glyph (ends 164.13
        // nominal) when present.
        const contentRight = addOnSvgW ? addOnStartSvg8 + addOnSvgW + 3 : 162;
        const bgRight = guardOn8 ? Math.max(contentRight, guardX8 + 12.48 + 2)
                                 : contentRight;
        // Box top follows truncation like the other renderers (bottom
        // anchored at HRI area); taller HRI add-on digits join the min when
        // present (covers the shorter guard automatically).
        let contentTop = (opts.topLabel || opts.addOn) ? topLabelTop : barTop;
        if (opts.addOn && (opts.addOn.length === 2 || opts.addOn.length === 5)) {
            contentTop = Math.min(contentTop, addonDigitBaselineFor(heightScale) - ADDON_DIGIT_MAX_H);
        }
        const bgFill = FillDescriptor.createSolid(opts.bgColourRGBA);
        addBackgroundBox(builder, 0, contentTop, bgRight, 142 - contentTop,
                         sx, sy, ox, oy, bgFill);
    }

    // Bars (use 7-module quiet zone on each side; left edge of bars at x = 14)
    // (For EAN-8 BWIPP places module-0 at SVG x=14, so quiet zone = 7 modules)
    const EAN8_QUIET_LEFT = 14;
    const sbs = encodeEAN8(opts.eight);
    const bars = sbsToBars(sbs);
    for (const b of bars) {
        const xL = EAN8_QUIET_LEFT + b.mx * 2;
        const w  = b.mw * 2;
        const guard = isGuardBar8(b.mx, b.mx + b.mw);
        const bot = guard ? BAR_BOT_GUARD_8 : BAR_BOT_SHORT;
        addBarAt(builder, xL, barTop, w, bot - barTop, sx, sy, ox, oy, fill);
    }

    // Bottom HRI: 4 digits below left half, 4 digits below right half.
    // HRI stays at its nominal position regardless of bar truncation.
    const t = opts.eight;
    // Left half: slots start at x=21
    for (let i = 0; i < 4; i++) {
        const slotX = 21 + i * 14;
        const g = GLYPHS.bottom[t.charAt(i)];
        addGlyphAt(builder, g, slotX + (14 - g.w) / 2, HRI_TOP_Y, sx, sy, ox, oy, fill);
    }
    // Right half: slots start at x=85
    for (let i = 4; i < 8; i++) {
        const slotX = 85 + (i - 4) * 14;
        const g = GLYPHS.bottom[t.charAt(i)];
        addGlyphAt(builder, g, slotX + (14 - g.w) / 2, HRI_TOP_Y, sx, sy, ox, oy, fill);
    }

    // Top label (optional)
    if (opts.topLabel) {
        // Top label follows the bar top down (so it stays close above the
        // truncated bars rather than floating up at the nominal position).
        const labelOffsetY = topLabelTop - TOP_LABEL_TOP_Y;
        drawTopLabel(builder, opts.topLabel, 81, 134,
                     labelOffsetY, sx, sy, ox, oy, fill);
    }

    // --- Right-hand quiet-zone guard ('>') ---
    // Raised near the bar tops after an add-on; HRI baseline otherwise.
    if (guardOn8) {
        const guardSvgY = guardAfterAddon8 ? guardSvgYAfterAddonFor(heightScale)
                                           : GLYPHS.guard.top;
        addGlyphAt(builder, GLYPHS.guard, guardX8, guardSvgY,
                   sx, sy, ox, oy, fill);
    }

    // --- Add-on (if any) ---
    if (opts.addOn && (opts.addOn.length === 2 || opts.addOn.length === 5)) {
        drawAddOn(builder, opts.addOn, addOnStartSvg8, sx, sy, ox, oy, fill,
                  heightScale);
    }

    // createCommand(false): never auto-select new nodes — selecting while a
    // preview is active voids the painting (commit selects the container
    // manually afterwards; cf. 21-make-grid, which also passes false).
    doc.executeCommand(builder.createCommand(false), preview);
    return container;
}

// ============================================================
// renderUPCA
// UPC-A uses the SAME 95-module bar layout as EAN-13 (encoded with a
// leading zero), but visually:
// * The first digit (system, after stripping the leading zero) sits to
// the LEFT of the bars at bar-baseline height
// * Digits 2-6 below left half (5 of them, not 6)
// * Digits 7-11 below right half (5 of them)
// * The check digit (last) sits to the RIGHT of the bars at bar-baseline
// height
// ============================================================
function renderUPCA(doc, opts, preview) {
    const mmToPx = doc.unitValueConverter.getConversionFactor(
        UnitType.Millimetre, UnitType.Pixel);
    // Widths and text stay at nominal; only bar HEIGHT scales (from the TOP).
    const sx = NOMINAL_MM_PER_UNIT * mmToPx;
    const sy = NOMINAL_MM_PER_UNIT * mmToPx;
    const heightScale = (opts.sizePct || 100) / 100;
    const shortFullH  = BAR_BOT_SHORT - BAR_TOP_Y;
    // All bars share the same scaled top edge; guard bottoms stay at
    // BAR_BOT_GUARD_13 (descender preserved).
    const barTop      = BAR_BOT_SHORT - shortFullH * heightScale;
    const topLabelTop = barTop - (BAR_TOP_Y - TOP_LABEL_TOP_Y);
    const ox = opts.posX_mm * mmToPx;
    const oy = opts.posY_mm * mmToPx;
    const fill = FillDescriptor.createSolid(opts.colourRGBA);

    // Preview builds bars+glyphs flat on the spread (no container); commit
    // wraps them in the named container. Single worker, preview flag only.
    const container = preview ? null : createContainer(doc, opts.groupName);
    const builder = AddChildNodesCommandBuilder.create();
    builder.autoName = false;
    if (!preview) builder.setInsertionTarget(container);

    // Guard-after-addon geometry (as in the EAN-13 family): with an add-on
    // the '>' rises to near the bar tops; without, HRI baseline.
    const guardAfterAddon = (opts.includeGuard !== false) && opts.addOn &&
                            (opts.addOn.length === 2 || opts.addOn.length === 5);

    // --- Background box (drawn FIRST so it sits behind everything) ---
    if (opts.includeBg && opts.bgColourRGBA) {
        // UPC-A spans SVG x = 0..230 (same as EAN-13 family).
        // Add-on (if any) extends further; background covers the guard
        // glyph too (ends 242.48 nominal, 301.13/355.13 past add-ons).
        const bgRight = !opts.addOn
                      ? ((opts.includeGuard !== false) ? 244 : 230)
                      : opts.addOn.length === 5
                      ? ((opts.includeGuard !== false) ? 356 : 340)
                      : ((opts.includeGuard !== false) ? 302 : 285);
        // Box top follows truncation (topLabelTop covers the label); bottom
        // anchored at the HRI area. Taller HRI add-on digits join the min
        // when present (covers the shorter guard automatically).
        let contentTop = (opts.topLabel || opts.addOn) ? topLabelTop : barTop;
        if (opts.addOn && (opts.addOn.length === 2 || opts.addOn.length === 5)) {
            contentTop = Math.min(contentTop, addonDigitBaselineFor(heightScale) - ADDON_DIGIT_MAX_H);
        }
        const bgFill = FillDescriptor.createSolid(opts.bgColourRGBA);
        addBackgroundBox(builder, 0, contentTop, bgRight, 142 - contentTop,
                         sx, sy, ox, oy, bgFill);
    }

    // The thirteen passed in is "0" + 11-digit UPC + check; encode as EAN-13.
    // The visible UPC-A digits are positions 1..12 of the thirteen (skip the
    // leading zero).
    const thirteen = opts.thirteen; // "0SSSSSSSSSSSC" -> 13 digits
    const upcaVisible = thirteen.substring(1); // 12 digits: S+10+C
    const firstDigit = upcaVisible.charAt(0);   // system digit
    const lastDigit  = upcaVisible.charAt(11);  // check digit

    // --- Bars (same as EAN-13) ---
    const sbs = encodeEAN13(thirteen);
    const bars = sbsToBars(sbs);
    for (const b of bars) {
        const xL = 24 + b.mx * 2;
        const w  = b.mw * 2;
        const guard = isGuardBar13(b.mx, b.mx + b.mw);
        const bot = guard ? BAR_BOT_GUARD_13 : BAR_BOT_SHORT;
        addBarAt(builder, xL, barTop, w, bot - barTop, sx, sy, ox, oy, fill);
    }

    // --- First digit (system) to LEFT of bars at nominal HRI position ---
    const g0 = GLYPHS.bottom[firstDigit];
    addGlyphAt(builder, g0, 14 - g0.w, HRI_TOP_Y, sx, sy, ox, oy, fill);

    // --- Middle 10 digits below the bars (positions 2-11 of upcaVisible) ---
    // 5 in left half, 5 in right half. Use the same +1/+3 nudges as EAN-13
    // but with 5 slots per side instead of 6.
    // Left-half data spans modules 3-44 (42 modules = 6 digits * 7). We want
    // 5 digits centred under the LAST 5 of those 6 (skipping the first,
    // because the first left-data digit corresponds to UPC-A pos 1 = system
    // digit we already drew outside). Actually UPC-A is a special case: the
    // EAN-13's left-half encodes UPC-A digits 1..6, and the right-half
    // encodes digits 7..11 + check. So UPC-A digits 2-6 are in EAN positions
    // 2-6 of the left half (slots 2-6, NOT slot 1).
    for (let i = 1; i <= 5; i++) {
        // EAN position i+1 (1-indexed in left half), digit = upcaVisible[i]
        const slotX = 31 + i * 14;
        const g = GLYPHS.bottom[upcaVisible.charAt(i)];
        addGlyphAt(builder, g, slotX + (14 - g.w) / 2, HRI_TOP_Y, sx, sy, ox, oy, fill);
    }
    // Right half slots 0..4 (UPC-A digits 7..11) — start at x=125 to
    // centre 5 digit slots in the 84-unit right data area (UPC-A uses 5 of
    // EAN-13's 6 right slots; the last slot's space is left empty since
    // the check digit is drawn OUTSIDE the bars)
    for (let i = 0; i <= 4; i++) {
        const slotX = 125 + i * 14;
        const g = GLYPHS.bottom[upcaVisible.charAt(6 + i)];
        addGlyphAt(builder, g, slotX + (14 - g.w) / 2, HRI_TOP_Y, sx, sy, ox, oy, fill);
    }

    // --- Last digit (check) to RIGHT of bars at nominal HRI position ---
    const g12 = GLYPHS.bottom[lastDigit];
    addGlyphAt(builder, g12, 217, HRI_TOP_Y, sx, sy, ox, oy, fill);

    // --- Top label (optional) ---
    if (opts.topLabel) {
        // Top label follows the bar top down (so it stays close above the
        // truncated bars rather than floating up at the nominal position).
        const labelOffsetY = topLabelTop - TOP_LABEL_TOP_Y;
        drawTopLabel(builder, opts.topLabel, 119, 190,
                     labelOffsetY, sx, sy, ox, oy, fill);
    }

    // --- Right-hand quiet-zone guard ('>') ---
    // Nominal 230 (clears the outboard check digit ending ~227.4); after
    // the add-on when present, as in the EAN-13 family. Shares the price
    // digits' baseline with an add-on; HRI baseline otherwise.
    if (opts.includeGuard !== false) {
        const addOnW = !opts.addOn ? 0 : opts.addOn.length === 5 ? 94 : 40;
        const guardX = opts.addOn ? 245 + addOnW + 3.65 : 230;
        const guardSvgY = guardAfterAddon ? guardSvgYAfterAddonFor(heightScale)
                                          : GLYPHS.guard.top;
        addGlyphAt(builder, GLYPHS.guard, guardX, guardSvgY,
                   sx, sy, ox, oy, fill);
    }

    // --- Add-on (if any) ---
    if (opts.addOn && (opts.addOn.length === 2 || opts.addOn.length === 5)) {
        const addOnStartSvg = 245;
        drawAddOn(builder, opts.addOn, addOnStartSvg, sx, sy, ox, oy, fill,
                  heightScale);
    }

    // createCommand(false): never auto-select new nodes — selecting while a
    // preview is active voids the painting (commit selects the container
    // manually afterwards; cf. 21-make-grid, which also passes false).
    doc.executeCommand(builder.createCommand(false), preview);
    return container;
}

// ============================================================
// Dialog and main
// ============================================================

const BARCODE_TYPES = [
    { id: 'isbn',  label: 'ISBN (book)',         sample: '978-0-306-40615-7' },
    { id: 'ean13', label: 'EAN-13',              sample: '5012345678900' },
    { id: 'ean8',  label: 'EAN-8',               sample: '12345670' },
    { id: 'upca',  label: 'UPC-A',               sample: '012345000058' },
    { id: 'issn',  label: 'ISSN (periodical)',   sample: '1234-5679' }
    // NOTE: all samples are check-digit-valid, so pressing OK immediately
    // renders a barcode — edit in place with your own number.
    // ISMN was removed from the menu (v1.0.1): its sample failed check-digit
    // validation and the renderer stub only showed a "not built in" alert.
    // To add ISMN, supply an ISMN sample SVG (from BWIPP) so the M glyph can
    // be extracted the same way I and S were, then re-add a menu entry here.
];

// Single worker shared by the live preview tick and the OK commit path so
// the two can never diverge. Reads every dialog control, validates, and
// normalises into renderer-ready options. Throws Error carrying the
// user-facing message: pre-check failures throw their bare alert text;
// normalise failures are wrapped as 'Could not create barcode:\n\n...'.
// main() shows err.message verbatim, preserving the long-standing alerts.
// forPreview hyphenates from session-cached data only (pre-warmed bounded
// by the refresh path) — it never initiates a render-path fetch, so a
// preview NEVER blocks beyond that cap; bars are identical either way.
// lenientAddOn (preview only) coerces an invalid add-on to '' instead of
// throwing, so a half-typed add-on costs the add-on, not the whole preview.
function buildBarcodeOpts(doc, dlg, forPreview, lenientAddOn) {
    const typeId = BARCODE_TYPES[dlg.typeCombo.selectedIndex].id;
    const data   = dlg.dataBox.text.trim();
    let addOn    = dlg.addOnBox.text.trim().replace(/\s+/g, '');
    const sizePct = dlg.scaleEditor.value;
    const posX_mm = dlg.posX.value;
    const posY_mm = dlg.posY.value;
    const includeGuard = dlg.guardSwitch.value;
    const showTopLabel = dlg.topLabelSwitch.value;
    const colourRGBA = dlg.barColourPicker.value || RGBA8(0, 0, 0, 255);
    const includeBg = dlg.bgSwitch.value;
    const bgColourRGBA = dlg.bgColourPicker.value || RGBA8(255, 255, 255, 255);

    if (!data) throw new Error('Please enter a number.');
    const addOnBadLength = addOn && addOn.length !== 2 && addOn.length !== 5;
    const addOnBadChars = addOn && !/^\d+$/.test(addOn);
    if (addOnBadLength || addOnBadChars) {
        // Lenient preview path: drop a half-typed add-on and render the main
        // symbol alone (the status line already explains the add-on error).
        // OK-time stays strict and alerts instead. Message precedence
        // (length before charset) matches the long-standing alerts exactly.
        if (lenientAddOn) {
            addOn = '';
        } else if (addOnBadLength) {
            throw new Error('Add-on must be 2 or 5 digits (or blank).');
        } else {
            throw new Error('Add-on must contain only digits.');
        }
    }

    const opts = {
        sizePct: sizePct,
        posX_mm: posX_mm,
        posY_mm: posY_mm,
        colourRGBA: colourRGBA,
        addOn: addOn,
        includeGuard: includeGuard,
        includeBg: includeBg,
        bgColourRGBA: bgColourRGBA
    };

    try {
        if (typeId === 'isbn') {
            const norm = normaliseISBN(data);
            // Preview hyphenates too (typed hyphens first, else live ranges
            // data via the refresh path's bounded pre-warm — offline it
            // falls back silently); commit path is unchanged.
            const formatted = norm.userFormatted || hyphenateISBN13(norm.thirteen);
            opts.thirteen = norm.thirteen;
            opts.topLabel = showTopLabel ? 'ISBN ' + formatted : null;
            opts.groupName = 'ISBN: ' + formatted +
                             (addOn ? ' +' + addOn : '');
            return { renderer: 'ean13family', opts: opts };
        } else if (typeId === 'ean13') {
            const thirteen = normaliseEAN13(data);
            opts.thirteen = thirteen;
            opts.topLabel = null;
            opts.groupName = 'EAN-13: ' + thirteen +
                             (addOn ? ' +' + addOn : '');
            return { renderer: 'ean13family', opts: opts };
        } else if (typeId === 'ean8') {
            const eight = normaliseEAN8(data);
            opts.eight = eight;
            opts.topLabel = null;
            opts.groupName = 'EAN-8: ' + eight +
                             (addOn ? ' +' + addOn : '');
            return { renderer: 'ean8', opts: opts };
        } else if (typeId === 'upca') {
            const twelve = normaliseUPCA(data);
            opts.thirteen = '0' + twelve;
            opts.topLabel = null;
            opts.groupName = 'UPC-A: ' + twelve +
                             (addOn ? ' +' + addOn : '');
            return { renderer: 'upca', opts: opts };
        } else if (typeId === 'issn') {
            const thirteen = normaliseISSN(data);
            const label = formatISSNLabel(thirteen);
            opts.thirteen = thirteen;
            opts.topLabel = 'ISSN ' + label;
            opts.groupName = 'ISSN: ' + label +
                             (addOn ? ' +' + addOn : '');
            return { renderer: 'ean13family', opts: opts };
        }
    } catch (err) {
        throw new Error('Could not create barcode:\n\n' + err.message);
    }
    throw new Error('Unknown barcode type.');
}

function renderBarcode(doc, renderer, opts, preview) {
    if (renderer === 'ean8') return renderEAN8(doc, opts, preview);
    if (renderer === 'upca') return renderUPCA(doc, opts, preview);
    return renderEAN13Family(doc, opts, preview);
}

// Colour identity for the preview key, layered (first hit wins):
// 1. wrapper component properties (r/g/b plus a/alpha variants);
// 2. native ColourApi.getRGBA8(handle) via lazy require (cached; a missing
//    module must never break the script, so this stays in try/catch);
// 3. constant fallback (key then ignores colour — commit stays correct).
let _nativeColourApi = null;
function _getNativeColourApi() {
    if (_nativeColourApi === 'missing') return null;
    if (_nativeColourApi) return _nativeColourApi;
    try {
        _nativeColourApi = require('affinity:colours').ColourApi || 'missing';
    } catch (e) {
        _nativeColourApi = 'missing';
    }
    return _nativeColourApi === 'missing' ? null : _nativeColourApi;
}
function colourKey(c) {
    try {
        if (!c) return 'none';
        if (typeof c.r === 'number' && typeof c.g === 'number' && typeof c.b === 'number') {
            const a = (typeof c.a === 'number') ? c.a
                    : (typeof c.alpha === 'number') ? c.alpha : 255;
            return [c.r, c.g, c.b, a].join(',');
        }
        if (c.handle) {
            const api = _getNativeColourApi();
            if (api && api.getRGBA8) {
                const v = api.getRGBA8(c.handle);
                if (v && typeof v.r === 'number') {
                    return [v.r, v.g, v.b, v.a].join(',');
                }
            }
        }
    } catch (e) {
        /* unreadable — fall through */
    }
    return 'unreadable';
}

// Preview change-key: every value that affects the output, joined. Colours
// are read for real (layered accessors above) so a picker-close tick — the
// commit point of a drag — rebuilds with the new colour; the sequence
// counter stays as belt-and-braces for any picker event that does fire.
function previewKeyFor(built, colourSeq) {
    const o = built.opts;
    return [
        built.renderer,
        o.thirteen || o.eight || '',
        o.topLabel || '',
        o.sizePct, o.posX_mm, o.posY_mm,
        o.addOn, o.includeGuard, o.includeBg,
        colourKey(o.colourRGBA), colourKey(o.bgColourRGBA),
        colourSeq
    ].join('|');
}

function buildDialog(doc) {
    const dlg = Dialog.create('Barcode Generator');
    dlg.initialWidth = 400;
    const col = dlg.addColumn();

    // ---- Code group (compact: type, number, add-on, guard checkbox) ----
    const codeGroup = col.addGroup('Code');
    const typeLabels = BARCODE_TYPES.map(t => t.label);
    dlg.typeCombo = codeGroup.addComboBox('Type:', typeLabels, 0);

    dlg.dataBox = codeGroup.addTextBox('Number:', BARCODE_TYPES[0].sample);
    // Bracket explanation as a static line (static-at-build text always
    // paints at open; the '\n' two-line label attempt did not render as two
    // lines in-app, so the label is single-line again).
    // Full-width so the long hint is never clipped to the value column.
    dlg.hintLine = codeGroup.addStaticText(' ', '(ISBN-10/12-digit entries expand to 13 digits when you leave the field.)');
    try { dlg.hintLine.isFullWidth = true; } catch (e) {}
    dlg.addOnBox = codeGroup.addTextBox('Add-on (2 or 5 digits):', '');
    dlg.guardSwitch = codeGroup.addSwitch(
        'Include right-hand guard (>)', true);
    // ISBN top line is optional eye-legible metadata (ISO 2108 says it
    // "should", not "shall", appear); default ON preserves all existing
    // output. ISSN keeps its top line always (stricter guidance, and the
    // only true-ISSN human rendering). Auto-disabled for non-ISBN types.
    dlg.topLabelSwitch = codeGroup.addSwitch('Show ISBN line above bars', true);
    // Live status line: the polling tick below writes validation errors
    // here ('❌ ...' — red cross mark + VS16 emoji-presentation lock; no
    // text-colour API exists for dialog controls in SDK 3.3, verified
    // against the official reference, so a red glyph is the closest
    // achievable red) or blanks it. Blank at build. NOTE: StaticText live
    // repaint is unproven on current builds (broken on 3.2.1); if this line
    // stays blank in-app, OK-time alerts remain the enforcement backstop
    // and the dialog still functions fully.
    dlg.statusLine = codeGroup.addStaticText(' ', ' ');
    // Full-width row: the message gets ~the entire dialog width instead of
    // squeezing into the value column beside a caption (the label slot is
    // fixed at creation — native API has getLabel but no setLabel — so the
    // caption can't carry dynamic text; the ❌ prefix marks the row instead).
    try { dlg.statusLine.isFullWidth = true; } catch (e) {}

    // Auto-schema: picking a type fills the Number box with that type's
    // check-digit-valid sample in the SAME open dialog (no close/reopen).
    // Proven pattern: per-control onValueChangedHandler (cf. latex-editor.js
    // exampleCombo, iOS-squircle-rect.js presetCtrl). Smart-preserve: only
    // replaces the box when the user hasn't typed their own value (empty or
    // still showing the previous type's sample), so custom input survives a
    // mis-click on the combo. Also clears the live status line (context
    // changed). Wrapped in try/catch so builds without the handler degrade
    // to the previous static-sample behaviour.
    let lastTypeIdx = 0;
    try {
        dlg.typeCombo.onValueChangedHandler = function () {
            try {
                const idx = dlg.typeCombo.selectedIndex;
                if (idx === lastTypeIdx) return;
                if (idx < 0 || idx >= BARCODE_TYPES.length) return;
                const prevSample = BARCODE_TYPES[lastTypeIdx].sample;
                lastTypeIdx = idx;
                try { dlg.topLabelSwitch.isEnabled = (BARCODE_TYPES[idx].id === 'isbn'); } catch (e) {}
                const cur = dlg.dataBox.text;
                if (!cur || cur === prevSample) {
                    dlg.dataBox.text = BARCODE_TYPES[idx].sample;
                }
                setStatus(' ');
                refreshPreview();
            } catch (e) {
                /* ignore mid-edit states */
            }
        };
    } catch (e) {
        /* handler unsupported — static initial sample remains */
    }

    function setStatus(s) {
        try {
            if (dlg.statusLine.text !== s) dlg.statusLine.text = s;
        } catch (e) {
            /* ignore mid-edit states */
        }
    }

    // Live ISBN feedback (change handler: dialog-wide plus per-control
    // attachments below — whichever fires on a given build): expands complete valid
    // ISBN-10/12 input to 13 digits and surfaces check-digit errors on the
    // status line, all in the single open dialog. Writes land visibly once
    // the box loses focus (writes to the focused box don't repaint, and the
    // SDK exposes no blur event — the tick keeps firing after Tab-out, when
    // the box is unfocused and writable-visibly). Guards:
    // - ISBN type only; other types untouched.
    // - Stateless: every tick re-evaluates the live box text (no change
    //   cache — a cached "last seen" copy once desynchronized after
    //   programmatic writes, so a repeat paste evaluated as "unchanged"
    //   and did nothing).
    // - Never rewrites partial input; errors only for complete-looking
    //   input (exactly 10/12/13 chars, or >13).
    // - Mid-correction guard: a single-char deletion of a finished valid 13
    //   stays editable (paste-over and fresh typing still convert).
    // - Hyphenation only with live ranges data (one lazy fetch per dialog
    //   session, 5s cap); otherwise plain digits, so no wrong grouping gets
    //   locked in via the render path's user-hyphenation preservation.
    // - Post-write state recomputes to itself: no write loops.
    // OK-time validation is unchanged and remains the backstop.
    // Only prevStripped/prevValid13 are retained (for the single-deletion
    // guard); everything else is recomputed from the live box each tick.
    const tickState = { prevStripped: '', prevValid13: false, rangesTried: false };
    function thirteenDisplay(thirteen) {
        if (!tickState.rangesTried && _isbnRangesCache === null) {
            tickState.rangesTried = true;
            fetchISBNRanges(5);
        }
        return _isbnRangesCache ? hyphenateISBN13(thirteen) : thirteen;
    }
    function onTick() {
        try {
                const typeId = BARCODE_TYPES[dlg.typeCombo.selectedIndex].id;
                const addOnText = dlg.addOnBox.text.trim().replace(/\s+/g, '');
                const aoe = addOnErrorFor(addOnText);
                if (aoe) {
                    setStatus('❌\uFE0F ' + aoe);
                } else if (typeId === 'isbn') {
                    const cur = dlg.dataBox.text;
                    const prevStripped = tickState.prevStripped;
                    const wasPrevValid13 = tickState.prevValid13;
                    const stripped = stripFormatting(cur).toUpperCase();
                    tickState.prevStripped = stripped;
                    tickState.prevValid13 = isValidISBN13Digits(stripped);
                    const expanded = tryExpandISBNTo13(cur);
                    if (expanded) {
                        if (!(wasPrevValid13 && isSingleDeletion(prevStripped, stripped))) {
                            const target = thirteenDisplay(expanded);
                            if (cur !== target) dlg.dataBox.text = target;
                        }
                        setStatus(' ');
                    } else if (isValidISBN13Digits(stripped)) {
                        const target = thirteenDisplay(stripped);
                        if (cur !== target) dlg.dataBox.text = target;
                        setStatus(' ');
                    } else {
                        setStatus(isbnErrorFor(stripped));
                    }
                } else {
                    tickState.prevStripped = '';
                    tickState.prevValid13 = false;
                    setStatus(' ');
                }
                refreshPreview();
        } catch (e) {
            /* ignore mid-edit states */
        }
    }
    try {
        dlg.onControlValueChangedHandler = onTick;
    } catch (e) {
        /* handler unsupported — OK-time validation still applies */
    }

    // Live on-canvas preview: rebuilds ONLY when the change-key differs
    // (the tick fires constantly; an unconditional rebuild per poll would
    // melt). One preview is ever active — each rebuild atomically replaces
    // the previous (cf. 01-add-guides, 21-make-grid). Invalid input clears
    // the preview; the status line / OK-time alerts explain why.
    let lastPreviewKey = null;
    let previewActive = false;
    let colourSeq = 0;
    function refreshPreview(prewarm) {
        // Bounded hyphenation pre-warm for preview labels: one ≤5s ranges
        // attempt per dialog session, ISBN-looking input only. Skipped when
        // prewarm === false (initial pre-modal paint opens instantly — the
        // first tick warms instead and the label self-corrects via the key).
        if (prewarm !== false) {
            try {
                if (BARCODE_TYPES[dlg.typeCombo.selectedIndex].id === 'isbn' &&
                    _isbnRangesCache === null) {
                    const s = stripFormatting(dlg.dataBox.text).toUpperCase();
                    if (s.length === 10 || s.length === 12 || s.length === 13) {
                        fetchISBNRanges(5);
                    }
                }
            } catch (e) {}
        }
        let built = null;
        try {
            built = buildBarcodeOpts(doc, dlg, true, true);
        } catch (e) {
            built = null;
        }
        if (!built) {
            if (previewActive) {
                try { doc.clearPreviews(); } catch (e) {}
                previewActive = false;
            }
            lastPreviewKey = null;
            return;
        }
        const key = previewKeyFor(built, colourSeq);
        if (key === lastPreviewKey) return;
        lastPreviewKey = key;
        try {
            renderBarcode(doc, built.renderer, built.opts, true);
            previewActive = true;
        } catch (e) {
            // Preview must never break the dialog; OK-time path surfaces
            // errors. Keep lastPreviewKey (do NOT reset): retrying the same
            // failing input on every poll would hammer a failing command.
            previewActive = false;
        }
    }
    // Every remaining control triggers the same shared evaluation: the
    // dialog-wide handler is event-driven on this build (text/unit-editor
    // commits) and never fires for switch/picker interactions, so those
    // would otherwise sit unapplied until the next text tick. Key-gating
    // inside refreshPreview makes redundant firings free. (v1.1.0 wired the
    // colour handlers before the pickers existed — swallowed by try/catch,
    // never attached. This block runs after all controls exist.)
    // Colour pickers go through bump wrappers so their changes enter the
    // key (Colour wrapper internals are not probed); the type combo keeps
    // its own handler (sample fill) and calls refreshPreview() directly.
    // Every remaining control triggers the same shared evaluation (method
    // form for switches/pickers — proven to fire on current builds;
    // property form elsewhere). Colour pickers bump the change-key sequence
    // (their chosen colour is applied at commit at the latest: pickers emit
    // no dialog events, so colour is OK-time-only for live preview).
    function attachTick(ctrl) {
        try { if (ctrl) ctrl.onValueChangedHandler = onTick; } catch (e) {}
    }
    function attachMethodTick(ctrl) {
        try {
            if (!ctrl) return;
            if (typeof ctrl.setOnValueChangedHandler === 'function') {
                ctrl.setOnValueChangedHandler(onTick);
            } else {
                ctrl.onValueChangedHandler = onTick;
            }
        } catch (e) {}
    }
    function attachColourTick(ctrl) {
        try {
            if (!ctrl) return;
            const fn = function () { colourSeq++; onTick(); };
            if (typeof ctrl.setOnValueChangedHandler === 'function') {
                ctrl.setOnValueChangedHandler(fn);
            } else {
                ctrl.onValueChangedHandler = fn;
            }
        } catch (e) {}
    }
    attachTick(dlg.dataBox);
    attachTick(dlg.addOnBox);
    attachMethodTick(dlg.guardSwitch);
    attachTick(dlg.scaleEditor);
    attachTick(dlg.posX);
    attachTick(dlg.posY);
    attachMethodTick(dlg.bgSwitch);
    attachMethodTick(dlg.topLabelSwitch);
    attachColourTick(dlg.barColourPicker);
    attachColourTick(dlg.bgColourPicker);

    // ---- Bar height (width stays at nominal print size) ----
    const dimGroup = col.addGroup('Bar height');
    dlg.scaleEditor = dimGroup.addUnitValueEditor(
        'Bar height (% of nominal):',
        UnitType.Number, UnitType.Number,
        100, 25, 200);
    dlg.scaleEditor.precision = 0;

    // ---- Colour ----
    const colourGroup = col.addGroup('Colour');
    dlg.barColourPicker = colourGroup.addColourPicker(
        'Bar / text colour:', new Colour(RGBA8(0, 0, 0, 255).handle));

    // ---- Position ----
    const posGroup = col.addGroup('Position on spread');
    dlg.posX = posGroup.addUnitValueEditor(
        'X:', UnitType.Millimetre, UnitType.Millimetre, 10.0);
    dlg.posX.precision = 2;
    dlg.posX.noMinValue = true; dlg.posX.noMaxValue = true;
    dlg.posY = posGroup.addUnitValueEditor(
        'Y:', UnitType.Millimetre, UnitType.Millimetre, 10.0);
    dlg.posY.precision = 2;
    dlg.posY.noMinValue = true; dlg.posY.noMaxValue = true;

    // ---- Background (applies to all barcode types) ----
    const bgGroup = col.addGroup('Background');
    dlg.bgSwitch = bgGroup.addSwitch('Include background box', false);
    dlg.bgColourPicker = bgGroup.addColourPicker(
        'Background colour:', new Colour(RGBA8(255, 255, 255, 255).handle));

    // First paint: the valid initial sample previews as the dialog opens.
    // No pre-warm here (opens instantly); the first tick warms the ranges
    // fetch and the label self-corrects via the change-key.
    refreshPreview(false);

    return dlg;
}

function main() {
    const doc = Document.current;
    if (!doc) {
        app.alert('Open a document first.');
        return;
    }

    const dlg = buildDialog(doc);

    while (dlg.runModal() == DialogResult.Ok) {
        let built;
        try {
            built = buildBarcodeOpts(doc, dlg, false);
        } catch (err) {
            app.alert(err.message);
            continue;
        }
        // Commit: drop the transient preview first so it never doubles with
        // (or is mistaken for) the real nodes, then render for real and
        // select the new container. Render errors keep today's alert text.
        try { doc.clearPreviews(); } catch (e) {}
        try {
            const container = renderBarcode(doc, built.renderer, built.opts, false);
            if (container) {
                try { doc.selection = container.selfSelection; } catch (e) {}
            }
        } catch (err) {
            app.alert('Could not create barcode:\n\n' + err.message);
            continue;
        }
        break;
    }
    try { doc.clearPreviews(); } catch (e) {}
}

main();
